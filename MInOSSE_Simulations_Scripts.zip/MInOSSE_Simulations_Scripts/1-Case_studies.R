# By using this script the users can perform MInOSSE with the case studies reported
# in the main manuscript
#  

# WARNING! EcoPast (GPL-2) relies on some functions provided by other packages. Some of these packages cannot be directly installed along with EcoPast because they are distributed under different license types. Please notice, before installing EcoPast, make sure you have installed the following packages:
#  SDMTools (last version) available at https://cran.r-project.org/src/contrib/Archive/SDMTools/.
# chronosphere and rangeBuilder, available on CRAN, can be installed by means of the common installation procedure in R.

library(devtools)
install.packages(c("chronosphere","rangeBuilder"))
install_github("francesco-carotenuto/EcoPast")


library(EcoPast)
data(lgm)
library(raster)
raster(system.file("exdata/prediction_ground.gri", package="EcoPast"))->prediction_ground



#### Geographic range reconstruction of Mummuthus primigeniuis in Eurasia from 24 kya to 14 kya ####
# First step: run minosse data to create the ecological predictors and select apart the target species occurrences
system.time(mam_minosse_dat<-minosse.data(
  obj=lgm, # the dataframe with the fossil record of all the species (target and predictors)
  species_name="Mammuthus_primigenius", # the target species name as reported in the fossil dataset (lgm in this case)
  domain=NULL, # the spatial domain. Only used if you don't have a paleo map of the considered time period. Consider using the function "mapofpast" to get paleomaps of several temporal intervals
  coc.by="cell", # level at which performing the co-occurrence analysis. "Cell" is a setting suited for fossil localities with just one species (like many LGM fossil sites). By this setting the species belonging to different sites but occurring in the same spatial cell are combined and the co-occurrence analysis is performed by using this new species list
  min.occs=3, # species with less than this occurrences'number are discarded either as target either as predictors.
  abiotic.covs=NULL, # If you have abiotic covariates's rasters you can include them in this argument as stack. These variables will be added to the predictors species. 
  combine.covs=TRUE,  # Experimental. If FALSE, if you use some strategy for variables' dimensionality reduction, the abiotic covariates are not involved in this reduction and forced to be used as they are in the target species reconstruction. 
  reduce_covs_by="pca", # The strategy for predictor species' dimensionality reduction. You can choose: "pca", "corr" (correlation) or "variance" (VIF).
  covs_th=0.95, # The threshold above which excluding predictors. 
  c.size="mean", # the resolution of the grid used for spatial reconstruction. It can be "mean","semimean" (slower) or any numeric value (1 = 1x1 meter).
  bkg.predictors="presence", # The number of pseudo-absences to simulate. "presence" force minosse.data to simulate as many pseudo-absences as the predictors' presences are.
  min.bkg=100, # The minimum number of pseudo-absences to simulate.
  sampling.by.distance=TRUE, # The spatial strategy to simulate the pseudo-absences. TRUE = the nearer to target's occurrences the lower the pseudo-absences density. FASLE = random distribution.
  prediction.ground=prediction_ground, # The raster used as geographical domain to perform the spatial reconstructions. The function mapofpas can provide many interesting paleo maps reconstructions along with paleo dems! Powered by Scotese and Wright (2018) !
  crop.by.mcp=FALSE, # If TRUE, the spatial reconstructions are limited within the minimum convex polygon enclosing all the fosisl sites. FALSE allows using the whole spatial domain.
  projection=NULL, # The Equal area projection of the spatial reconstructions. It can be null if the prediction ground has its own equal-area projection.
  lon_0=NULL, # The projection's centre longitude. Can be null if the prediction ground has its own projection set
  lat_0=NULL, # The projection's centre latitude. Can be null if the prediction ground has its own projection set
  n.clusters="automatic", # The number of clusters for the parallel computation. By setting "automatic" the algorithm finds the best cores' number to speed up minosse.data without slowling down your PC!
  seed=625 # The seed you can set to perform reproducible experiments.
  ));gc();spplot(mam_minosse_dat[[2]])
## 

# Second step: running minosse.target by using the output of minosse.data in order to reconstruct
# target species geographic range.
system.time(mam_minosse_res<-minosse.target(
  resp=mam_minosse_dat[[1]], # the first output of minosse.data function is the fossil record of the target species.
  predictors=mam_minosse_dat[[2]], # the second output of minosse.data function is the stack of predictor species' rasters.
  bkg="presence", # as done for minosse.data function, you can set the number of pseudo-absences to simulate. 
  min.bkg = 100, # the number of the minimum required pseudo-absences.
  n.sims=10, # the number of pseudo-absences' simulations to perform.
  sampling.by.distance=TRUE, # as done for minosse.data function, this argument allows you to set the strategy for the spatial distribution of the pseudo-absences.
  n.folds=1, # The number of folds for model's cross validation to generate indices of model's performance. Notice that n.folds * n.sims. 
  n.sims.clusters="automatic", # The number of clusters for parallel computation.
  seed=625 # The seed you can set to perform reproducible experiments.
  ));gc()
mam_minosse_res$validation # Extracting the indices that tell about the model's performance
minosse.poly(mam_minosse_res) # Generating the polygon of the reconstructed target species' geographic range (which is a raster object in the output of minosse.target)
library(ggplot2)
minosse.plot(mam_minosse_res) # A nice plot of the results (according to the authors!)





#### Capreolus capreolus. In this script the Roe deer geographic range was reconstructed since 24 kya instead of 130 kya
# because of we used a fully revised, not-yet buplished dataset for the longer time interva. Also in this restricted example the 
#results and reconstructions are still consistent with what reported in the main manuscript 

# First step: run minosse data to create the ecological predictors and select apart the target species occurrences
system.time(cap_minosse_dat<-minosse.data(
  obj=lgm,
  species_name="Capreolus_capreolus",
  domain="land",
  coc.by="locality",
  min.occs=3,
  abiotic.covs=NULL,
  combine.covs=FALSE,   
  reduce_covs_by="pca",
  covs_th=0.95,
  c.size="mean",
  bkg.predictors="presence",
  min.bkg=100,
  sampling.by.distance=TRUE,
  prediction.ground=NULL,
  crop.by.mcp=FALSE,
  projection="laea",
  lon_0=NULL,
  lat_0=NULL,
  n.clusters="automatic",
  seed=625));gc();spplot(cap_minosse_dat[[2]])
## 


# Second step: running minosse.target by using the output of minosse.data in order to reconstruct
# target species geographic range.
system.time(cap_minosse_res<-minosse.target(
  resp=cap_minosse_dat[[1]],
  predictors=cap_minosse_dat[[2]],
  bkg="presence", 
  min.bkg = 100,
  n.sims=10, 
  sampling.by.distance=TRUE,
  n.folds=1, 
  n.sims.clusters="automatic",
  seed=625));gc()
cap_minosse_res$validation
minosse.poly(cap_minosse_res)
library(ggplot2)
minosse.plot(cap_minosse_res)








