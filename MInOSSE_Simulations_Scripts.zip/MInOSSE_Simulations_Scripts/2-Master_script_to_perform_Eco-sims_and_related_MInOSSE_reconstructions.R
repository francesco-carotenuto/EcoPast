# The following code lines perform the creation of artificial species to be used 
# to test MInOSSE's performance. In details, by this script, we simulate species 
# that mimic the climatic preferences of real past species. To this aim our simulations 
# are based on the real record of large mammalian species that lived in the Eurasian 
# continent during the Last Glacial Maximum. The fossil record is combined with LGM 
# climatic variables (downloaded from www.worldclim.org) in order to # derive past 
# species climatic preferences and then, these preferences are used to simualte new 
# species spatial distribution. The algorithm to generate the simulated species is 
# the Artificial Bell Respose discussed in Varela et al. (2014). The Artificial Bell
# Response algorithm creates maps of suitability index built upon the species climatic
# preferences and we used these maps to generate species'populations inside a geographic
# domain (the Eurasia continent). For each simulated species, we computed the occpupancy
# maps that we used as species'geographic ranges. These geographic distribution 
# were considered as the actual realized geographic ranges of the simulated species.
# The successive step was to simulate a fossilization process in order to create a
# fossil record from these species with the aim of running MInOSSE with this record
# and reconstruct the original actual species'geographic ranges. After generating 
# the actual species'gepgraphic ranges, we simulated a spatial distribution of fossil 
# localities. In this particular scenario, we used the density distribution of the 
# same LGM fossil mammal occurrences dataset in order the generate the most realistic
# spatial distribution of fossil localities. These simulated fossil localities were,
# then, overlapped on the actual simulated species ranges in order to extract the identity
# of species there occurring. After generating a species list,
# for each fossil localities, we simulated a fossilization bias by removing for 
# each sampled species, from the 50 to the 80% of its occurrences in the fossil 
# localites. The removal of species occurrences was not random but was proportional
# to the simulated actual species geographic ranges, in order to give higher occurrence
# probability to the very wide and abundant species, as it happens in the real fossil
# record. We used these simulated species in order to run MInOSSE with several 
# parametes'settings. In details. we tested if reducing the number of predictors
# (and hence reducing compuntational time) by means of co-occurence analysis badly
# impacted the performance of MInOSSE in predicting the simulated actual species'geographic
# ranges. Additionally, as MInOSSE to run needs the setting of a spatial resolution
# to properly perform Kriging interpolations and Regression Kriging algorithms,
# we used these simulations to test if MInOSSE correctly estimated the simulated 
# actual species'geographic ranges by using different spatial resolutions.
# Please, refer the paper Carotenuto et al.... and the related supplementary Information for details about simulations.







#### This is the main script that runs all at once all the Eco-sims as described in the main manuscript
# and performs the related MInOSSE geographic ranges reconstrictions. The user has to install the required
# packages (described below) and enter the path to the folder where appendices are stored ("appendices_folder")
# and where to store all the simulations results (my.path). An additional parameter to set is the number of 
# folds for AUC-based cross-validations. A default parameter is n.folds=1, which speeds up MInOSSE 
# predictions without affecting any result but the AUC computation (see below).

rm(list=ls(all=TRUE))

# WARNING! EcoPast (GPL-2) relies on some functions provided by other packages. Some of these packages cannot be directly installed along with EcoPast because they are distributed under different license types. Please notice, before installing EcoPast, make sure you have installed the following packages:
#  SDMTools (last version) available at https://cran.r-project.org/src/contrib/Archive/SDMTools/.
# chronosphere and rangeBuilder, available on CRAN, can be installed by means of the common installation procedure in R.

library(devtools)
install.packages(c("chronosphere","rangeBuilder","sdmvspecies","rgeos","scales","KernSmooth"))
install_github("francesco-carotenuto/EcoPast")

library(EcoPast)
library(raster)
library(sdmvspecies)
library(foreach)
library(doSNOW)
library(doParallel)
library(rgeos)
library(scales)
library(KernSmooth)
library(dismo)


#### General setting ####
memory.size(max=TRUE)
#### Enter the path to the folder where you stored all appendices
appendices_folder<-"C:/MInOSSE_Simulations_Scripts/R_Appendices/" # ending slash required!
appendices_folder_RANDOM<-"C:/MInOSSE_Simulations_Scripts/RFM_RANDOM_Appendices/" # ending slash required!
appendices_folder_CLUSTERED<-"C:/MInOSSE_Simulations_Scripts/RFM_CLUSTERED_Appendices/" # ending slash required!



#### Enter the path where you want to store all the simulations ####
my.path<-"C:/MInOSSE_Simulations_Scripts/R_Tests_minosse/"  # ending slash required!
my.path_RANDOM<-"C:/MInOSSE_Simulations_Scripts/RFM_RANDOM_Tests_minosse/"  # ending slash required!
my.path_CLUSTERED<-"C:/MInOSSE_Simulations_Scripts/RFM_CLUSTERED_Tests_minosse/"  # ending slash required!

#### this is the path of the folder where to store 100 species and 100 fossil localities simulations used to run MInOSSE with cooccurrence analysis ####
dir.path<-paste(my.path,"eco-sims/coc_loc/",sep="") # Do not change this line!
dir.create(dir.path, showWarnings = TRUE, recursive = TRUE)

dir.path_RANDOM<-paste(my.path_RANDOM,"eco-sims/coc_loc/",sep="") # Do not change this line!
dir.create(dir.path_RANDOM, showWarnings = TRUE, recursive = TRUE)

dir.path_CLUSTERED<-paste(my.path_CLUSTERED,"eco-sims/coc_loc/",sep="") # Do not change this line!
dir.create(dir.path_CLUSTERED, showWarnings = TRUE, recursive = TRUE)



#### this is the path of the folder where to store 100 species and 100 fossil localities simulations used to run MInOSSE without cooccurrence analysis ####
dir.path_no_coc<-paste(my.path,"eco-sims/no_coc/",sep="") # Do not change this line!
dir.create(dir.path_no_coc, showWarnings = TRUE, recursive = TRUE)

dir.path_no_coc_RANDOM<-paste(my.path_RANDOM,"eco-sims/no_coc/",sep="") # Do not change this line!
dir.create(dir.path_no_coc_RANDOM, showWarnings = TRUE, recursive = TRUE)

dir.path_no_coc_CLUSTERED<-paste(my.path_CLUSTERED,"eco-sims/no_coc/",sep="") # Do not change this line!
dir.create(dir.path_no_coc_CLUSTERED, showWarnings = TRUE, recursive = TRUE)

#### Download LGM time period bioclimatic variables and store files into "my.path" folder ####
# This files are used to extract climatic variables at simulated fossil sites to generate 
# ecologically and climatically plausible virtual species simulations (see the main manuscript). 
download.file("http://biogeo.ucdavis.edu/data/climate/cmip5/lgm/cclgmbi_10m.zip", paste(my.path,"cclgmbi_10m.zip",sep=""))
unzip(zipfile=paste(my.path,"cclgmbi_10m.zip",sep=""),exdir=paste(my.path,"LGM",sep=""))

download.file("http://biogeo.ucdavis.edu/data/climate/cmip5/lgm/cclgmbi_10m.zip", paste(my.path_RANDOM,"cclgmbi_10m.zip",sep=""))
unzip(zipfile=paste(my.path_RANDOM,"cclgmbi_10m.zip",sep=""),exdir=paste(my.path_RANDOM,"LGM",sep=""))

download.file("http://biogeo.ucdavis.edu/data/climate/cmip5/lgm/cclgmbi_10m.zip", paste(my.path,"cclgmbi_10m.zip",sep=""))
unzip(zipfile=paste(my.path_CLUSTERED,"cclgmbi_10m.zip",sep=""),exdir=paste(my.path_CLUSTERED,"LGM",sep=""))




#### Set the number of folds for AUC-based cross-validations of MInOSSE models.
# AUC-based cross-validations are additional analyses we allow to perform to test MInOSSE models performance
# and that add to the internal 5-folds cross-validation of Regression Kriging model performance measure.
# AUC-based cross-validations increase MInOSSE computational time as each pseudo-absences simulation 
# (default number = 10) is repeated as many times as the folds' number. As a consequence, we set 1 fold to 
# speed up MInOSSE, but the AUC values presented in the main manuscript (and related supplementary 
# informations) are based on a 5 folds AUC-based cross-validation procedure (see the main text).

n.folds<-1


clus_num<-10 # set the number of clusters to use for parallel computation. You can set "automatic" in order to 
                      # allow MInOSSE using all the available clusters minus 1 








#### LGM-based fossil localities simulations ####
# The following code lines are used to simulate actual species geographic ranges and to run MInOSSE by using the co-occurrence analysis and by considering different cell resolution for spatial reconstructions.
#### By using cooccurrence analysis ####
##  with average nearest neighbours distance as interpolation cell resolution ##
#rm(list=ls(all=TRUE)[-which(ls(all=TRUE)%in%c("appendices_folder","my.path","dir.path","dir.path_no_coc"))])
source(paste(appendices_folder,"eco_sims_coc_loc_mean.R",sep=""))
gc()

## with half of average nearest neighbours distance as interpolation cell resolution ##
rm(list=ls(all=TRUE)[-which(ls(all=TRUE)%in%c("clus_num","appendices_folder","my.path","dir.path","dir.path_no_coc","n.folds"))])
source(paste(appendices_folder,"eco_sims_coc_loc_semimean.R",sep=""))
gc() # 

## with 100x100 km as interpolation cell resolution ##
rm(list=ls(all=TRUE)[-which(ls(all=TRUE)%in%c("clus_num","appendices_folder","my.path","dir.path","dir.path_no_coc","n.folds"))])
source(paste(appendices_folder,"eco_sims_coc_loc_100km.R",sep=""))
gc() # 

## with 200x200 km as interpolation cell resolution ##
rm(list=ls(all=TRUE)[-which(ls(all=TRUE)%in%c("clus_num","appendices_folder","my.path","dir.path","dir.path_no_coc","n.folds"))])
source(paste(appendices_folder,"eco_sims_coc_loc_200km.R",sep=""))
gc()

## with 300x300 km as interpolation cell resolution ##
rm(list=ls(all=TRUE)[-which(ls(all=TRUE)%in%c("clus_num","appendices_folder","my.path","dir.path","dir.path_no_coc","n.folds"))])
source(paste(appendices_folder,"eco_sims_coc_loc_300km.R",sep=""))
gc()





#### Without cooccurrence analysis ####
# The following code lines are used to simulate actual species geographic ranges and to run MInOSSE without using the co-occurrence analysis and by considering different cell resolution for spatial reconstructions.
##  with average nearest neighbours distance as interpolation cell resolution ##
rm(list=ls(all=TRUE)[-which(ls(all=TRUE)%in%c("clus_num","appendices_folder","my.path","dir.path","dir.path_no_coc","n.folds"))])
source(paste(appendices_folder,"eco_sims_no_coc_mean.R",sep=""))
gc()

## with half of average nearest neighbours distance as interpolation cell resolution ##
rm(list=ls(all=TRUE)[-which(ls(all=TRUE)%in%c("clus_num","appendices_folder","my.path","dir.path","dir.path_no_coc","n.folds"))])
source(paste(appendices_folder,"eco_sims_no_coc_semimean.R",sep=""))
gc()

## with 100x100 km as interpolation cell resolution ##
rm(list=ls(all=TRUE)[-which(ls(all=TRUE)%in%c("clus_num","appendices_folder","my.path","dir.path","dir.path_no_coc","n.folds"))])
source(paste(appendices_folder,"eco_sims_no_coc_100km.R",sep=""))
gc()

## with 200x200 km as interpolation cell resolution ##
rm(list=ls(all=TRUE)[-which(ls(all=TRUE)%in%c("clus_num","appendices_folder","my.path","dir.path","dir.path_no_coc","n.folds"))])
source(paste(appendices_folder,"eco_sims_no_coc_200km.R",sep=""))
gc()

## with 300x300 km as interpolation cell resolution ##
rm(list=ls(all=TRUE)[-which(ls(all=TRUE)%in%c("clus_num","appendices_folder","my.path","dir.path","dir.path_no_coc","n.folds"))])
source(paste(appendices_folder,"eco_sims_no_coc_300km.R",sep=""))
gc()






#### Randomly distributed fossil localities ####
#### By using cooccurrence analysis ####
##  with average nearest neighbours distance as interpolation cell resolution ##
#rm(list=ls(all=TRUE)[-which(ls(all=TRUE)%in%c("appendices_folder","my.path","dir.path","dir.path_no_coc"))])
rm(list=ls(all=TRUE)[-which(ls(all=TRUE)%in%c("clus_num","appendices_folder_RANDOM","my.path_RANDOM","dir.path_RANDOM","dir.path_no_coc_RANDOM","n.folds"))])
source(paste(appendices_folder_RANDOM,"eco_sims_coc_loc_mean.R",sep=""))
gc() # 15:59 28/10/2019

## with half of average nearest neighbours distance as interpolation cell resolution ##
rm(list=ls(all=TRUE)[-which(ls(all=TRUE)%in%c("clus_num","appendices_folder_RANDOM","my.path_RANDOM","dir.path_RANDOM","dir.path_no_coc_RANDOM","n.folds"))])
source(paste(appendices_folder_RANDOM,"eco_sims_coc_loc_semimean.R",sep=""))
gc() # 

## with 100x100 km as interpolation cell resolution ##
rm(list=ls(all=TRUE)[-which(ls(all=TRUE)%in%c("clus_num","appendices_folder_RANDOM","my.path_RANDOM","dir.path_RANDOM","dir.path_no_coc_RANDOM","n.folds"))])
source(paste(appendices_folder_RANDOM,"eco_sims_coc_loc_100km.R",sep=""))
gc() # 

## with 200x200 km as interpolation cell resolution ##
rm(list=ls(all=TRUE)[-which(ls(all=TRUE)%in%c("clus_num","appendices_folder_RANDOM","my.path_RANDOM","dir.path_RANDOM","dir.path_no_coc_RANDOM","n.folds"))])
source(paste(appendices_folder_RANDOM,"eco_sims_coc_loc_200km.R",sep=""))
gc()

## with 300x300 km as interpolation cell resolution ##
rm(list=ls(all=TRUE)[-which(ls(all=TRUE)%in%c("clus_num","appendices_folder_RANDOM","my.path_RANDOM","dir.path_RANDOM","dir.path_no_coc_RANDOM","n.folds"))])
source(paste(appendices_folder_RANDOM,"eco_sims_coc_loc_300km.R",sep=""))
gc()





#### Without cooccurrence analysis ####
##  with average nearest neighbours distance as interpolation cell resolution ##
rm(list=ls(all=TRUE)[-which(ls(all=TRUE)%in%c("clus_num","appendices_folder_RANDOM","my.path_RANDOM","dir.path_RANDOM","dir.path_no_coc_RANDOM","n.folds"))])
source(paste(appendices_folder_RANDOM,"eco_sims_no_coc_mean.R",sep=""))
gc()

## with half of average nearest neighbours distance as interpolation cell resolution ##
rm(list=ls(all=TRUE)[-which(ls(all=TRUE)%in%c("clus_num","appendices_folder_RANDOM","my.path_RANDOM","dir.path_RANDOM","dir.path_no_coc_RANDOM","n.folds"))])
source(paste(appendices_folder_RANDOM,"eco_sims_no_coc_semimean.R",sep=""))
gc()

## with 100x100 km as interpolation cell resolution ##
rm(list=ls(all=TRUE)[-which(ls(all=TRUE)%in%c("clus_num","appendices_folder_RANDOM","my.path_RANDOM","dir.path_RANDOM","dir.path_no_coc_RANDOM","n.folds"))])
source(paste(appendices_folder_RANDOM,"eco_sims_no_coc_100km.R",sep=""))
gc()

## with 200x200 km as interpolation cell resolution ##
rm(list=ls(all=TRUE)[-which(ls(all=TRUE)%in%c("clus_num","appendices_folder_RANDOM","my.path_RANDOM","dir.path_RANDOM","dir.path_no_coc_RANDOM","n.folds"))])
source(paste(appendices_folder_RANDOM,"eco_sims_no_coc_200km.R",sep=""))
gc()

## with 300x300 km as interpolation cell resolution ##
rm(list=ls(all=TRUE)[-which(ls(all=TRUE)%in%c("clus_num","appendices_folder_RANDOM","my.path_RANDOM","dir.path_RANDOM","dir.path_no_coc_RANDOM","n.folds"))])
source(paste(appendices_folder_RANDOM,"eco_sims_no_coc_300km.R",sep=""))
gc()






#### Clustered distribution of fossil localities####
#### By using cooccurrence analysis ####
##  with average nearest neighbours distance as interpolation cell resolution ##
#rm(list=ls(all=TRUE)[-which(ls(all=TRUE)%in%c("appendices_folder","my.path","dir.path","dir.path_no_coc"))])
rm(list=ls(all=TRUE)[-which(ls(all=TRUE)%in%c("clus_num","appendices_folder_CLUSTERED","my.path_CLUSTERED","dir.path_CLUSTERED","dir.path_no_coc_CLUSTERED","n.folds"))])
source(paste(appendices_folder_CLUSTERED,"eco_sims_coc_loc_mean.R",sep=""))
gc() # 15:59 28/10/2019

## with half of average nearest neighbours distance as interpolation cell resolution ##
rm(list=ls(all=TRUE)[-which(ls(all=TRUE)%in%c("clus_num","appendices_folder_CLUSTERED","my.path_CLUSTERED","dir.path_CLUSTERED","dir.path_no_coc_CLUSTERED","n.folds"))])
source(paste(appendices_folder_CLUSTERED,"eco_sims_coc_loc_semimean.R",sep=""))
gc() # 

## with 100x100 km as interpolation cell resolution ##
rm(list=ls(all=TRUE)[-which(ls(all=TRUE)%in%c("clus_num","appendices_folder_CLUSTERED","my.path_CLUSTERED","dir.path_CLUSTERED","dir.path_no_coc_CLUSTERED","n.folds"))])
source(paste(appendices_folder_CLUSTERED,"eco_sims_coc_loc_100km.R",sep=""))
gc() # 

## with 200x200 km as interpolation cell resolution ##
rm(list=ls(all=TRUE)[-which(ls(all=TRUE)%in%c("clus_num","appendices_folder_CLUSTERED","my.path_CLUSTERED","dir.path_CLUSTERED","dir.path_no_coc_CLUSTERED","n.folds"))])
source(paste(appendices_folder_CLUSTERED,"eco_sims_coc_loc_200km.R",sep=""))
gc()

## with 300x300 km as interpolation cell resolution ##
rm(list=ls(all=TRUE)[-which(ls(all=TRUE)%in%c("clus_num","appendices_folder_CLUSTERED","my.path_CLUSTERED","dir.path_CLUSTERED","dir.path_no_coc_CLUSTERED","n.folds"))])
source(paste(appendices_folder_CLUSTERED,"eco_sims_coc_loc_300km.R",sep=""))
gc()





#### Without cooccurrence analysis ####
##  with average nearest neighbours distance as interpolation cell resolution ##
rm(list=ls(all=TRUE)[-which(ls(all=TRUE)%in%c("clus_num","appendices_folder_CLUSTERED","my.path_CLUSTERED","dir.path_CLUSTERED","dir.path_no_coc_CLUSTERED","n.folds"))])
source(paste(appendices_folder_CLUSTERED,"eco_sims_no_coc_mean.R",sep=""))
gc()

## with half of average nearest neighbours distance as interpolation cell resolution ##
rm(list=ls(all=TRUE)[-which(ls(all=TRUE)%in%c("clus_num","appendices_folder_CLUSTERED","my.path_CLUSTERED","dir.path_CLUSTERED","dir.path_no_coc_CLUSTERED","n.folds"))])
source(paste(appendices_folder_CLUSTERED,"eco_sims_no_coc_semimean.R",sep=""))
gc()

## with 100x100 km as interpolation cell resolution ##
rm(list=ls(all=TRUE)[-which(ls(all=TRUE)%in%c("clus_num","appendices_folder_CLUSTERED","my.path_CLUSTERED","dir.path_CLUSTERED","dir.path_no_coc_CLUSTERED","n.folds"))])
source(paste(appendices_folder_CLUSTERED,"eco_sims_no_coc_100km.R",sep=""))
gc()

## with 200x200 km as interpolation cell resolution ##
rm(list=ls(all=TRUE)[-which(ls(all=TRUE)%in%c("clus_num","appendices_folder_CLUSTERED","my.path_CLUSTERED","dir.path_CLUSTERED","dir.path_no_coc_CLUSTERED","n.folds"))])
source(paste(appendices_folder_CLUSTERED,"eco_sims_no_coc_200km.R",sep=""))
gc()

## with 300x300 km as interpolation cell resolution ##
rm(list=ls(all=TRUE)[-which(ls(all=TRUE)%in%c("clus_num","appendices_folder_CLUSTERED","my.path_CLUSTERED","dir.path_CLUSTERED","dir.path_no_coc_CLUSTERED","n.folds"))])
source(paste(appendices_folder_CLUSTERED,"eco_sims_no_coc_300km.R",sep=""))
gc()
