#rm(list=ls(all=T))
#gc()



library(EcoPast)
library(spatstat)
library(rworldmap)
library(maptools)
library(rgdal) 
library(adehabitatLT)
library(sp)
library(raster)
library(foreach)
library(doSNOW)
library(doParallel) 
library(rgeos)

#### seed 1861, highly clustered spatial simulations ####
#### Create the folder where storing simulations with specific seeds####
rm(list=ls(all=TRUE)[-which(ls(all=TRUE)==dir.path_no_coc_100_200)]);setwd(dir.path_no_coc_100_200)
sim.dir<-"3-1861/"
dir.create(sim.dir, showWarnings = TRUE, recursive = TRUE) 

#### Simulations of species populations ####

spec_seed<-3 # the seed for populations simulations
loc_seed<-1861 # the seed for fossil localities generation
spec_num<-100 # number of species to simulate
locs_num<-200 # number of fossil localities to simulate
lon_0<-85 # longitude of equal area projection centre
lat_0<-45 # latitude of equal area projection centre
grid_size<-100000 # Grid resolution for simulated poipulations polygons
div<-1000 # the denominator for Ornstein-Uhlenbeck process for the spatial distribution of simulated populations 


#### Generatong the spatial polygon of Eurasia domain for spatial simulations #### 
my_proj<-CRS(paste("+proj=laea +lon_0=",lon_0," +lat_0=",lat_0," +x_0=0 +y_0=0 +ellps=WGS84 +units=m +no_defs",sep="")) 
data(countriesCoarseLessIslands)
data(countriesCoarseLessIslands)
eurasia<-countriesCoarseLessIslands[grep("Eurasia",countriesCoarseLessIslands$continent),]
eu<-unionSpatialPolygons(eurasia, cut(coordinates(eurasia)[,1], range(coordinates(eurasia)[,1]), include.lowest=F))
poly<-eu@polygons[[1]]@Polygons[47][[1]]@coords
poly<-as.matrix(poly)
Sr1 = Polygon(poly)
Srs1 = Polygons(list(Sr1), "s1")
SpP = SpatialPolygons(list(Srs1))
proj4string(SpP)<-CRS("+proj=longlat +ellps=WGS84 +datum=WGS84 +no_defs")
spTransform(SpP,CRS=my_proj)->SpP_prj

#### Generating the spatial distribution of populations' centres ####
set.seed(spec_seed)
origins<-spsample(SpP, spec_num,type="clustered",nclusters=100)
origins<-as.data.frame(origins)
data_ck<-origins
coordinates(data_ck)<-~x1+x2
#### Testing the hypothesis of a clustered spatial distribution of populations' centres ####
clarkevans.test(as(data_ck,"ppp"),alternative="clustered")

#### Generating the family of parameters for a Log2-Gaussian distribution of populations aboudances and a positive relationship between populations area and aboundance ####
set.seed(spec_seed)
acca<-rbeta(100,1,5)
range(acca)

length(acca)
set.seed(spec_seed)
abba<-sample(2^(rnorm(100,log(1000,2),log(1000,2)/10)),100)
sort(acca)->acca
sort(abba)->abba

#### Generating the species' populations ####
seed<-seq(1:100)
x_zero<-list()
brown.points<-list()
temp_sample<-list()
for(i in 1:100){
  set.seed(seed[i])
  x_zero[[i]]<-as.vector(origins[sample(as.numeric(rownames(origins)),1),])
  set.seed(seed[i])
  brown.points[[i]]<-simm.mou(date=1:abba[i] ,b=c(sample(seq(from=x_zero[[i]]$x1,to=x_zero[[i]]$x1+(5),by=1),1),sample(seq(from=x_zero[[i]]$x2,to=x_zero[[i]]$x2+(5),by=1),1)),a=diag(c(acca[i]/div,acca[i]/div)),x0=c(x_zero[[i]]$x1,x_zero[[i]]$x2)) 
  brown.points[[i]]<-brown.points[[i]][[1]][,1:2]
  temp_sample[[i]]<-brown.points[[i]]
  try(temp_sample[[i]]<-cbind(temp_sample[[i]], paste("spec", i, sep="")),silent=F)
  print(i)
}

gc()


#### Generating actual species' geographic ranges polygons ####
temp_population<-list()
pops<-list()
for(i in 1:100){
  try(colnames(temp_sample[[i]])[3]<-"spec",silent=F)
  try(temp_population[[i]]<-temp_sample[[i]][which(point.in.polygon(temp_sample[[i]]$x,temp_sample[[i]]$y, SpP@polygons[[1]]@Polygons[[1]]@coords[,1],SpP@polygons[[1]]@Polygons[[1]]@coords[,2])>0),],silent=F)
  try(coordinates(temp_population[[i]])<-~x+y,silent=F)
  try(proj4string(temp_population[[i]])<-CRS("+proj=longlat +ellps=WGS84 +datum=WGS84 +no_defs"),silent=F)
  try(pops[[i]]<-temp_population[[i]][SpP,],silent=F)
  print(i)
}

populations<-do.call(rbind, pops)
spTransform(populations,CRS=my_proj)->prj_populations
extent(prj_populations)[1:2]->x_lim
extent(prj_populations)[3:4]->y_lim
sampling_grid<-expand.grid(x=seq(from=x_lim[1],to=x_lim[2],grid_size),y=seq(from=y_lim[1],to=y_lim[2],grid_size))
sampling_grid->prediction_ground
prediction_ground$z<-1
rasterFromXYZ(prediction_ground)->prediction_ground
crs(prediction_ground)<-my_proj
mask(prediction_ground,SpP_prj)->prediction_ground
coordinates(sampling_grid)<-~x+y
gridded(sampling_grid)<-TRUE
crs(sampling_grid)<-my_proj
as(sampling_grid,"SpatialPolygons")->sampling_grid
lapply(pops,function(x)spTransform(x,CRS=my_proj))->prj_pops


cl <- makeCluster(2, type="SOCK")
registerDoSNOW (cl)
foreach(i=1:length(prj_pops),.packages=c("raster")) %dopar% {
  over(prj_pops[[i]],sampling_grid)->original_over_res
}->original_over_res
stopCluster(cl)
doParallel::stopImplicitCluster()

lapply(original_over_res,function(x){sampling_grid[unique(x)[!is.na(unique(x))]]->x;
  return(x)})->real_poly
for(i in 1:length(real_poly)) {
  rgeos::gUnaryUnion(real_poly[[i]])->real_poly[[i]]
  print(i)
}

sapply(real_poly,function(x)gArea(x))->areas
sapply(pops,function(x)length(x))->abundance


lapply(pops,function(x)unique(as.character(x$spec)))->pops_names
names(pops)<-pops_names
names(prj_pops)<-pops_names
names(real_poly)<-pops_names


#### Generating the spatial distribution of fossil localities and using then to sample actual simulated species geographic ranges ####
set.seed(loc_seed)
sim_locs<-spsample(SpP_prj,locs_num,type = "clustered",nclusters=50)

lapply(real_poly,function(x){
  over(x,sim_locs,returnList=TRUE)  
})->over_res
which(sapply(over_res,function(x)length(x[[1]])!=0))->valid_specs
over_res[valid_specs]->over_res
over_res<-mapply(function(x,y) {data.frame(x,spec=rep(y,length(x)))->z;
  return(z)},over_res,names(over_res),SIMPLIFY = FALSE)
lapply(over_res,function(x){sim_locs[x$X1,]->z;
  z$loc_id<-x$X1;
  return(z)})->over_res
over_res<-mapply(function(x,y) { as.data.frame(x)->x;
  x$spec<-y;
  return(x)}, over_res,names(over_res),SIMPLIFY = FALSE )

over_res<-do.call(rbind,over_res)
rownames(over_res)<-NULL
colnames(over_res)[2:3]<-c("x","y")

coordinates(over_res)<-~x+y
crs(over_res)<-my_proj
over_res->general_sim_dat
spTransform(general_sim_dat,CRS=CRS("+proj=longlat +datum=WGS84"))->general_sim_dat
general_sim_dat<-as.data.frame(general_sim_dat)
as.character(general_sim_dat$spec)->general_sim_dat$spec
general_sim_dat->general_sim_locs
general_sim_locs$age<-1

#### Randomly subsetting species lists of each fossil locality to simulate taphonomic biases ####
set.seed(2047)
summary(to_rem<-round(rnorm(length(unique(general_sim_locs$loc_id)), mean=30,sd=10)))
id_list<-unique(general_sim_locs$loc_id)

reduce_list<-function(x,y,seed){
  to_keep<-sample(which(general_sim_locs$loc_id%in%x),round(length(which(general_sim_locs$loc_id%in%x))*((100-y)/100)))
  reduced_general_sim_locs<-general_sim_locs[to_keep,]
  return(reduced_general_sim_locs)
}

reduced_general_sim_locs<-mapply(function(x,y) reduce_list(x,y,seed=39), id_list, to_rem,SIMPLIFY=FALSE )
reduced_general_sim_locs<-do.call(rbind,reduced_general_sim_locs)
rownames(reduced_general_sim_locs)<-NULL



#### Performing MInOSSE ####
Sys.getenv("R_MAX_NUM_DLLs", unset = NA)
unique(as.character(reduced_general_sim_locs$spec))->spec_list
minosse_dat<-list()
minosse_res_list<-list()
for(i in 1:length(spec_list)){
  if(class(try(minosse_dat[[i]]<-minosse.data(
    obj=reduced_general_sim_locs,
    species_name=spec_list[i],
    domain="land",
    coc.by=NULL,
    min.occs=3,
    abiotic.covs=NULL,
    combine.covs=FALSE,   
    reduce_covs_by="pca",
    covs_th=0.95,
    c.size=100000,
    bkg.predictors="presence", 
    min.bkg=100,
    sampling.by.distance=TRUE,
    prediction.ground=prediction_ground,
    crop.by.mcp=FALSE,
    projection="laea",
    lon_0=85,
    lat_0=45,
    n.clusters="automatic", 
    seed=625)
  ))=="try-error") {next} else {minosse_dat[[i]]<-minosse_dat[[i]];
  
  
  if(class(try(minosse_res_list[[i]]<-minosse.target(
    resp=minosse_dat[[i]][[1]],
    predictors=minosse_dat[[i]][[2]],
    bkg="presence",
    min.bkg = 100,
    n.sims=10,
    sampling.by.distance=TRUE,
    n.folds=n.folds,
    n.sims.clusters="automatic",
    seed=625)))=="try-error") {next} else minosse_res_list[[i]]<-minosse_res_list[[i]] 
  }
  print(i)
}
gc()

#### save ####
save.image(paste(sim.dir,"200_100_clus_max_3_1861_no_coc.RData",sep=""))
##
###





#### seed 1861,  moderately clustered spatial simulations ####
rm(list=ls(all=TRUE)[-which(ls(all=TRUE)==dir.path_no_coc_100_200)]);setwd(dir.path_no_coc_100_200)
sim.dir<-"3-1861/"
dir.create(sim.dir, showWarnings = TRUE, recursive = TRUE) 

spec_seed<-3
loc_seed<-1861
spec_num<-100
locs_num<-200
lon_0<-85
lat_0<-45
my_proj<-CRS(paste("+proj=laea +lon_0=",lon_0," +lat_0=",lat_0," +x_0=0 +y_0=0 +ellps=WGS84 +units=m +no_defs",sep="")) 
grid_size<-100000
div<-1000

data(countriesCoarseLessIslands)
data(countriesCoarseLessIslands)
eurasia<-countriesCoarseLessIslands[grep("Eurasia",countriesCoarseLessIslands$continent),]
eu<-unionSpatialPolygons(eurasia, cut(coordinates(eurasia)[,1], range(coordinates(eurasia)[,1]), include.lowest=F))
poly<-eu@polygons[[1]]@Polygons[47][[1]]@coords
poly<-as.matrix(poly)
Sr1 = Polygon(poly)
Srs1 = Polygons(list(Sr1), "s1")
SpP = SpatialPolygons(list(Srs1))
proj4string(SpP)<-CRS("+proj=longlat +ellps=WGS84 +datum=WGS84 +no_defs")
spTransform(SpP,CRS=my_proj)->SpP_prj

set.seed(spec_seed)
origins<-spsample(SpP, spec_num,type="clustered",nclusters=150)
origins<-as.data.frame(origins)
data_ck<-origins
coordinates(data_ck)<-~x1+x2
clarkevans.test(as(data_ck,"ppp"),alternative="clustered")

set.seed(spec_seed)
acca<-rbeta(100,1,5)
range(acca)

length(acca)
set.seed(spec_seed)
abba<-sample(2^(rnorm(100,log(1000,2),log(1000,2)/10)),100)
sort(acca)->acca
sort(abba)->abba

seed<-seq(1:100)
x_zero<-list()
brown.points<-list()
temp_sample<-list()
for(i in 1:100){
  set.seed(seed[i])
  x_zero[[i]]<-as.vector(origins[sample(as.numeric(rownames(origins)),1),])
  set.seed(seed[i])
  brown.points[[i]]<-simm.mou(date=1:abba[i] ,b=c(sample(seq(from=x_zero[[i]]$x1,to=x_zero[[i]]$x1+(5),by=1),1),sample(seq(from=x_zero[[i]]$x2,to=x_zero[[i]]$x2+(5),by=1),1)),a=diag(c(acca[i]/div,acca[i]/div)),x0=c(x_zero[[i]]$x1,x_zero[[i]]$x2)) 
  brown.points[[i]]<-brown.points[[i]][[1]][,1:2]
  temp_sample[[i]]<-brown.points[[i]]
  try(temp_sample[[i]]<-cbind(temp_sample[[i]], paste("spec", i, sep="")),silent=F)
  print(i)
}
gc()

temp_population<-list()
pops<-list()
for(i in 1:nrow(origins)){
  try(colnames(temp_sample[[i]])[3]<-"spec",silent=F)
  try(temp_population[[i]]<-temp_sample[[i]][which(point.in.polygon(temp_sample[[i]]$x,temp_sample[[i]]$y, SpP@polygons[[1]]@Polygons[[1]]@coords[,1],SpP@polygons[[1]]@Polygons[[1]]@coords[,2])>0),],silent=F)
  try(coordinates(temp_population[[i]])<-~x+y,silent=F)
  try(proj4string(temp_population[[i]])<-CRS("+proj=longlat +ellps=WGS84 +datum=WGS84 +no_defs"),silent=F)
  try(pops[[i]]<-temp_population[[i]][SpP,],silent=F)
  print(i)
}

populations<-do.call(rbind, pops)
spTransform(populations,CRS=my_proj)->prj_populations
extent(prj_populations)[1:2]->x_lim
extent(prj_populations)[3:4]->y_lim
sampling_grid<-expand.grid(x=seq(from=x_lim[1],to=x_lim[2],grid_size),y=seq(from=y_lim[1],to=y_lim[2],grid_size))
sampling_grid->prediction_ground
prediction_ground$z<-1
rasterFromXYZ(prediction_ground)->prediction_ground
crs(prediction_ground)<-my_proj
mask(prediction_ground,SpP_prj)->prediction_ground
coordinates(sampling_grid)<-~x+y
gridded(sampling_grid)<-TRUE
crs(sampling_grid)<-my_proj
as(sampling_grid,"SpatialPolygons")->sampling_grid
lapply(pops,function(x)spTransform(x,CRS=my_proj))->prj_pops

cl <- makeCluster(2, type="SOCK")
registerDoSNOW (cl)
foreach(i=1:length(prj_pops),.packages=c("raster")) %dopar% {
  over(prj_pops[[i]],sampling_grid)->original_over_res
}->original_over_res
stopCluster(cl)
doParallel::stopImplicitCluster()
##

lapply(original_over_res,function(x){sampling_grid[unique(x)[!is.na(unique(x))]]->x;
  return(x)})->real_poly

for(i in 1:length(real_poly)) {
  rgeos::gUnaryUnion(real_poly[[i]])->real_poly[[i]]
  print(i)
}
##

sapply(real_poly,function(x)gArea(x))->areas

lapply(pops,function(x)unique(as.character(x$spec)))->pops_names
names(pops)<-pops_names
names(prj_pops)<-pops_names
names(real_poly)<-pops_names

set.seed(loc_seed)
sim_locs<-spsample(SpP_prj,locs_num,type = "clustered",nclusters=90)

lapply(real_poly,function(x){
  over(x,sim_locs,returnList=TRUE)  
})->over_res
which(sapply(over_res,function(x)length(x[[1]])!=0))->valid_specs
over_res[valid_specs]->over_res
over_res<-mapply(function(x,y) {data.frame(x,spec=rep(y,length(x)))->z;
  return(z)},over_res,names(over_res),SIMPLIFY = FALSE)
lapply(over_res,function(x){sim_locs[x$X1,]->z;
  z$loc_id<-x$X1;
  return(z)})->over_res
over_res<-mapply(function(x,y) { as.data.frame(x)->x;
  x$spec<-y;
  return(x)}, over_res,names(over_res),SIMPLIFY = FALSE )
over_res<-do.call(rbind,over_res)
rownames(over_res)<-NULL
colnames(over_res)[2:3]<-c("x","y")
coordinates(over_res)<-~x+y
crs(over_res)<-my_proj
over_res->general_sim_dat
spTransform(general_sim_dat,CRS=CRS("+proj=longlat +datum=WGS84"))->general_sim_dat
general_sim_dat<-as.data.frame(general_sim_dat)
as.character(general_sim_dat$spec)->general_sim_dat$spec
general_sim_dat->general_sim_locs
general_sim_locs$age<-1

set.seed(2047)
summary(to_rem<-round(rnorm(length(unique(general_sim_locs$loc_id)), mean=30,sd=10)))
id_list<-unique(general_sim_locs$loc_id)
reduce_list<-function(x,y,seed){
  to_keep<-sample(which(general_sim_locs$loc_id%in%x),round(length(which(general_sim_locs$loc_id%in%x))*((100-y)/100)))
  reduced_general_sim_locs<-general_sim_locs[to_keep,]
  return(reduced_general_sim_locs)
}

reduced_general_sim_locs<-mapply(function(x,y) reduce_list(x,y,seed=39), id_list, to_rem,SIMPLIFY=FALSE )
reduced_general_sim_locs<-do.call(rbind,reduced_general_sim_locs)
rownames(reduced_general_sim_locs)<-NULL

#### Performing MInOSSE ####
Sys.getenv("R_MAX_NUM_DLLs", unset = NA)
unique(as.character(reduced_general_sim_locs$spec))->spec_list
minosse_dat<-list()
minosse_res_list<-list()
for(i in 1:length(spec_list)){
  if(class(try(minosse_dat[[i]]<-minosse.data(
    obj=reduced_general_sim_locs,
    species_name=spec_list[i],
    domain="land",
    coc.by=NULL,
    min.occs=3,
    abiotic.covs=NULL,
    combine.covs=FALSE,   
    reduce_covs_by="pca",
    covs_th=0.95,
    c.size=100000,
    bkg.predictors="presence", 
    min.bkg=100,
    sampling.by.distance=TRUE,
    prediction.ground=prediction_ground,
    crop.by.mcp=FALSE,
    projection="laea",
    lon_0=85,
    lat_0=45,
    n.clusters="automatic", 
    seed=625)
  ))=="try-error") {next} else {minosse_dat[[i]]<-minosse_dat[[i]];
  
  
  if(class(try(minosse_res_list[[i]]<-minosse.target(
    resp=minosse_dat[[i]][[1]],
    predictors=minosse_dat[[i]][[2]],
    bkg="presence",
    min.bkg = 100,
    n.sims=10,
    sampling.by.distance=TRUE,
    n.folds=n.folds,
    n.sims.clusters="automatic",
    seed=625)))=="try-error") {next} else minosse_res_list[[i]]<-minosse_res_list[[i]] 
  }
  print(i)
}
gc()

#### save ####
save.image(paste(sim.dir,"200_100_clus_min_3_1861_no_coc.RData",sep=""))
##






#### seed 1861,  randomly distributed spatial simulations ####
rm(list=ls(all=TRUE)[-which(ls(all=TRUE)==dir.path_no_coc_100_200)]);setwd(dir.path_no_coc_100_200)
sim.dir<-"3-1861/"
dir.create(sim.dir, showWarnings = TRUE, recursive = TRUE) 

spec_seed<-3
loc_seed<-1861
spec_num<-100
locs_num<-200
lon_0<-85
lat_0<-45
my_proj<-CRS(paste("+proj=laea +lon_0=",lon_0," +lat_0=",lat_0," +x_0=0 +y_0=0 +ellps=WGS84 +units=m +no_defs",sep="")) 
grid_size<-100000
div<-1000

data(countriesCoarseLessIslands)
data(countriesCoarseLessIslands)
eurasia<-countriesCoarseLessIslands[grep("Eurasia",countriesCoarseLessIslands$continent),]
eu<-unionSpatialPolygons(eurasia, cut(coordinates(eurasia)[,1], range(coordinates(eurasia)[,1]), include.lowest=F))
poly<-eu@polygons[[1]]@Polygons[47][[1]]@coords
poly<-as.matrix(poly)
Sr1 = Polygon(poly)
Srs1 = Polygons(list(Sr1), "s1")
SpP = SpatialPolygons(list(Srs1))
proj4string(SpP)<-CRS("+proj=longlat +ellps=WGS84 +datum=WGS84 +no_defs")
spTransform(SpP,CRS=my_proj)->SpP_prj


set.seed(spec_seed)
origins<-spsample(SpP, spec_num,type="random")
origins<-as.data.frame(origins)

data_ck<-origins
coordinates(data_ck)<-~x+y
clarkevans.test(as(data_ck,"ppp"),alternative="clustered")

set.seed(spec_seed)
acca<-rbeta(100,1,5)
range(acca)

length(acca)
set.seed(spec_seed)
abba<-sample(2^(rnorm(100,log(1000,2),log(1000,2)/10)),100)
sort(acca)->acca
sort(abba)->abba

seed<-seq(1:100)
x_zero<-list()
brown.points<-list()
temp_sample<-list()
for(i in 1:100){
  set.seed(seed[i])
  x_zero[[i]]<-as.vector(origins[sample(as.numeric(rownames(origins)),1),])
  set.seed(seed[i])
  brown.points[[i]]<-simm.mou(date=1:abba[i],b=c(sample(seq(from=x_zero[[i]]$x,to=x_zero[[i]]$x+(5),by=1),1),sample(seq(from=x_zero[[i]]$y,to=x_zero[[i]]$y+(5),by=1),1)),a=diag(c(acca[i]/div,acca[i]/div)),x0=c(x_zero[[i]]$x,x_zero[[i]]$y)) 
  brown.points[[i]]<-brown.points[[i]][[1]][,1:2]
  temp_sample[[i]]<-brown.points[[i]]
  try(temp_sample[[i]]<-cbind(temp_sample[[i]], paste("spec", i, sep="")),silent=F)
  print(i)
}

gc()

temp_population<-list()
pops<-list()
for(i in 1:nrow(origins)){
  try(colnames(temp_sample[[i]])[3]<-"spec",silent=F)
  try(temp_population[[i]]<-temp_sample[[i]][which(point.in.polygon(temp_sample[[i]]$x,temp_sample[[i]]$y, SpP@polygons[[1]]@Polygons[[1]]@coords[,1],SpP@polygons[[1]]@Polygons[[1]]@coords[,2])>0),],silent=F)
  try(coordinates(temp_population[[i]])<-~x+y,silent=F)
  try(proj4string(temp_population[[i]])<-CRS("+proj=longlat +ellps=WGS84 +datum=WGS84 +no_defs"),silent=F)
  try(pops[[i]]<-temp_population[[i]][SpP,],silent=F)
  print(i)
}

populations<-do.call(rbind, pops)
spTransform(populations,CRS=my_proj)->prj_populations
extent(prj_populations)[1:2]->x_lim
extent(prj_populations)[3:4]->y_lim

sampling_grid<-expand.grid(x=seq(from=x_lim[1],to=x_lim[2],grid_size),y=seq(from=y_lim[1],to=y_lim[2],grid_size))
sampling_grid->prediction_ground
prediction_ground$z<-1
rasterFromXYZ(prediction_ground)->prediction_ground
crs(prediction_ground)<-my_proj
mask(prediction_ground,SpP_prj)->prediction_ground
coordinates(sampling_grid)<-~x+y
gridded(sampling_grid)<-TRUE
crs(sampling_grid)<-my_proj
as(sampling_grid,"SpatialPolygons")->sampling_grid
lapply(pops,function(x)spTransform(x,CRS=my_proj))->prj_pops

cl <- makeCluster(2, type="SOCK")
registerDoSNOW (cl)
foreach(i=1:length(prj_pops),.packages=c("raster")) %dopar% {
  over(prj_pops[[i]],sampling_grid)->original_over_res
}->original_over_res
stopCluster(cl)
doParallel::stopImplicitCluster()
##

lapply(original_over_res,function(x){sampling_grid[unique(x)[!is.na(unique(x))]]->x;
  return(x)})->real_poly
for(i in 1:length(real_poly)) {
  rgeos::gUnaryUnion(real_poly[[i]])->real_poly[[i]]
  print(i)
}
##

sapply(real_poly,function(x)gArea(x))->areas
lapply(pops,function(x)unique(as.character(x$spec)))->pops_names
names(pops)<-pops_names
names(prj_pops)<-pops_names
names(real_poly)<-pops_names


set.seed(loc_seed)
sim_locs<-spsample(SpP_prj,locs_num,type = "random")

lapply(real_poly,function(x){
  over(x,sim_locs,returnList=TRUE)  
})->over_res
which(sapply(over_res,function(x)length(x[[1]])!=0))->valid_specs
over_res[valid_specs]->over_res
over_res<-mapply(function(x,y) {data.frame(x,spec=rep(y,length(x)))->z;
  return(z)},over_res,names(over_res),SIMPLIFY = FALSE)
lapply(over_res,function(x){sim_locs[x$X1,]->z;
  z$loc_id<-x$X1;
  return(z)})->over_res
over_res<-mapply(function(x,y) { as.data.frame(x)->x;
  x$spec<-y;
  return(x)}, over_res,names(over_res),SIMPLIFY = FALSE )
over_res<-do.call(rbind,over_res)
rownames(over_res)<-NULL
colnames(over_res)[2:3]<-c("x","y")
coordinates(over_res)<-~x+y
crs(over_res)<-my_proj
over_res->general_sim_dat
spTransform(general_sim_dat,CRS=CRS("+proj=longlat +datum=WGS84"))->general_sim_dat
general_sim_dat<-as.data.frame(general_sim_dat)
as.character(general_sim_dat$spec)->general_sim_dat$spec
general_sim_dat->general_sim_locs
general_sim_locs$age<-1

set.seed(2047)
summary(to_rem<-round(rnorm(length(unique(general_sim_locs$loc_id)), mean=30,sd=10)))
id_list<-unique(general_sim_locs$loc_id)
reduce_list<-function(x,y,seed){
  to_keep<-sample(which(general_sim_locs$loc_id%in%x),round(length(which(general_sim_locs$loc_id%in%x))*((100-y)/100)))
  reduced_general_sim_locs<-general_sim_locs[to_keep,]
  return(reduced_general_sim_locs)
}

reduced_general_sim_locs<-mapply(function(x,y) reduce_list(x,y,seed=39), id_list, to_rem,SIMPLIFY=FALSE )
reduced_general_sim_locs<-do.call(rbind,reduced_general_sim_locs)
rownames(reduced_general_sim_locs)<-NULL


#### Performing MInOSSE ####
Sys.getenv("R_MAX_NUM_DLLs", unset = NA)
unique(as.character(reduced_general_sim_locs$spec))->spec_list

minosse_dat<-list()
minosse_res_list<-list()
for(i in 1:length(spec_list)){
  if(class(try(minosse_dat[[i]]<-minosse.data(
    obj=reduced_general_sim_locs,
    species_name=spec_list[i],
    domain="land",
    coc.by=NULL,
    min.occs=3,
    abiotic.covs=NULL,
    combine.covs=FALSE,   
    reduce_covs_by="pca",
    covs_th=0.95,
    c.size=100000,
    bkg.predictors="presence", 
    min.bkg=100,
    sampling.by.distance=TRUE,
    prediction.ground=prediction_ground,
    crop.by.mcp=FALSE,
    projection="laea",
    lon_0=85,
    lat_0=45,
    n.clusters="automatic", 
    seed=625)
  ))=="try-error") {next} else {minosse_dat[[i]]<-minosse_dat[[i]];
  
  
  if(class(try(minosse_res_list[[i]]<-minosse.target(
    resp=minosse_dat[[i]][[1]],
    predictors=minosse_dat[[i]][[2]],
    bkg="presence",
    min.bkg = 100,
    n.sims=10,
    sampling.by.distance=TRUE,
    n.folds=n.folds,
    n.sims.clusters="automatic",
    seed=625)))=="try-error") {next} else minosse_res_list[[i]]<-minosse_res_list[[i]] 
  }
  print(i)
}
gc()

#### save ####
save.image(paste(sim.dir,"200_100_random_3_1861_no_coc.RData",sep=""))##
##





#### seed 1861,  uniformly distributed spatial simulations ####
rm(list=ls(all=TRUE)[-which(ls(all=TRUE)==dir.path_no_coc_100_200)]);setwd(dir.path_no_coc_100_200)
sim.dir<-"3-1861/"
dir.create(sim.dir, showWarnings = TRUE, recursive = TRUE) 

spec_seed<-3
loc_seed<-1861
spec_num<-100
locs_num<-200
lon_0<-85
lat_0<-45
my_proj<-CRS(paste("+proj=laea +lon_0=",lon_0," +lat_0=",lat_0," +x_0=0 +y_0=0 +ellps=WGS84 +units=m +no_defs",sep="")) 
grid_size<-100000
div<-1000

data(countriesCoarseLessIslands)
data(countriesCoarseLessIslands)
eurasia<-countriesCoarseLessIslands[grep("Eurasia",countriesCoarseLessIslands$continent),]
eu<-unionSpatialPolygons(eurasia, cut(coordinates(eurasia)[,1], range(coordinates(eurasia)[,1]), include.lowest=F))
poly<-eu@polygons[[1]]@Polygons[47][[1]]@coords
poly<-as.matrix(poly)
Sr1 = Polygon(poly)
Srs1 = Polygons(list(Sr1), "s1")
SpP = SpatialPolygons(list(Srs1))
proj4string(SpP)<-CRS("+proj=longlat +ellps=WGS84 +datum=WGS84 +no_defs")
spTransform(SpP,CRS=my_proj)->SpP_prj


set.seed(spec_seed)
origins<-spsample(SpP, spec_num,type="regular")
origins<-as.data.frame(origins)
data_ck<-origins
coordinates(data_ck)<-~x1+x2
clarkevans.test(as(data_ck,"ppp"),alternative="clustered")

set.seed(spec_seed)
acca<-rbeta(100,1,5)
range(acca)

length(acca)

set.seed(spec_seed)
abba<-sample(2^(rnorm(100,log(1000,2),log(1000,2)/10)),100)
sort(acca)->acca
sort(abba)->abba

seed<-seq(1:100)
x_zero<-list()
brown.points<-list()
temp_sample<-list()
for(i in 1:100){
  set.seed(seed[i])
  x_zero[[i]]<-as.vector(origins[sample(as.numeric(rownames(origins)),1),])
  set.seed(seed[i])
  brown.points[[i]]<-simm.mou(date=1:abba[i],b=c(sample(seq(from=x_zero[[i]]$x1,to=x_zero[[i]]$x1+(5),by=1),1),sample(seq(from=x_zero[[i]]$x2,to=x_zero[[i]]$x2+(5),by=1),1)),a=diag(c(acca[i]/div,acca[i]/div)),x0=c(x_zero[[i]]$x1,x_zero[[i]]$x2)) 
  brown.points[[i]]<-brown.points[[i]][[1]][,1:2]
  temp_sample[[i]]<-brown.points[[i]]
  try(temp_sample[[i]]<-cbind(temp_sample[[i]], paste("spec", i, sep="")),silent=F)
  print(i)
}

gc()

temp_population<-list()
pops<-list()
for(i in 1:nrow(origins)){
  try(colnames(temp_sample[[i]])[3]<-"spec",silent=F)
  try(temp_population[[i]]<-temp_sample[[i]][which(point.in.polygon(temp_sample[[i]]$x,temp_sample[[i]]$y, SpP@polygons[[1]]@Polygons[[1]]@coords[,1],SpP@polygons[[1]]@Polygons[[1]]@coords[,2])>0),],silent=F)
  try(coordinates(temp_population[[i]])<-~x+y,silent=F)
  try(proj4string(temp_population[[i]])<-CRS("+proj=longlat +ellps=WGS84 +datum=WGS84 +no_defs"),silent=F)
  try(pops[[i]]<-temp_population[[i]][SpP,],silent=F)
  print(i)
}
populations<-do.call(rbind, pops)

spTransform(populations,CRS=my_proj)->prj_populations
extent(prj_populations)[1:2]->x_lim
extent(prj_populations)[3:4]->y_lim
sampling_grid<-expand.grid(x=seq(from=x_lim[1],to=x_lim[2],grid_size),y=seq(from=y_lim[1],to=y_lim[2],grid_size))
sampling_grid->prediction_ground
prediction_ground$z<-1
rasterFromXYZ(prediction_ground)->prediction_ground
crs(prediction_ground)<-my_proj
mask(prediction_ground,SpP_prj)->prediction_ground
coordinates(sampling_grid)<-~x+y
gridded(sampling_grid)<-TRUE
crs(sampling_grid)<-my_proj
as(sampling_grid,"SpatialPolygons")->sampling_grid
lapply(pops,function(x)spTransform(x,CRS=my_proj))->prj_pops

cl <- makeCluster(1, type="SOCK")
registerDoSNOW (cl)
foreach(i=1:length(prj_pops),.packages=c("raster")) %dopar% {
  over(prj_pops[[i]],sampling_grid)->original_over_res
}->original_over_res
stopCluster(cl)
doParallel::stopImplicitCluster()
##

lapply(original_over_res,function(x){sampling_grid[unique(x)[!is.na(unique(x))]]->x;
  return(x)})->real_poly

for(i in 1:length(real_poly)) {
  rgeos::gUnaryUnion(real_poly[[i]])->real_poly[[i]]
  print(i)
}
##

sapply(real_poly,function(x)gArea(x))->areas


lapply(pops,function(x)unique(as.character(x$spec)))->pops_names
names(pops)<-pops_names
names(prj_pops)<-pops_names
names(real_poly)<-pops_names


set.seed(loc_seed)
sim_locs<-spsample(SpP_prj,locs_num,type = "regular")
lapply(real_poly,function(x){
  over(x,sim_locs,returnList=TRUE)  
})->over_res
which(sapply(over_res,function(x)length(x[[1]])!=0))->valid_specs
over_res[valid_specs]->over_res
over_res<-mapply(function(x,y) {data.frame(x,spec=rep(y,length(x)))->z;
  return(z)},over_res,names(over_res),SIMPLIFY = FALSE)
lapply(over_res,function(x){sim_locs[x$X1,]->z;
  z$loc_id<-x$X1;
  return(z)})->over_res
over_res<-mapply(function(x,y) { as.data.frame(x)->x;
  x$spec<-y;
  return(x)}, over_res,names(over_res),SIMPLIFY = FALSE )
over_res<-do.call(rbind,over_res)
rownames(over_res)<-NULL
colnames(over_res)[2:3]<-c("x","y")
coordinates(over_res)<-~x+y
crs(over_res)<-my_proj
over_res->general_sim_dat
spTransform(general_sim_dat,CRS=CRS("+proj=longlat +datum=WGS84"))->general_sim_dat
general_sim_dat<-as.data.frame(general_sim_dat)
as.character(general_sim_dat$spec)->general_sim_dat$spec
general_sim_dat->general_sim_locs
general_sim_locs$age<-1


set.seed(2047)
summary(to_rem<-round(rnorm(length(unique(general_sim_locs$loc_id)), mean=30,sd=10)))
id_list<-unique(general_sim_locs$loc_id)

reduce_list<-function(x,y,seed){
  to_keep<-sample(which(general_sim_locs$loc_id%in%x),round(length(which(general_sim_locs$loc_id%in%x))*((100-y)/100)))
  reduced_general_sim_locs<-general_sim_locs[to_keep,]
  return(reduced_general_sim_locs)
}

reduced_general_sim_locs<-mapply(function(x,y) reduce_list(x,y,seed=39), id_list, to_rem,SIMPLIFY=FALSE )
reduced_general_sim_locs<-do.call(rbind,reduced_general_sim_locs)
rownames(reduced_general_sim_locs)<-NULL



#### Performing MInOSSE ####
Sys.getenv("R_MAX_NUM_DLLs", unset = NA)
unique(as.character(reduced_general_sim_locs$spec))->spec_list

minosse_dat<-list()
minosse_res_list<-list()
for(i in 1:length(spec_list)){
  if(class(try(minosse_dat[[i]]<-minosse.data(
    obj=reduced_general_sim_locs,
    species_name=spec_list[i],
    domain="land",
    coc.by=NULL,
    min.occs=3,
    abiotic.covs=NULL,
    combine.covs=FALSE,   
    reduce_covs_by="pca",
    covs_th=0.95,
    c.size=100000,
    bkg.predictors="presence", 
    min.bkg=100,
    sampling.by.distance=TRUE,
    prediction.ground=prediction_ground,
    crop.by.mcp=FALSE,
    projection="laea",
    lon_0=85,
    lat_0=45,
    n.clusters="automatic", 
    seed=625)
  ))=="try-error") {next} else {minosse_dat[[i]]<-minosse_dat[[i]];
  
  
  if(class(try(minosse_res_list[[i]]<-minosse.target(
    resp=minosse_dat[[i]][[1]],
    predictors=minosse_dat[[i]][[2]],
    bkg="presence",
    min.bkg = 100,
    n.sims=10,
    sampling.by.distance=TRUE,
    n.folds=n.folds,
    n.sims.clusters="automatic",
    seed=625)))=="try-error") {next} else minosse_res_list[[i]]<-minosse_res_list[[i]] 
  }
  print(i)
}
gc()
#### save ####
save.image(paste(sim.dir,"200_100_uniform_3_1861_no_coc.RData",sep=""))
##



#### seed 2004,  highly clustered spatial simulations ####
rm(list=ls(all=TRUE)[-which(ls(all=TRUE)==dir.path_no_coc_100_200)]);setwd(dir.path_no_coc_100_200)
sim.dir<-"4-2004/"
dir.create(sim.dir, showWarnings = TRUE, recursive = TRUE) 

spec_seed<-4
loc_seed<-2004
spec_num<-100
locs_num<-200
lon_0<-85
lat_0<-45
my_proj<-CRS(paste("+proj=laea +lon_0=",lon_0," +lat_0=",lat_0," +x_0=0 +y_0=0 +ellps=WGS84 +units=m +no_defs",sep="")) 
grid_size<-100000
div<-1000

data(countriesCoarseLessIslands)
data(countriesCoarseLessIslands)
eurasia<-countriesCoarseLessIslands[grep("Eurasia",countriesCoarseLessIslands$continent),]
eu<-unionSpatialPolygons(eurasia, cut(coordinates(eurasia)[,1], range(coordinates(eurasia)[,1]), include.lowest=F))
poly<-eu@polygons[[1]]@Polygons[47][[1]]@coords
poly<-as.matrix(poly)
Sr1 = Polygon(poly)
Srs1 = Polygons(list(Sr1), "s1")
SpP = SpatialPolygons(list(Srs1))
proj4string(SpP)<-CRS("+proj=longlat +ellps=WGS84 +datum=WGS84 +no_defs")
spTransform(SpP,CRS=my_proj)->SpP_prj


set.seed(spec_seed)
origins<-spsample(SpP, spec_num,type="clustered",nclusters=100)
origins<-as.data.frame(origins)

data_ck<-origins
coordinates(data_ck)<-~x1+x2
clarkevans.test(as(data_ck,"ppp"),alternative="clustered")

set.seed(spec_seed)
acca<-rbeta(100,1,5)
range(acca)

length(acca)
set.seed(spec_seed)
abba<-sample(2^(rnorm(100,log(1000,2),log(1000,2)/10)),100)
sort(acca)->acca
sort(abba)->abba

seed<-seq(1:100)
x_zero<-list()
brown.points<-list()
temp_sample<-list()
for(i in 1:100){
  set.seed(seed[i])
  x_zero[[i]]<-as.vector(origins[sample(as.numeric(rownames(origins)),1),])
  set.seed(seed[i])
  brown.points[[i]]<-simm.mou(date=1:abba[i] ,b=c(sample(seq(from=x_zero[[i]]$x1,to=x_zero[[i]]$x1+(5),by=1),1),sample(seq(from=x_zero[[i]]$x2,to=x_zero[[i]]$x2+(5),by=1),1)),a=diag(c(acca[i]/div,acca[i]/div)),x0=c(x_zero[[i]]$x1,x_zero[[i]]$x2)) 
  brown.points[[i]]<-brown.points[[i]][[1]][,1:2]
  temp_sample[[i]]<-brown.points[[i]]
  try(temp_sample[[i]]<-cbind(temp_sample[[i]], paste("spec", i, sep="")),silent=F)
  print(i)
}
gc()

temp_population<-list()
pops<-list()
for(i in 1:nrow(origins)){
  try(colnames(temp_sample[[i]])[3]<-"spec",silent=F)
  try(temp_population[[i]]<-temp_sample[[i]][which(point.in.polygon(temp_sample[[i]]$x,temp_sample[[i]]$y, SpP@polygons[[1]]@Polygons[[1]]@coords[,1],SpP@polygons[[1]]@Polygons[[1]]@coords[,2])>0),],silent=F)
  try(coordinates(temp_population[[i]])<-~x+y,silent=F)
  try(proj4string(temp_population[[i]])<-CRS("+proj=longlat +ellps=WGS84 +datum=WGS84 +no_defs"),silent=F)
  try(pops[[i]]<-temp_population[[i]][SpP,],silent=F)
  print(i)
}
populations<-do.call(rbind, pops)

spTransform(populations,CRS=my_proj)->prj_populations
extent(prj_populations)[1:2]->x_lim
extent(prj_populations)[3:4]->y_lim
sampling_grid<-expand.grid(x=seq(from=x_lim[1],to=x_lim[2],grid_size),y=seq(from=y_lim[1],to=y_lim[2],grid_size))
sampling_grid->prediction_ground
prediction_ground$z<-1
rasterFromXYZ(prediction_ground)->prediction_ground
crs(prediction_ground)<-my_proj
mask(prediction_ground,SpP_prj)->prediction_ground
coordinates(sampling_grid)<-~x+y
gridded(sampling_grid)<-TRUE
crs(sampling_grid)<-my_proj
as(sampling_grid,"SpatialPolygons")->sampling_grid
lapply(pops,function(x)spTransform(x,CRS=my_proj))->prj_pops

cl <- makeCluster(2, type="SOCK")
registerDoSNOW (cl)
foreach(i=1:length(prj_pops),.packages=c("raster")) %dopar% {
  over(prj_pops[[i]],sampling_grid)->original_over_res
}->original_over_res
stopCluster(cl)
doParallel::stopImplicitCluster()
##

lapply(original_over_res,function(x){sampling_grid[unique(x)[!is.na(unique(x))]]->x;
  return(x)})->real_poly
for(i in 1:length(real_poly)) {
  rgeos::gUnaryUnion(real_poly[[i]])->real_poly[[i]]
  print(i)
}
##

sapply(real_poly,function(x)gArea(x))->areas

sapply(pops,function(x)length(x))->abundance


lapply(pops,function(x)unique(as.character(x$spec)))->pops_names
names(pops)<-pops_names
names(prj_pops)<-pops_names
names(real_poly)<-pops_names


set.seed(loc_seed)
sim_locs<-spsample(SpP_prj,locs_num,type = "clustered",nclusters=50)

lapply(real_poly,function(x){
  over(x,sim_locs,returnList=TRUE)  
})->over_res
which(sapply(over_res,function(x)length(x[[1]])!=0))->valid_specs
over_res[valid_specs]->over_res
over_res<-mapply(function(x,y) {data.frame(x,spec=rep(y,length(x)))->z;
  return(z)},over_res,names(over_res),SIMPLIFY = FALSE)

lapply(over_res,function(x){sim_locs[x$X1,]->z;
  z$loc_id<-x$X1;
  return(z)})->over_res
over_res<-mapply(function(x,y) { as.data.frame(x)->x;
  x$spec<-y;
  return(x)}, over_res,names(over_res),SIMPLIFY = FALSE )
over_res<-do.call(rbind,over_res)
rownames(over_res)<-NULL
colnames(over_res)[2:3]<-c("x","y")
coordinates(over_res)<-~x+y
crs(over_res)<-my_proj
over_res->general_sim_dat
spTransform(general_sim_dat,CRS=CRS("+proj=longlat +datum=WGS84"))->general_sim_dat
general_sim_dat<-as.data.frame(general_sim_dat)
as.character(general_sim_dat$spec)->general_sim_dat$spec
general_sim_dat->general_sim_locs
general_sim_locs$age<-1

set.seed(2047)
summary(to_rem<-round(rnorm(length(unique(general_sim_locs$loc_id)), mean=30,sd=10)))
id_list<-unique(general_sim_locs$loc_id)
reduce_list<-function(x,y,seed){
  to_keep<-sample(which(general_sim_locs$loc_id%in%x),round(length(which(general_sim_locs$loc_id%in%x))*((100-y)/100)))
  reduced_general_sim_locs<-general_sim_locs[to_keep,]
  return(reduced_general_sim_locs)
}
reduced_general_sim_locs<-mapply(function(x,y) reduce_list(x,y,seed=39), id_list, to_rem,SIMPLIFY=FALSE )
reduced_general_sim_locs<-do.call(rbind,reduced_general_sim_locs)
rownames(reduced_general_sim_locs)<-NULL

#### Performing MInOSSE ####
Sys.getenv("R_MAX_NUM_DLLs", unset = NA)
unique(as.character(reduced_general_sim_locs$spec))->spec_list

minosse_dat<-list()
minosse_res_list<-list()
for(i in 1:length(spec_list)){
  if(class(try(minosse_dat[[i]]<-minosse.data(
    obj=reduced_general_sim_locs,
    species_name=spec_list[i],
    domain="land",
    coc.by=NULL,
    min.occs=3,
    abiotic.covs=NULL,
    combine.covs=FALSE,   
    reduce_covs_by="pca",
    covs_th=0.95,
    c.size=100000,
    bkg.predictors="presence", 
    min.bkg=100,
    sampling.by.distance=TRUE,
    prediction.ground=prediction_ground,
    crop.by.mcp=FALSE,
    projection="laea",
    lon_0=85,
    lat_0=45,
    n.clusters="automatic", 
    seed=625)
  ))=="try-error") {next} else {minosse_dat[[i]]<-minosse_dat[[i]];
  
  
  if(class(try(minosse_res_list[[i]]<-minosse.target(
    resp=minosse_dat[[i]][[1]],
    predictors=minosse_dat[[i]][[2]],
    bkg="presence",
    min.bkg = 100,
    n.sims=10,
    sampling.by.distance=TRUE,
    n.folds=n.folds,
    n.sims.clusters="automatic",
    seed=625)))=="try-error") {next} else minosse_res_list[[i]]<-minosse_res_list[[i]] 
  }
  print(i)
}
gc()
#### save ####
save.image(paste(sim.dir,"200_100_clus_max_4_2004_no_coc.RData",sep=""))
###



#### seed 2004,  moderately clustered spatial simulations ####
rm(list=ls(all=TRUE)[-which(ls(all=TRUE)==dir.path_no_coc_100_200)]);setwd(dir.path_no_coc_100_200)
sim.dir<-"4-2004/"
dir.create(sim.dir, showWarnings = TRUE, recursive = TRUE) 

spec_seed<-4
loc_seed<-2004
spec_num<-100
locs_num<-200
lon_0<-85
lat_0<-45
my_proj<-CRS(paste("+proj=laea +lon_0=",lon_0," +lat_0=",lat_0," +x_0=0 +y_0=0 +ellps=WGS84 +units=m +no_defs",sep="")) 
grid_size<-100000
div<-1000

data(countriesCoarseLessIslands)
data(countriesCoarseLessIslands)
eurasia<-countriesCoarseLessIslands[grep("Eurasia",countriesCoarseLessIslands$continent),]
eu<-unionSpatialPolygons(eurasia, cut(coordinates(eurasia)[,1], range(coordinates(eurasia)[,1]), include.lowest=F))
poly<-eu@polygons[[1]]@Polygons[47][[1]]@coords
poly<-as.matrix(poly)
Sr1 = Polygon(poly)
Srs1 = Polygons(list(Sr1), "s1")
SpP = SpatialPolygons(list(Srs1))
proj4string(SpP)<-CRS("+proj=longlat +ellps=WGS84 +datum=WGS84 +no_defs")
spTransform(SpP,CRS=my_proj)->SpP_prj


set.seed(spec_seed)
origins<-spsample(SpP, spec_num,type="clustered",nclusters=150)
origins<-as.data.frame(origins)
data_ck<-origins
coordinates(data_ck)<-~x1+x2
clarkevans.test(as(data_ck,"ppp"),alternative="clustered")

set.seed(spec_seed)
acca<-rbeta(100,1,5)
range(acca)

length(acca)
set.seed(spec_seed)
abba<-sample(2^(rnorm(100,log(1000,2),log(1000,2)/10)),100)
sort(acca)->acca
sort(abba)->abba

seed<-seq(1:100)
x_zero<-list()
brown.points<-list()
temp_sample<-list()
for(i in 1:100){
  set.seed(seed[i])
  x_zero[[i]]<-as.vector(origins[sample(as.numeric(rownames(origins)),1),])
  set.seed(seed[i])
  brown.points[[i]]<-simm.mou(date=1:abba[i] ,b=c(sample(seq(from=x_zero[[i]]$x1,to=x_zero[[i]]$x1+(5),by=1),1),sample(seq(from=x_zero[[i]]$x2,to=x_zero[[i]]$x2+(5),by=1),1)),a=diag(c(acca[i]/div,acca[i]/div)),x0=c(x_zero[[i]]$x1,x_zero[[i]]$x2)) 
  brown.points[[i]]<-brown.points[[i]][[1]][,1:2]
  temp_sample[[i]]<-brown.points[[i]]
  try(temp_sample[[i]]<-cbind(temp_sample[[i]], paste("spec", i, sep="")),silent=F)
  print(i)
}

gc()

temp_population<-list()
pops<-list()
for(i in 1:nrow(origins)){
  try(colnames(temp_sample[[i]])[3]<-"spec",silent=F)
  try(temp_population[[i]]<-temp_sample[[i]][which(point.in.polygon(temp_sample[[i]]$x,temp_sample[[i]]$y, SpP@polygons[[1]]@Polygons[[1]]@coords[,1],SpP@polygons[[1]]@Polygons[[1]]@coords[,2])>0),],silent=F)
  try(coordinates(temp_population[[i]])<-~x+y,silent=F)
  try(proj4string(temp_population[[i]])<-CRS("+proj=longlat +ellps=WGS84 +datum=WGS84 +no_defs"),silent=F)
  try(pops[[i]]<-temp_population[[i]][SpP,],silent=F)
  print(i)
}
populations<-do.call(rbind, pops)

spTransform(populations,CRS=my_proj)->prj_populations
extent(prj_populations)[1:2]->x_lim
extent(prj_populations)[3:4]->y_lim
sampling_grid<-expand.grid(x=seq(from=x_lim[1],to=x_lim[2],grid_size),y=seq(from=y_lim[1],to=y_lim[2],grid_size))
sampling_grid->prediction_ground
prediction_ground$z<-1
rasterFromXYZ(prediction_ground)->prediction_ground
crs(prediction_ground)<-my_proj
mask(prediction_ground,SpP_prj)->prediction_ground
coordinates(sampling_grid)<-~x+y
gridded(sampling_grid)<-TRUE
crs(sampling_grid)<-my_proj
as(sampling_grid,"SpatialPolygons")->sampling_grid
lapply(pops,function(x)spTransform(x,CRS=my_proj))->prj_pops

cl <- makeCluster(2, type="SOCK")
registerDoSNOW (cl)
foreach(i=1:length(prj_pops),.packages=c("raster")) %dopar% {
  over(prj_pops[[i]],sampling_grid)->original_over_res
}->original_over_res
stopCluster(cl)
doParallel::stopImplicitCluster()
##

lapply(original_over_res,function(x){sampling_grid[unique(x)[!is.na(unique(x))]]->x;
  return(x)})->real_poly
for(i in 1:length(real_poly)) {
  rgeos::gUnaryUnion(real_poly[[i]])->real_poly[[i]]
  print(i)
}
##

sapply(real_poly,function(x)gArea(x))->areas
lapply(pops,function(x)unique(as.character(x$spec)))->pops_names
names(pops)<-pops_names
names(prj_pops)<-pops_names
names(real_poly)<-pops_names


set.seed(loc_seed)
sim_locs<-spsample(SpP_prj,locs_num,type = "clustered",nclusters=90)

lapply(real_poly,function(x){
  over(x,sim_locs,returnList=TRUE)  
})->over_res
which(sapply(over_res,function(x)length(x[[1]])!=0))->valid_specs
over_res[valid_specs]->over_res
over_res<-mapply(function(x,y) {data.frame(x,spec=rep(y,length(x)))->z;
  return(z)},over_res,names(over_res),SIMPLIFY = FALSE)
lapply(over_res,function(x){sim_locs[x$X1,]->z;
  z$loc_id<-x$X1;
  return(z)})->over_res
over_res<-mapply(function(x,y) { as.data.frame(x)->x;
  x$spec<-y;
  return(x)}, over_res,names(over_res),SIMPLIFY = FALSE )
over_res<-do.call(rbind,over_res)
rownames(over_res)<-NULL
colnames(over_res)[2:3]<-c("x","y")
coordinates(over_res)<-~x+y
crs(over_res)<-my_proj
over_res->general_sim_dat
spTransform(general_sim_dat,CRS=CRS("+proj=longlat +datum=WGS84"))->general_sim_dat
general_sim_dat<-as.data.frame(general_sim_dat)
as.character(general_sim_dat$spec)->general_sim_dat$spec
general_sim_dat->general_sim_locs
general_sim_locs$age<-1

set.seed(2047)
summary(to_rem<-round(rnorm(length(unique(general_sim_locs$loc_id)), mean=30,sd=10)))
id_list<-unique(general_sim_locs$loc_id)
reduce_list<-function(x,y,seed){
  to_keep<-sample(which(general_sim_locs$loc_id%in%x),round(length(which(general_sim_locs$loc_id%in%x))*((100-y)/100)))
  reduced_general_sim_locs<-general_sim_locs[to_keep,]
  return(reduced_general_sim_locs)
}
reduced_general_sim_locs<-mapply(function(x,y) reduce_list(x,y,seed=39), id_list, to_rem,SIMPLIFY=FALSE )
reduced_general_sim_locs<-do.call(rbind,reduced_general_sim_locs)
rownames(reduced_general_sim_locs)<-NULL


#### Performing MInOSSE ####
Sys.getenv("R_MAX_NUM_DLLs", unset = NA)
unique(as.character(reduced_general_sim_locs$spec))->spec_list

minosse_dat<-list()
minosse_res_list<-list()
for(i in 1:length(spec_list)){
  if(class(try(minosse_dat[[i]]<-minosse.data(
    obj=reduced_general_sim_locs,
    species_name=spec_list[i],
    domain="land",
    coc.by=NULL,
    min.occs=3,
    abiotic.covs=NULL,
    combine.covs=FALSE,   
    reduce_covs_by="pca",
    covs_th=0.95,
    c.size=100000,
    bkg.predictors="presence", 
    min.bkg=100,
    sampling.by.distance=TRUE,
    prediction.ground=prediction_ground,
    crop.by.mcp=FALSE,
    projection="laea",
    lon_0=85,
    lat_0=45,
    n.clusters="automatic", 
    seed=625)
  ))=="try-error") {next} else {minosse_dat[[i]]<-minosse_dat[[i]];
  
  
  if(class(try(minosse_res_list[[i]]<-minosse.target(
    resp=minosse_dat[[i]][[1]],
    predictors=minosse_dat[[i]][[2]],
    bkg="presence",
    min.bkg = 100,
    n.sims=10,
    sampling.by.distance=TRUE,
    n.folds=n.folds,
    n.sims.clusters="automatic",
    seed=625)))=="try-error") {next} else minosse_res_list[[i]]<-minosse_res_list[[i]] 
  }
  print(i)
}
gc()
#### save ####
save.image(paste(sim.dir,"200_100_clus_min_4_2004_no_coc.RData",sep=""))
##





#### seed 2004,  randomly distributed spatial simulations ####
rm(list=ls(all=TRUE)[-which(ls(all=TRUE)==dir.path_no_coc_100_200)]);setwd(dir.path_no_coc_100_200)
sim.dir<-"4-2004/"
dir.create(sim.dir, showWarnings = TRUE, recursive = TRUE) 

################ creazione delle popolazioni reali

spec_seed<-4
loc_seed<-2004
spec_num<-100
locs_num<-200
lon_0<-85
lat_0<-45
my_proj<-CRS(paste("+proj=laea +lon_0=",lon_0," +lat_0=",lat_0," +x_0=0 +y_0=0 +ellps=WGS84 +units=m +no_defs",sep="")) 
grid_size<-100000
div<-1000

data(countriesCoarseLessIslands)
data(countriesCoarseLessIslands)
eurasia<-countriesCoarseLessIslands[grep("Eurasia",countriesCoarseLessIslands$continent),]
eu<-unionSpatialPolygons(eurasia, cut(coordinates(eurasia)[,1], range(coordinates(eurasia)[,1]), include.lowest=F))
poly<-eu@polygons[[1]]@Polygons[47][[1]]@coords
poly<-as.matrix(poly)
Sr1 = Polygon(poly)
Srs1 = Polygons(list(Sr1), "s1")
SpP = SpatialPolygons(list(Srs1))
proj4string(SpP)<-CRS("+proj=longlat +ellps=WGS84 +datum=WGS84 +no_defs")
spTransform(SpP,CRS=my_proj)->SpP_prj


set.seed(spec_seed)
origins<-spsample(SpP, spec_num,type="random")
origins<-as.data.frame(origins)
data_ck<-origins
coordinates(data_ck)<-~x+y
clarkevans.test(as(data_ck,"ppp"),alternative="clustered")

set.seed(spec_seed)
acca<-rbeta(100,1,5)
range(acca)

length(acca)
set.seed(spec_seed)
abba<-sample(2^(rnorm(100,log(1000,2),log(1000,2)/10)),100)
sort(acca)->acca
sort(abba)->abba

seed<-seq(1:100)
x_zero<-list()
brown.points<-list()
temp_sample<-list()
for(i in 1:100){
  set.seed(seed[i])
  x_zero[[i]]<-as.vector(origins[sample(as.numeric(rownames(origins)),1),])
  set.seed(seed[i])
  brown.points[[i]]<-simm.mou(date=1:abba[i] ,b=c(sample(seq(from=x_zero[[i]]$x,to=x_zero[[i]]$x+(5),by=1),1),sample(seq(from=x_zero[[i]]$y,to=x_zero[[i]]$y+(5),by=1),1)),a=diag(c(acca[i]/div,acca[i]/div)),x0=c(x_zero[[i]]$x,x_zero[[i]]$y)) 
  brown.points[[i]]<-brown.points[[i]][[1]][,1:2]
  temp_sample[[i]]<-brown.points[[i]]
  try(temp_sample[[i]]<-cbind(temp_sample[[i]], paste("spec", i, sep="")),silent=F)
  print(i)
}
gc()

temp_population<-list()
pops<-list()
for(i in 1:nrow(origins)){
  try(colnames(temp_sample[[i]])[3]<-"spec",silent=F)
  try(temp_population[[i]]<-temp_sample[[i]][which(point.in.polygon(temp_sample[[i]]$x,temp_sample[[i]]$y, SpP@polygons[[1]]@Polygons[[1]]@coords[,1],SpP@polygons[[1]]@Polygons[[1]]@coords[,2])>0),],silent=F)
  try(coordinates(temp_population[[i]])<-~x+y,silent=F)
  try(proj4string(temp_population[[i]])<-CRS("+proj=longlat +ellps=WGS84 +datum=WGS84 +no_defs"),silent=F)
  try(pops[[i]]<-temp_population[[i]][SpP,],silent=F)
  print(i)
}
populations<-do.call(rbind, pops)
spTransform(populations,CRS=my_proj)->prj_populations
extent(prj_populations)[1:2]->x_lim
extent(prj_populations)[3:4]->y_lim
sampling_grid<-expand.grid(x=seq(from=x_lim[1],to=x_lim[2],grid_size),y=seq(from=y_lim[1],to=y_lim[2],grid_size))
sampling_grid->prediction_ground
prediction_ground$z<-1
rasterFromXYZ(prediction_ground)->prediction_ground
crs(prediction_ground)<-my_proj
mask(prediction_ground,SpP_prj)->prediction_ground
coordinates(sampling_grid)<-~x+y
gridded(sampling_grid)<-TRUE
crs(sampling_grid)<-my_proj
as(sampling_grid,"SpatialPolygons")->sampling_grid
lapply(pops,function(x)spTransform(x,CRS=my_proj))->prj_pops

cl <- makeCluster(2, type="SOCK")
registerDoSNOW (cl)
foreach(i=1:length(prj_pops),.packages=c("raster")) %dopar% {
  over(prj_pops[[i]],sampling_grid)->original_over_res
}->original_over_res
stopCluster(cl)
doParallel::stopImplicitCluster()
##

lapply(original_over_res,function(x){sampling_grid[unique(x)[!is.na(unique(x))]]->x;
  return(x)})->real_poly
for(i in 1:length(real_poly)) {
  rgeos::gUnaryUnion(real_poly[[i]])->real_poly[[i]]
  print(i)
}
##

sapply(real_poly,function(x)gArea(x))->areas
lapply(pops,function(x)unique(as.character(x$spec)))->pops_names
names(pops)<-pops_names
names(prj_pops)<-pops_names
names(real_poly)<-pops_names


set.seed(loc_seed)
sim_locs<-spsample(SpP_prj,locs_num,type = "random",nclusters=90)

lapply(real_poly,function(x){
  over(x,sim_locs,returnList=TRUE)  
})->over_res
which(sapply(over_res,function(x)length(x[[1]])!=0))->valid_specs
over_res[valid_specs]->over_res
over_res<-mapply(function(x,y) {data.frame(x,spec=rep(y,length(x)))->z;
  return(z)},over_res,names(over_res),SIMPLIFY = FALSE)
lapply(over_res,function(x){sim_locs[x$X1,]->z;
  z$loc_id<-x$X1;
  return(z)})->over_res
over_res<-mapply(function(x,y) { as.data.frame(x)->x;
  x$spec<-y;
  return(x)}, over_res,names(over_res),SIMPLIFY = FALSE )
over_res<-do.call(rbind,over_res)
rownames(over_res)<-NULL
colnames(over_res)[2:3]<-c("x","y")
coordinates(over_res)<-~x+y
crs(over_res)<-my_proj
over_res->general_sim_dat
spTransform(general_sim_dat,CRS=CRS("+proj=longlat +datum=WGS84"))->general_sim_dat
general_sim_dat<-as.data.frame(general_sim_dat)
as.character(general_sim_dat$spec)->general_sim_dat$spec
general_sim_dat->general_sim_locs
general_sim_locs$age<-1

set.seed(2047)
summary(to_rem<-round(rnorm(length(unique(general_sim_locs$loc_id)), mean=30,sd=10)))
id_list<-unique(general_sim_locs$loc_id)
reduce_list<-function(x,y,seed){
  to_keep<-sample(which(general_sim_locs$loc_id%in%x),round(length(which(general_sim_locs$loc_id%in%x))*((100-y)/100)))
  reduced_general_sim_locs<-general_sim_locs[to_keep,]
  return(reduced_general_sim_locs)
}
reduced_general_sim_locs<-mapply(function(x,y) reduce_list(x,y,seed=39), id_list, to_rem,SIMPLIFY=FALSE )
reduced_general_sim_locs<-do.call(rbind,reduced_general_sim_locs)
rownames(reduced_general_sim_locs)<-NULL


#### Performing MInOSSE ####
Sys.getenv("R_MAX_NUM_DLLs", unset = NA)
unique(as.character(reduced_general_sim_locs$spec))->spec_list

minosse_dat<-list()
minosse_res_list<-list()
for(i in 1:length(spec_list)){
  if(class(try(minosse_dat[[i]]<-minosse.data(
    obj=reduced_general_sim_locs,
    species_name=spec_list[i],
    domain="land",
    coc.by=NULL,
    min.occs=3,
    abiotic.covs=NULL,
    combine.covs=FALSE,   
    reduce_covs_by="pca",
    covs_th=0.95,
    c.size=100000,
    bkg.predictors="presence", 
    min.bkg=100,
    sampling.by.distance=TRUE,
    prediction.ground=prediction_ground,
    crop.by.mcp=FALSE,
    projection="laea",
    lon_0=85,
    lat_0=45,
    n.clusters="automatic", 
    seed=625)
  ))=="try-error") {next} else {minosse_dat[[i]]<-minosse_dat[[i]];
  
  
  if(class(try(minosse_res_list[[i]]<-minosse.target(
    resp=minosse_dat[[i]][[1]],
    predictors=minosse_dat[[i]][[2]],
    bkg="presence",
    min.bkg = 100,
    n.sims=10,
    sampling.by.distance=TRUE,
    n.folds=n.folds,
    n.sims.clusters="automatic",
    seed=625)))=="try-error") {next} else minosse_res_list[[i]]<-minosse_res_list[[i]] 
  }
  print(i)
}
gc()


#### save ####
save.image(paste(sim.dir,"200_100_random_4_2004_no_coc.RData",sep=""))
##





#### seed 2004,  uniformly distributed spatial simulations ####
rm(list=ls(all=TRUE)[-which(ls(all=TRUE)==dir.path_no_coc_100_200)]);setwd(dir.path_no_coc_100_200)
sim.dir<-"4-2004/"
dir.create(sim.dir, showWarnings = TRUE, recursive = TRUE) 

spec_seed<-4
loc_seed<-2004
spec_num<-100
locs_num<-200
lon_0<-85
lat_0<-45
my_proj<-CRS(paste("+proj=laea +lon_0=",lon_0," +lat_0=",lat_0," +x_0=0 +y_0=0 +ellps=WGS84 +units=m +no_defs",sep="")) 
grid_size<-100000
div<-1000

data(countriesCoarseLessIslands)
data(countriesCoarseLessIslands)
eurasia<-countriesCoarseLessIslands[grep("Eurasia",countriesCoarseLessIslands$continent),]
eu<-unionSpatialPolygons(eurasia, cut(coordinates(eurasia)[,1], range(coordinates(eurasia)[,1]), include.lowest=F))
poly<-eu@polygons[[1]]@Polygons[47][[1]]@coords
poly<-as.matrix(poly)
Sr1 = Polygon(poly)
Srs1 = Polygons(list(Sr1), "s1")
SpP = SpatialPolygons(list(Srs1))
proj4string(SpP)<-CRS("+proj=longlat +ellps=WGS84 +datum=WGS84 +no_defs")
spTransform(SpP,CRS=my_proj)->SpP_prj


set.seed(spec_seed)
origins<-spsample(SpP, spec_num,type="regular")
origins<-as.data.frame(origins)
data_ck<-origins
coordinates(data_ck)<-~x1+x2
clarkevans.test(as(data_ck,"ppp"),alternative="clustered")

set.seed(spec_seed)
acca<-rbeta(100,1,5)
range(acca)

length(acca)

set.seed(spec_seed)
abba<-sample(2^(rnorm(100,log(1000,2),log(1000,2)/10)),100)
sort(acca)->acca
sort(abba)->abba

seed<-seq(1:100)
x_zero<-list()
brown.points<-list()
temp_sample<-list()
for(i in 1:100){
  set.seed(seed[i])
  x_zero[[i]]<-as.vector(origins[sample(as.numeric(rownames(origins)),1),])
  set.seed(seed[i])
  brown.points[[i]]<-simm.mou(date=1:abba[i],b=c(sample(seq(from=x_zero[[i]]$x1,to=x_zero[[i]]$x1+(5),by=1),1),sample(seq(from=x_zero[[i]]$x2,to=x_zero[[i]]$x2+(5),by=1),1)),a=diag(c(acca[i]/div,acca[i]/div)),x0=c(x_zero[[i]]$x1,x_zero[[i]]$x2)) 
  brown.points[[i]]<-brown.points[[i]][[1]][,1:2]
  temp_sample[[i]]<-brown.points[[i]]
  try(temp_sample[[i]]<-cbind(temp_sample[[i]], paste("spec", i, sep="")),silent=F)
  print(i)
}
gc()

temp_population<-list()
pops<-list()
for(i in 1:nrow(origins)){
  try(colnames(temp_sample[[i]])[3]<-"spec",silent=F)
  try(temp_population[[i]]<-temp_sample[[i]][which(point.in.polygon(temp_sample[[i]]$x,temp_sample[[i]]$y, SpP@polygons[[1]]@Polygons[[1]]@coords[,1],SpP@polygons[[1]]@Polygons[[1]]@coords[,2])>0),],silent=F)
  try(coordinates(temp_population[[i]])<-~x+y,silent=F)
  try(proj4string(temp_population[[i]])<-CRS("+proj=longlat +ellps=WGS84 +datum=WGS84 +no_defs"),silent=F)
  try(pops[[i]]<-temp_population[[i]][SpP,],silent=F)
  print(i)
}
populations<-do.call(rbind, pops)
spTransform(populations,CRS=my_proj)->prj_populations
extent(prj_populations)[1:2]->x_lim
extent(prj_populations)[3:4]->y_lim
sampling_grid<-expand.grid(x=seq(from=x_lim[1],to=x_lim[2],grid_size),y=seq(from=y_lim[1],to=y_lim[2],grid_size))
sampling_grid->prediction_ground
prediction_ground$z<-1
rasterFromXYZ(prediction_ground)->prediction_ground
crs(prediction_ground)<-my_proj
mask(prediction_ground,SpP_prj)->prediction_ground
coordinates(sampling_grid)<-~x+y
gridded(sampling_grid)<-TRUE
crs(sampling_grid)<-my_proj
as(sampling_grid,"SpatialPolygons")->sampling_grid
lapply(pops,function(x)spTransform(x,CRS=my_proj))->prj_pops

cl <- makeCluster(2, type="SOCK")
registerDoSNOW (cl)
foreach(i=1:length(prj_pops),.packages=c("raster")) %dopar% {
  over(prj_pops[[i]],sampling_grid)->original_over_res
}->original_over_res
stopCluster(cl)
doParallel::stopImplicitCluster()
##

lapply(original_over_res,function(x){sampling_grid[unique(x)[!is.na(unique(x))]]->x;
  return(x)})->real_poly
for(i in 1:length(real_poly)) {
  rgeos::gUnaryUnion(real_poly[[i]])->real_poly[[i]]
  print(i)
}
##

sapply(real_poly,function(x)gArea(x))->areas


lapply(pops,function(x)unique(as.character(x$spec)))->pops_names
names(pops)<-pops_names
names(prj_pops)<-pops_names
names(real_poly)<-pops_names


set.seed(loc_seed)
sim_locs<-spsample(SpP_prj,locs_num,type = "regular")
lapply(real_poly,function(x){
  over(x,sim_locs,returnList=TRUE)  
})->over_res
which(sapply(over_res,function(x)length(x[[1]])!=0))->valid_specs
over_res[valid_specs]->over_res
over_res<-mapply(function(x,y) {data.frame(x,spec=rep(y,length(x)))->z;
  return(z)},over_res,names(over_res),SIMPLIFY = FALSE)
lapply(over_res,function(x){sim_locs[x$X1,]->z;
  z$loc_id<-x$X1;
  return(z)})->over_res
over_res<-mapply(function(x,y) { as.data.frame(x)->x;
  x$spec<-y;
  return(x)}, over_res,names(over_res),SIMPLIFY = FALSE )
over_res<-do.call(rbind,over_res)
rownames(over_res)<-NULL
colnames(over_res)[2:3]<-c("x","y")
coordinates(over_res)<-~x+y
crs(over_res)<-my_proj
over_res->general_sim_dat
spTransform(general_sim_dat,CRS=CRS("+proj=longlat +datum=WGS84"))->general_sim_dat
general_sim_dat<-as.data.frame(general_sim_dat)
as.character(general_sim_dat$spec)->general_sim_dat$spec
general_sim_dat->general_sim_locs
general_sim_locs$age<-1

set.seed(2047)
summary(to_rem<-round(rnorm(length(unique(general_sim_locs$loc_id)), mean=30,sd=10)))
id_list<-unique(general_sim_locs$loc_id)
reduce_list<-function(x,y,seed){
  to_keep<-sample(which(general_sim_locs$loc_id%in%x),round(length(which(general_sim_locs$loc_id%in%x))*((100-y)/100)))
  reduced_general_sim_locs<-general_sim_locs[to_keep,]
  return(reduced_general_sim_locs)
}
reduced_general_sim_locs<-mapply(function(x,y) reduce_list(x,y,seed=39), id_list, to_rem,SIMPLIFY=FALSE )
reduced_general_sim_locs<-do.call(rbind,reduced_general_sim_locs)
rownames(reduced_general_sim_locs)<-NULL



#### Performing MInOSSE ####
Sys.getenv("R_MAX_NUM_DLLs", unset = NA)
unique(as.character(reduced_general_sim_locs$spec))->spec_list

minosse_dat<-list()
minosse_res_list<-list()
for(i in 1:length(spec_list)){
  if(class(try(minosse_dat[[i]]<-minosse.data(
    obj=reduced_general_sim_locs,
    species_name=spec_list[i],
    domain="land",
    coc.by=NULL,
    min.occs=3,
    abiotic.covs=NULL,
    combine.covs=FALSE,   
    reduce_covs_by="pca",
    covs_th=0.95,
    c.size=100000,
    bkg.predictors="presence", 
    min.bkg=100,
    sampling.by.distance=TRUE,
    prediction.ground=prediction_ground,
    crop.by.mcp=FALSE,
    projection="laea",
    lon_0=85,
    lat_0=45,
    n.clusters="automatic", 
    seed=625)
  ))=="try-error") {next} else {minosse_dat[[i]]<-minosse_dat[[i]];
  
  
  if(class(try(minosse_res_list[[i]]<-minosse.target(
    resp=minosse_dat[[i]][[1]],
    predictors=minosse_dat[[i]][[2]],
    bkg="presence",
    min.bkg = 100,
    n.sims=10,
    sampling.by.distance=TRUE,
    n.folds=n.folds,
    n.sims.clusters="automatic",
    seed=625)))=="try-error") {next} else minosse_res_list[[i]]<-minosse_res_list[[i]] 
  }
  print(i)
}
gc()

#### save ####
save.image(paste(sim.dir,"200_100_uniform_4_2004_no_coc.RData",sep=""))
##




#### seed 2014,  ighly clustered spatial simulations ####
rm(list=ls(all=TRUE)[-which(ls(all=TRUE)==dir.path_no_coc_100_200)]);setwd(dir.path_no_coc_100_200)
sim.dir<-"6-2014/"
dir.create(sim.dir, showWarnings = TRUE, recursive = TRUE) 

spec_seed<-6
loc_seed<-2014
spec_num<-100
locs_num<-200
lon_0<-85
lat_0<-45
my_proj<-CRS(paste("+proj=laea +lon_0=",lon_0," +lat_0=",lat_0," +x_0=0 +y_0=0 +ellps=WGS84 +units=m +no_defs",sep="")) 
grid_size<-100000
div<-1000

data(countriesCoarseLessIslands)
data(countriesCoarseLessIslands)
eurasia<-countriesCoarseLessIslands[grep("Eurasia",countriesCoarseLessIslands$continent),]
eu<-unionSpatialPolygons(eurasia, cut(coordinates(eurasia)[,1], range(coordinates(eurasia)[,1]), include.lowest=F))
poly<-eu@polygons[[1]]@Polygons[47][[1]]@coords
poly<-as.matrix(poly)
Sr1 = Polygon(poly)
Srs1 = Polygons(list(Sr1), "s1")
SpP = SpatialPolygons(list(Srs1))
proj4string(SpP)<-CRS("+proj=longlat +ellps=WGS84 +datum=WGS84 +no_defs")
spTransform(SpP,CRS=my_proj)->SpP_prj


set.seed(spec_seed)
origins<-spsample(SpP, spec_num,type="clustered",nclusters=100)
origins<-as.data.frame(origins)
data_ck<-origins
coordinates(data_ck)<-~x1+x2
clarkevans.test(as(data_ck,"ppp"),alternative="clustered")

set.seed(spec_seed)
acca<-rbeta(100,1,5)
range(acca)

length(acca)

set.seed(spec_seed)
abba<-sample(2^(rnorm(100,log(1000,2),log(1000,2)/10)),100)
sort(acca)->acca
sort(abba)->abba

seed<-seq(1:100)
x_zero<-list()
brown.points<-list()
temp_sample<-list()
for(i in 1:100){
  set.seed(seed[i])
  x_zero[[i]]<-as.vector(origins[sample(as.numeric(rownames(origins)),1),])
  set.seed(seed[i])
  brown.points[[i]]<-simm.mou(date=1:abba[i] ,b=c(sample(seq(from=x_zero[[i]]$x1,to=x_zero[[i]]$x1+(5),by=1),1),sample(seq(from=x_zero[[i]]$x2,to=x_zero[[i]]$x2+(5),by=1),1)),a=diag(c(acca[i]/div,acca[i]/div)),x0=c(x_zero[[i]]$x1,x_zero[[i]]$x2)) 
  brown.points[[i]]<-brown.points[[i]][[1]][,1:2]
  temp_sample[[i]]<-brown.points[[i]]
  try(temp_sample[[i]]<-cbind(temp_sample[[i]], paste("spec", i, sep="")),silent=F)
  print(i)
}
gc()

temp_population<-list()
pops<-list()
for(i in 1:nrow(origins)){
  try(colnames(temp_sample[[i]])[3]<-"spec",silent=F)
  try(temp_population[[i]]<-temp_sample[[i]][which(point.in.polygon(temp_sample[[i]]$x,temp_sample[[i]]$y, SpP@polygons[[1]]@Polygons[[1]]@coords[,1],SpP@polygons[[1]]@Polygons[[1]]@coords[,2])>0),],silent=F)
  try(coordinates(temp_population[[i]])<-~x+y,silent=F)
  try(proj4string(temp_population[[i]])<-CRS("+proj=longlat +ellps=WGS84 +datum=WGS84 +no_defs"),silent=F)
  try(pops[[i]]<-temp_population[[i]][SpP,],silent=F)
  print(i)
}
populations<-do.call(rbind, pops)
spTransform(populations,CRS=my_proj)->prj_populations
extent(prj_populations)[1:2]->x_lim
extent(prj_populations)[3:4]->y_lim
sampling_grid<-expand.grid(x=seq(from=x_lim[1],to=x_lim[2],grid_size),y=seq(from=y_lim[1],to=y_lim[2],grid_size))
sampling_grid->prediction_ground
prediction_ground$z<-1
rasterFromXYZ(prediction_ground)->prediction_ground
crs(prediction_ground)<-my_proj
mask(prediction_ground,SpP_prj)->prediction_ground
coordinates(sampling_grid)<-~x+y
gridded(sampling_grid)<-TRUE
crs(sampling_grid)<-my_proj
as(sampling_grid,"SpatialPolygons")->sampling_grid
lapply(pops,function(x)spTransform(x,CRS=my_proj))->prj_pops

cl <- makeCluster(2, type="SOCK")
registerDoSNOW (cl)
foreach(i=1:length(prj_pops),.packages=c("raster")) %dopar% {
  over(prj_pops[[i]],sampling_grid)->original_over_res
}->original_over_res
stopCluster(cl)
doParallel::stopImplicitCluster()
##

lapply(original_over_res,function(x){sampling_grid[unique(x)[!is.na(unique(x))]]->x;
  return(x)})->real_poly
for(i in 1:length(real_poly)) {
  rgeos::gUnaryUnion(real_poly[[i]])->real_poly[[i]]
  print(i)
}
##

sapply(real_poly,function(x)gArea(x))->areas

sapply(pops,function(x)length(x))->abundance

lapply(pops,function(x)unique(as.character(x$spec)))->pops_names
names(pops)<-pops_names
names(prj_pops)<-pops_names
names(real_poly)<-pops_names


set.seed(loc_seed)
sim_locs<-spsample(SpP_prj,locs_num,type = "clustered",nclusters=50)

lapply(real_poly,function(x){
  over(x,sim_locs,returnList=TRUE)  
})->over_res
which(sapply(over_res,function(x)length(x[[1]])!=0))->valid_specs
over_res[valid_specs]->over_res
over_res<-mapply(function(x,y) {data.frame(x,spec=rep(y,length(x)))->z;
  return(z)},over_res,names(over_res),SIMPLIFY = FALSE)
lapply(over_res,function(x){sim_locs[x$X1,]->z;
  z$loc_id<-x$X1;
  return(z)})->over_res
over_res<-mapply(function(x,y) { as.data.frame(x)->x;
  x$spec<-y;
  return(x)}, over_res,names(over_res),SIMPLIFY = FALSE )
over_res<-do.call(rbind,over_res)
rownames(over_res)<-NULL
colnames(over_res)[2:3]<-c("x","y")
coordinates(over_res)<-~x+y
crs(over_res)<-my_proj
over_res->general_sim_dat
spTransform(general_sim_dat,CRS=CRS("+proj=longlat +datum=WGS84"))->general_sim_dat
general_sim_dat<-as.data.frame(general_sim_dat)
as.character(general_sim_dat$spec)->general_sim_dat$spec
general_sim_dat->general_sim_locs
general_sim_locs$age<-1

set.seed(2047)
summary(to_rem<-round(rnorm(length(unique(general_sim_locs$loc_id)), mean=30,sd=10)))
id_list<-unique(general_sim_locs$loc_id)
reduce_list<-function(x,y,seed){
  to_keep<-sample(which(general_sim_locs$loc_id%in%x),round(length(which(general_sim_locs$loc_id%in%x))*((100-y)/100)))
  reduced_general_sim_locs<-general_sim_locs[to_keep,]
  return(reduced_general_sim_locs)
}
reduced_general_sim_locs<-mapply(function(x,y) reduce_list(x,y,seed=39), id_list, to_rem,SIMPLIFY=FALSE )
reduced_general_sim_locs<-do.call(rbind,reduced_general_sim_locs)
rownames(reduced_general_sim_locs)<-NULL

#### Performing MInOSSE ####
Sys.getenv("R_MAX_NUM_DLLs", unset = NA)
unique(as.character(reduced_general_sim_locs$spec))->spec_list

minosse_dat<-list()
minosse_res_list<-list()
for(i in 1:length(spec_list)){
  if(class(try(minosse_dat[[i]]<-minosse.data(
    obj=reduced_general_sim_locs,
    species_name=spec_list[i],
    domain="land",
    coc.by=NULL,
    min.occs=3,
    abiotic.covs=NULL,
    combine.covs=FALSE,   
    reduce_covs_by="pca",
    covs_th=0.95,
    c.size=100000,
    bkg.predictors="presence", 
    min.bkg=100,
    sampling.by.distance=TRUE,
    prediction.ground=prediction_ground,
    crop.by.mcp=FALSE,
    projection="laea",
    lon_0=85,
    lat_0=45,
    n.clusters="automatic", 
    seed=625)
  ))=="try-error") {next} else {minosse_dat[[i]]<-minosse_dat[[i]];
  
  
  if(class(try(minosse_res_list[[i]]<-minosse.target(
    resp=minosse_dat[[i]][[1]],
    predictors=minosse_dat[[i]][[2]],
    bkg="presence",
    min.bkg = 100,
    n.sims=10,
    sampling.by.distance=TRUE,
    n.folds=n.folds,
    n.sims.clusters="automatic",
    seed=625)))=="try-error") {next} else minosse_res_list[[i]]<-minosse_res_list[[i]] 
  }
  print(i)
}
gc()

#### save ####
save.image(paste(sim.dir,"200_100_clus_max_6_2014_no_coc.RData",sep=""))
###





#### seed 2014,  moderately clustered spatial simulations ####
rm(list=ls(all=TRUE)[-which(ls(all=TRUE)==dir.path_no_coc_100_200)]);setwd(dir.path_no_coc_100_200)
sim.dir<-"6-2014/"
dir.create(sim.dir, showWarnings = TRUE, recursive = TRUE) 


spec_seed<-6
loc_seed<-2014
spec_num<-100
locs_num<-200
lon_0<-85
lat_0<-45
my_proj<-CRS(paste("+proj=laea +lon_0=",lon_0," +lat_0=",lat_0," +x_0=0 +y_0=0 +ellps=WGS84 +units=m +no_defs",sep="")) 
grid_size<-100000
div<-1000

data(countriesCoarseLessIslands)
data(countriesCoarseLessIslands)
eurasia<-countriesCoarseLessIslands[grep("Eurasia",countriesCoarseLessIslands$continent),]
eu<-unionSpatialPolygons(eurasia, cut(coordinates(eurasia)[,1], range(coordinates(eurasia)[,1]), include.lowest=F))
poly<-eu@polygons[[1]]@Polygons[47][[1]]@coords
poly<-as.matrix(poly)
Sr1 = Polygon(poly)
Srs1 = Polygons(list(Sr1), "s1")
SpP = SpatialPolygons(list(Srs1))
proj4string(SpP)<-CRS("+proj=longlat +ellps=WGS84 +datum=WGS84 +no_defs")
spTransform(SpP,CRS=my_proj)->SpP_prj


set.seed(spec_seed)
origins<-spsample(SpP, spec_num,type="clustered",nclusters=150)
origins<-as.data.frame(origins)
data_ck<-origins
coordinates(data_ck)<-~x1+x2
clarkevans.test(as(data_ck,"ppp"),alternative="clustered")

set.seed(spec_seed)
acca<-rbeta(100,1,5)
range(acca)

length(acca)
set.seed(spec_seed)
abba<-sample(2^(rnorm(100,log(1000,2),log(1000,2)/10)),100)
sort(acca)->acca
sort(abba)->abba

seed<-seq(1:100)
x_zero<-list()
brown.points<-list()
temp_sample<-list()
for(i in 1:100){
  set.seed(seed[i])
  x_zero[[i]]<-as.vector(origins[sample(as.numeric(rownames(origins)),1),])
  set.seed(seed[i])
  brown.points[[i]]<-simm.mou(date=1:abba[i] ,b=c(sample(seq(from=x_zero[[i]]$x1,to=x_zero[[i]]$x1+(5),by=1),1),sample(seq(from=x_zero[[i]]$x2,to=x_zero[[i]]$x2+(5),by=1),1)),a=diag(c(acca[i]/div,acca[i]/div)),x0=c(x_zero[[i]]$x1,x_zero[[i]]$x2)) 
  brown.points[[i]]<-brown.points[[i]][[1]][,1:2]
  temp_sample[[i]]<-brown.points[[i]]
  try(temp_sample[[i]]<-cbind(temp_sample[[i]], paste("spec", i, sep="")),silent=F)
  print(i)
}
gc()

temp_population<-list()
pops<-list()
for(i in 1:nrow(origins)){
  try(colnames(temp_sample[[i]])[3]<-"spec",silent=F)
  try(temp_population[[i]]<-temp_sample[[i]][which(point.in.polygon(temp_sample[[i]]$x,temp_sample[[i]]$y, SpP@polygons[[1]]@Polygons[[1]]@coords[,1],SpP@polygons[[1]]@Polygons[[1]]@coords[,2])>0),],silent=F)
  try(coordinates(temp_population[[i]])<-~x+y,silent=F)
  try(proj4string(temp_population[[i]])<-CRS("+proj=longlat +ellps=WGS84 +datum=WGS84 +no_defs"),silent=F)
  try(pops[[i]]<-temp_population[[i]][SpP,],silent=F)
  print(i)
}
populations<-do.call(rbind, pops)

spTransform(populations,CRS=my_proj)->prj_populations
extent(prj_populations)[1:2]->x_lim
extent(prj_populations)[3:4]->y_lim
sampling_grid<-expand.grid(x=seq(from=x_lim[1],to=x_lim[2],grid_size),y=seq(from=y_lim[1],to=y_lim[2],grid_size))
sampling_grid->prediction_ground
prediction_ground$z<-1
rasterFromXYZ(prediction_ground)->prediction_ground
crs(prediction_ground)<-my_proj
mask(prediction_ground,SpP_prj)->prediction_ground
coordinates(sampling_grid)<-~x+y
gridded(sampling_grid)<-TRUE
crs(sampling_grid)<-my_proj
as(sampling_grid,"SpatialPolygons")->sampling_grid
lapply(pops,function(x)spTransform(x,CRS=my_proj))->prj_pops

cl <- makeCluster(2, type="SOCK")
registerDoSNOW (cl)
foreach(i=1:length(prj_pops),.packages=c("raster")) %dopar% {
  over(prj_pops[[i]],sampling_grid)->original_over_res
}->original_over_res
stopCluster(cl)
doParallel::stopImplicitCluster()
##

lapply(original_over_res,function(x){sampling_grid[unique(x)[!is.na(unique(x))]]->x;
  return(x)})->real_poly
for(i in 1:length(real_poly)) {
  rgeos::gUnaryUnion(real_poly[[i]])->real_poly[[i]]
  print(i)
}
##

sapply(real_poly,function(x)gArea(x))->areas

lapply(pops,function(x)unique(as.character(x$spec)))->pops_names
names(pops)<-pops_names
names(prj_pops)<-pops_names
names(real_poly)<-pops_names


set.seed(loc_seed)
sim_locs<-spsample(SpP_prj,locs_num,type = "clustered",nclusters=90)

lapply(real_poly,function(x){
  over(x,sim_locs,returnList=TRUE)  
})->over_res
which(sapply(over_res,function(x)length(x[[1]])!=0))->valid_specs
over_res[valid_specs]->over_res
over_res<-mapply(function(x,y) {data.frame(x,spec=rep(y,length(x)))->z;
  return(z)},over_res,names(over_res),SIMPLIFY = FALSE)
lapply(over_res,function(x){sim_locs[x$X1,]->z;
  z$loc_id<-x$X1;
  return(z)})->over_res
over_res<-mapply(function(x,y) { as.data.frame(x)->x;
  x$spec<-y;
  return(x)}, over_res,names(over_res),SIMPLIFY = FALSE )
over_res<-do.call(rbind,over_res)
rownames(over_res)<-NULL
colnames(over_res)[2:3]<-c("x","y")
coordinates(over_res)<-~x+y
crs(over_res)<-my_proj
over_res->general_sim_dat
spTransform(general_sim_dat,CRS=CRS("+proj=longlat +datum=WGS84"))->general_sim_dat
general_sim_dat<-as.data.frame(general_sim_dat)
as.character(general_sim_dat$spec)->general_sim_dat$spec
general_sim_dat->general_sim_locs
general_sim_locs$age<-1

set.seed(2047)
summary(to_rem<-round(rnorm(length(unique(general_sim_locs$loc_id)), mean=30,sd=10)))
id_list<-unique(general_sim_locs$loc_id)
reduce_list<-function(x,y,seed){
  to_keep<-sample(which(general_sim_locs$loc_id%in%x),round(length(which(general_sim_locs$loc_id%in%x))*((100-y)/100)))
  reduced_general_sim_locs<-general_sim_locs[to_keep,]
  return(reduced_general_sim_locs)
}
reduced_general_sim_locs<-mapply(function(x,y) reduce_list(x,y,seed=39), id_list, to_rem,SIMPLIFY=FALSE )
reduced_general_sim_locs<-do.call(rbind,reduced_general_sim_locs)
rownames(reduced_general_sim_locs)<-NULL


#### Performing MInOSSE ####
Sys.getenv("R_MAX_NUM_DLLs", unset = NA)
unique(as.character(reduced_general_sim_locs$spec))->spec_list

minosse_dat<-list()
minosse_res_list<-list()
for(i in 1:length(spec_list)){
  if(class(try(minosse_dat[[i]]<-minosse.data(
    obj=reduced_general_sim_locs,
    species_name=spec_list[i],
    domain="land",
    coc.by=NULL,
    min.occs=3,
    abiotic.covs=NULL,
    combine.covs=FALSE,   
    reduce_covs_by="pca",
    covs_th=0.95,
    c.size=100000,
    bkg.predictors="presence", 
    min.bkg=100,
    sampling.by.distance=TRUE,
    prediction.ground=prediction_ground,
    crop.by.mcp=FALSE,
    projection="laea",
    lon_0=85,
    lat_0=45,
    n.clusters="automatic", 
    seed=625)
  ))=="try-error") {next} else {minosse_dat[[i]]<-minosse_dat[[i]];
  
  
  if(class(try(minosse_res_list[[i]]<-minosse.target(
    resp=minosse_dat[[i]][[1]],
    predictors=minosse_dat[[i]][[2]],
    bkg="presence",
    min.bkg = 100,
    n.sims=10,
    sampling.by.distance=TRUE,
    n.folds=n.folds,
    n.sims.clusters="automatic",
    seed=625)))=="try-error") {next} else minosse_res_list[[i]]<-minosse_res_list[[i]] 
  }
  print(i)
}
gc()

#### save ####
save.image(paste(sim.dir,"200_100_clus_min_6_2014_no_coc.RData",sep=""))
##


#### seed 2014,  randomly distributed spatial simulations ####
rm(list=ls(all=TRUE)[-which(ls(all=TRUE)==dir.path_no_coc_100_200)]);setwd(dir.path_no_coc_100_200)
sim.dir<-"6-2014/"
dir.create(sim.dir, showWarnings = TRUE, recursive = TRUE) 

spec_seed<-6
loc_seed<-2014
spec_num<-100
locs_num<-200
lon_0<-85
lat_0<-45
my_proj<-CRS(paste("+proj=laea +lon_0=",lon_0," +lat_0=",lat_0," +x_0=0 +y_0=0 +ellps=WGS84 +units=m +no_defs",sep="")) 
grid_size<-100000
div<-1000

data(countriesCoarseLessIslands)
data(countriesCoarseLessIslands)
eurasia<-countriesCoarseLessIslands[grep("Eurasia",countriesCoarseLessIslands$continent),]
eu<-unionSpatialPolygons(eurasia, cut(coordinates(eurasia)[,1], range(coordinates(eurasia)[,1]), include.lowest=F))
poly<-eu@polygons[[1]]@Polygons[47][[1]]@coords
poly<-as.matrix(poly)
Sr1 = Polygon(poly)
Srs1 = Polygons(list(Sr1), "s1")
SpP = SpatialPolygons(list(Srs1))
proj4string(SpP)<-CRS("+proj=longlat +ellps=WGS84 +datum=WGS84 +no_defs")
spTransform(SpP,CRS=my_proj)->SpP_prj


set.seed(spec_seed)
origins<-spsample(SpP, spec_num,type="random")
origins<-as.data.frame(origins)
data_ck<-origins
coordinates(data_ck)<-~x+y
clarkevans.test(as(data_ck,"ppp"),alternative="clustered")

set.seed(spec_seed)
acca<-rbeta(100,1,5)
range(acca)

length(acca)

set.seed(spec_seed)
abba<-sample(2^(rnorm(100,log(1000,2),log(1000,2)/10)),100)
sort(acca)->acca
sort(abba)->abba

seed<-seq(1:100)
x_zero<-list()
brown.points<-list()
temp_sample<-list()
for(i in 1:100){
  set.seed(seed[i])
  x_zero[[i]]<-as.vector(origins[sample(as.numeric(rownames(origins)),1),])
  set.seed(seed[i])
  brown.points[[i]]<-simm.mou(date=1:abba[i],b=c(sample(seq(from=x_zero[[i]]$x,to=x_zero[[i]]$x+(5),by=1),1),sample(seq(from=x_zero[[i]]$y,to=x_zero[[i]]$y+(5),by=1),1)),a=diag(c(acca[i]/div,acca[i]/div)),x0=c(x_zero[[i]]$x,x_zero[[i]]$y)) 
  brown.points[[i]]<-brown.points[[i]][[1]][,1:2]
  temp_sample[[i]]<-brown.points[[i]]
  try(temp_sample[[i]]<-cbind(temp_sample[[i]], paste("spec", i, sep="")),silent=F)
  print(i)
}
gc()

temp_population<-list()
pops<-list()
for(i in 1:nrow(origins)){
  try(colnames(temp_sample[[i]])[3]<-"spec",silent=F)
  try(temp_population[[i]]<-temp_sample[[i]][which(point.in.polygon(temp_sample[[i]]$x,temp_sample[[i]]$y, SpP@polygons[[1]]@Polygons[[1]]@coords[,1],SpP@polygons[[1]]@Polygons[[1]]@coords[,2])>0),],silent=F)
  try(coordinates(temp_population[[i]])<-~x+y,silent=F)
  try(proj4string(temp_population[[i]])<-CRS("+proj=longlat +ellps=WGS84 +datum=WGS84 +no_defs"),silent=F)
  try(pops[[i]]<-temp_population[[i]][SpP,],silent=F)
  print(i)
}
populations<-do.call(rbind, pops)

spTransform(populations,CRS=my_proj)->prj_populations
extent(prj_populations)[1:2]->x_lim
extent(prj_populations)[3:4]->y_lim
sampling_grid<-expand.grid(x=seq(from=x_lim[1],to=x_lim[2],grid_size),y=seq(from=y_lim[1],to=y_lim[2],grid_size))
sampling_grid->prediction_ground
prediction_ground$z<-1
rasterFromXYZ(prediction_ground)->prediction_ground
crs(prediction_ground)<-my_proj
mask(prediction_ground,SpP_prj)->prediction_ground
coordinates(sampling_grid)<-~x+y
gridded(sampling_grid)<-TRUE
crs(sampling_grid)<-my_proj
as(sampling_grid,"SpatialPolygons")->sampling_grid
lapply(pops,function(x)spTransform(x,CRS=my_proj))->prj_pops

cl <- makeCluster(2, type="SOCK")
registerDoSNOW (cl)
foreach(i=1:length(prj_pops),.packages=c("raster")) %dopar% {
  over(prj_pops[[i]],sampling_grid)->original_over_res
}->original_over_res
stopCluster(cl)
doParallel::stopImplicitCluster()
##

lapply(original_over_res,function(x){sampling_grid[unique(x)[!is.na(unique(x))]]->x;
  return(x)})->real_poly
for(i in 1:length(real_poly)) {
  rgeos::gUnaryUnion(real_poly[[i]])->real_poly[[i]]
  print(i)
}
##

sapply(real_poly,function(x)gArea(x))->areas

lapply(pops,function(x)unique(as.character(x$spec)))->pops_names
names(pops)<-pops_names
names(prj_pops)<-pops_names
names(real_poly)<-pops_names


set.seed(loc_seed)
sim_locs<-spsample(SpP_prj,locs_num,type = "random")

lapply(real_poly,function(x){
  over(x,sim_locs,returnList=TRUE)  
})->over_res
which(sapply(over_res,function(x)length(x[[1]])!=0))->valid_specs
over_res[valid_specs]->over_res
over_res<-mapply(function(x,y) {data.frame(x,spec=rep(y,length(x)))->z;
  return(z)},over_res,names(over_res),SIMPLIFY = FALSE)
lapply(over_res,function(x){sim_locs[x$X1,]->z;
  z$loc_id<-x$X1;
  return(z)})->over_res
over_res<-mapply(function(x,y) { as.data.frame(x)->x;
  x$spec<-y;
  return(x)}, over_res,names(over_res),SIMPLIFY = FALSE )
over_res<-do.call(rbind,over_res)
rownames(over_res)<-NULL
colnames(over_res)[2:3]<-c("x","y")
coordinates(over_res)<-~x+y
crs(over_res)<-my_proj
over_res->general_sim_dat
spTransform(general_sim_dat,CRS=CRS("+proj=longlat +datum=WGS84"))->general_sim_dat
general_sim_dat<-as.data.frame(general_sim_dat)
as.character(general_sim_dat$spec)->general_sim_dat$spec
general_sim_dat->general_sim_locs
general_sim_locs$age<-1

set.seed(2047)
summary(to_rem<-round(rnorm(length(unique(general_sim_locs$loc_id)), mean=30,sd=10)))
id_list<-unique(general_sim_locs$loc_id)
reduce_list<-function(x,y,seed){
  to_keep<-sample(which(general_sim_locs$loc_id%in%x),round(length(which(general_sim_locs$loc_id%in%x))*((100-y)/100)))
  reduced_general_sim_locs<-general_sim_locs[to_keep,]
  return(reduced_general_sim_locs)
}
reduced_general_sim_locs<-mapply(function(x,y) reduce_list(x,y,seed=39), id_list, to_rem,SIMPLIFY=FALSE )
reduced_general_sim_locs<-do.call(rbind,reduced_general_sim_locs)
rownames(reduced_general_sim_locs)<-NULL


#### Performing MInOSSE ####
Sys.getenv("R_MAX_NUM_DLLs", unset = NA)
unique(as.character(reduced_general_sim_locs$spec))->spec_list

minosse_dat<-list()
minosse_res_list<-list()
for(i in 1:length(spec_list)){
  if(class(try(minosse_dat[[i]]<-minosse.data(
    obj=reduced_general_sim_locs,
    species_name=spec_list[i],
    domain="land",
    coc.by=NULL,
    min.occs=3,
    abiotic.covs=NULL,
    combine.covs=FALSE,   
    reduce_covs_by="pca",
    covs_th=0.95,
    c.size=100000,
    bkg.predictors="presence", 
    min.bkg=100,
    sampling.by.distance=TRUE,
    prediction.ground=prediction_ground,
    crop.by.mcp=FALSE,
    projection="laea",
    lon_0=85,
    lat_0=45,
    n.clusters="automatic", 
    seed=625)
  ))=="try-error") {next} else {minosse_dat[[i]]<-minosse_dat[[i]];
  
  
  if(class(try(minosse_res_list[[i]]<-minosse.target(
    resp=minosse_dat[[i]][[1]],
    predictors=minosse_dat[[i]][[2]],
    bkg="presence",
    min.bkg = 100,
    n.sims=10,
    sampling.by.distance=TRUE,
    n.folds=n.folds,
    n.sims.clusters="automatic",
    seed=625)))=="try-error") {next} else minosse_res_list[[i]]<-minosse_res_list[[i]] 
  }
  print(i)
}
gc()


#### save ####
save.image(paste(sim.dir,"200_100_random_6_2014_no_coc.RData",sep=""))
##





#### seed 2014,  uniformly distributed spatial simulations ####
rm(list=ls(all=TRUE)[-which(ls(all=TRUE)==dir.path_no_coc_100_200)]);setwd(dir.path_no_coc_100_200)
sim.dir<-"6-2014/"
dir.create(sim.dir, showWarnings = TRUE, recursive = TRUE) 


spec_seed<-6
loc_seed<-2014
spec_num<-100
locs_num<-200
lon_0<-85
lat_0<-45
my_proj<-CRS(paste("+proj=laea +lon_0=",lon_0," +lat_0=",lat_0," +x_0=0 +y_0=0 +ellps=WGS84 +units=m +no_defs",sep="")) 
grid_size<-100000
div<-1000

data(countriesCoarseLessIslands)
data(countriesCoarseLessIslands)
eurasia<-countriesCoarseLessIslands[grep("Eurasia",countriesCoarseLessIslands$continent),]
eu<-unionSpatialPolygons(eurasia, cut(coordinates(eurasia)[,1], range(coordinates(eurasia)[,1]), include.lowest=F))
poly<-eu@polygons[[1]]@Polygons[47][[1]]@coords
poly<-as.matrix(poly)
Sr1 = Polygon(poly)
Srs1 = Polygons(list(Sr1), "s1")
SpP = SpatialPolygons(list(Srs1))
proj4string(SpP)<-CRS("+proj=longlat +ellps=WGS84 +datum=WGS84 +no_defs")
spTransform(SpP,CRS=my_proj)->SpP_prj


set.seed(spec_seed)
origins<-spsample(SpP, spec_num,type="regular")
origins<-as.data.frame(origins)

data_ck<-origins
coordinates(data_ck)<-~x1+x2
clarkevans.test(as(data_ck,"ppp"),alternative="clustered")

set.seed(spec_seed)
acca<-rbeta(100,1,5)
range(acca)

length(acca)

set.seed(spec_seed)
abba<-sample(2^(rnorm(100,log(1000,2),log(1000,2)/10)),100)
sort(acca)->acca
sort(abba)->abba

seed<-seq(1:100)
x_zero<-list()
brown.points<-list()
temp_sample<-list()
for(i in 1:100){
  set.seed(seed[i])
  x_zero[[i]]<-as.vector(origins[sample(as.numeric(rownames(origins)),1),])
  set.seed(seed[i])
  brown.points[[i]]<-simm.mou(date=1:abba[i],b=c(sample(seq(from=x_zero[[i]]$x1,to=x_zero[[i]]$x1+(5),by=1),1),sample(seq(from=x_zero[[i]]$x2,to=x_zero[[i]]$x2+(5),by=1),1)),a=diag(c(acca[i]/div,acca[i]/div)),x0=c(x_zero[[i]]$x1,x_zero[[i]]$x2)) 
  brown.points[[i]]<-brown.points[[i]][[1]][,1:2]
  temp_sample[[i]]<-brown.points[[i]]
  try(temp_sample[[i]]<-cbind(temp_sample[[i]], paste("spec", i, sep="")),silent=F)
  print(i)
}
gc()

temp_population<-list()
pops<-list()
for(i in 1:nrow(origins)){
  try(colnames(temp_sample[[i]])[3]<-"spec",silent=F)
  try(temp_population[[i]]<-temp_sample[[i]][which(point.in.polygon(temp_sample[[i]]$x,temp_sample[[i]]$y, SpP@polygons[[1]]@Polygons[[1]]@coords[,1],SpP@polygons[[1]]@Polygons[[1]]@coords[,2])>0),],silent=F)
  try(coordinates(temp_population[[i]])<-~x+y,silent=F)
  try(proj4string(temp_population[[i]])<-CRS("+proj=longlat +ellps=WGS84 +datum=WGS84 +no_defs"),silent=F)
  try(pops[[i]]<-temp_population[[i]][SpP,],silent=F)
  print(i)
}
populations<-do.call(rbind, pops)

spTransform(populations,CRS=my_proj)->prj_populations
extent(prj_populations)[1:2]->x_lim
extent(prj_populations)[3:4]->y_lim
sampling_grid<-expand.grid(x=seq(from=x_lim[1],to=x_lim[2],grid_size),y=seq(from=y_lim[1],to=y_lim[2],grid_size))
sampling_grid->prediction_ground
prediction_ground$z<-1
rasterFromXYZ(prediction_ground)->prediction_ground
crs(prediction_ground)<-my_proj
mask(prediction_ground,SpP_prj)->prediction_ground
coordinates(sampling_grid)<-~x+y
gridded(sampling_grid)<-TRUE
crs(sampling_grid)<-my_proj
as(sampling_grid,"SpatialPolygons")->sampling_grid
lapply(pops,function(x)spTransform(x,CRS=my_proj))->prj_pops

cl <- makeCluster(1, type="SOCK")
registerDoSNOW (cl)
foreach(i=1:length(prj_pops),.packages=c("raster")) %dopar% {
  over(prj_pops[[i]],sampling_grid)->original_over_res
}->original_over_res
stopCluster(cl)
doParallel::stopImplicitCluster()
##

lapply(original_over_res,function(x){sampling_grid[unique(x)[!is.na(unique(x))]]->x;
  return(x)})->real_poly
for(i in 1:length(real_poly)) {
  rgeos::gUnaryUnion(real_poly[[i]])->real_poly[[i]]
  print(i)
}
##

sapply(real_poly,function(x)gArea(x))->areas
lapply(pops,function(x)unique(as.character(x$spec)))->pops_names
names(pops)<-pops_names
names(prj_pops)<-pops_names
names(real_poly)<-pops_names


set.seed(loc_seed)
sim_locs<-spsample(SpP_prj,locs_num,type = "regular")

lapply(real_poly,function(x){
  over(x,sim_locs,returnList=TRUE)  
})->over_res
which(sapply(over_res,function(x)length(x[[1]])!=0))->valid_specs
over_res[valid_specs]->over_res
over_res<-mapply(function(x,y) {data.frame(x,spec=rep(y,length(x)))->z;
  return(z)},over_res,names(over_res),SIMPLIFY = FALSE)
lapply(over_res,function(x){sim_locs[x$X1,]->z;
  z$loc_id<-x$X1;
  return(z)})->over_res
over_res<-mapply(function(x,y) { as.data.frame(x)->x;
  x$spec<-y;
  return(x)}, over_res,names(over_res),SIMPLIFY = FALSE )
over_res<-do.call(rbind,over_res)
rownames(over_res)<-NULL
colnames(over_res)[2:3]<-c("x","y")
coordinates(over_res)<-~x+y
crs(over_res)<-my_proj
over_res->general_sim_dat
spTransform(general_sim_dat,CRS=CRS("+proj=longlat +datum=WGS84"))->general_sim_dat
general_sim_dat<-as.data.frame(general_sim_dat)
as.character(general_sim_dat$spec)->general_sim_dat$spec
general_sim_dat->general_sim_locs
general_sim_locs$age<-1

set.seed(2047)
summary(to_rem<-round(rnorm(length(unique(general_sim_locs$loc_id)), mean=30,sd=10)))
id_list<-unique(general_sim_locs$loc_id)
reduce_list<-function(x,y,seed){
  to_keep<-sample(which(general_sim_locs$loc_id%in%x),round(length(which(general_sim_locs$loc_id%in%x))*((100-y)/100)))
  reduced_general_sim_locs<-general_sim_locs[to_keep,]
  return(reduced_general_sim_locs)
}
reduced_general_sim_locs<-mapply(function(x,y) reduce_list(x,y,seed=39), id_list, to_rem,SIMPLIFY=FALSE )
reduced_general_sim_locs<-do.call(rbind,reduced_general_sim_locs)
rownames(reduced_general_sim_locs)<-NULL


#### Performing MInOSSE ####
Sys.getenv("R_MAX_NUM_DLLs", unset = NA)
unique(as.character(reduced_general_sim_locs$spec))->spec_list

minosse_dat<-list()
minosse_res_list<-list()
for(i in 1:length(spec_list)){
  if(class(try(minosse_dat[[i]]<-minosse.data(
    obj=reduced_general_sim_locs,
    species_name=spec_list[i],
    domain="land",
    coc.by=NULL,
    min.occs=3,
    abiotic.covs=NULL,
    combine.covs=FALSE,   
    reduce_covs_by="pca",
    covs_th=0.95,
    c.size=100000,
    bkg.predictors="presence", 
    min.bkg=100,
    sampling.by.distance=TRUE,
    prediction.ground=prediction_ground,
    crop.by.mcp=FALSE,
    projection="laea",
    lon_0=85,
    lat_0=45,
    n.clusters="automatic", 
    seed=625)
  ))=="try-error") {next} else {minosse_dat[[i]]<-minosse_dat[[i]];
  
  
  if(class(try(minosse_res_list[[i]]<-minosse.target(
    resp=minosse_dat[[i]][[1]],
    predictors=minosse_dat[[i]][[2]],
    bkg="presence",
    min.bkg = 100,
    n.sims=10,
    sampling.by.distance=TRUE,
    n.folds=n.folds,
    n.sims.clusters="automatic",
    seed=625)))=="try-error") {next} else minosse_res_list[[i]]<-minosse_res_list[[i]] 
  }
  print(i)
}
gc()


#### save ####
save.image(paste(sim.dir,"200_100_uniform_6_2014_no_coc.RData",sep=""))
##




#### seed 1789,  highly clustered spatial simulations ####
rm(list=ls(all=TRUE)[-which(ls(all=TRUE)==dir.path_no_coc_100_200)]);setwd(dir.path_no_coc_100_200)
sim.dir<-"7-1789/"
dir.create(sim.dir, showWarnings = TRUE, recursive = TRUE) 

spec_seed<-7
loc_seed<-1789
spec_num<-100
locs_num<-200
lon_0<-85
lat_0<-45
my_proj<-CRS(paste("+proj=laea +lon_0=",lon_0," +lat_0=",lat_0," +x_0=0 +y_0=0 +ellps=WGS84 +units=m +no_defs",sep="")) 
grid_size<-100000
div<-1000

data(countriesCoarseLessIslands)
data(countriesCoarseLessIslands)
eurasia<-countriesCoarseLessIslands[grep("Eurasia",countriesCoarseLessIslands$continent),]
eu<-unionSpatialPolygons(eurasia, cut(coordinates(eurasia)[,1], range(coordinates(eurasia)[,1]), include.lowest=F))
poly<-eu@polygons[[1]]@Polygons[47][[1]]@coords
poly<-as.matrix(poly)
Sr1 = Polygon(poly)
Srs1 = Polygons(list(Sr1), "s1")
SpP = SpatialPolygons(list(Srs1))
proj4string(SpP)<-CRS("+proj=longlat +ellps=WGS84 +datum=WGS84 +no_defs")
spTransform(SpP,CRS=my_proj)->SpP_prj


set.seed(spec_seed)
origins<-spsample(SpP, spec_num,type="clustered",nclusters=100)
origins<-as.data.frame(origins)
data_ck<-origins
coordinates(data_ck)<-~x1+x2
clarkevans.test(as(data_ck,"ppp"),alternative="clustered")

set.seed(spec_seed)
acca<-rbeta(100,1,5)
range(acca)

length(acca)

set.seed(spec_seed)
abba<-sample(2^(rnorm(100,log(1000,2),log(1000,2)/10)),100)
sort(acca)->acca
sort(abba)->abba

seed<-seq(1:100)
x_zero<-list()
brown.points<-list()
temp_sample<-list()
for(i in 1:100){
  set.seed(seed[i])
  x_zero[[i]]<-as.vector(origins[sample(as.numeric(rownames(origins)),1),])
  set.seed(seed[i])
  brown.points[[i]]<-simm.mou(date=1:abba[i] ,b=c(sample(seq(from=x_zero[[i]]$x1,to=x_zero[[i]]$x1+(5),by=1),1),sample(seq(from=x_zero[[i]]$x2,to=x_zero[[i]]$x2+(5),by=1),1)),a=diag(c(acca[i]/div,acca[i]/div)),x0=c(x_zero[[i]]$x1,x_zero[[i]]$x2)) 
  brown.points[[i]]<-brown.points[[i]][[1]][,1:2]
  temp_sample[[i]]<-brown.points[[i]]
  try(temp_sample[[i]]<-cbind(temp_sample[[i]], paste("spec", i, sep="")),silent=F)
  print(i)
}
gc()

temp_population<-list()
pops<-list()
for(i in 1:nrow(origins)){
  try(colnames(temp_sample[[i]])[3]<-"spec",silent=F)
  try(temp_population[[i]]<-temp_sample[[i]][which(point.in.polygon(temp_sample[[i]]$x,temp_sample[[i]]$y, SpP@polygons[[1]]@Polygons[[1]]@coords[,1],SpP@polygons[[1]]@Polygons[[1]]@coords[,2])>0),],silent=F)
  try(coordinates(temp_population[[i]])<-~x+y,silent=F)
  try(proj4string(temp_population[[i]])<-CRS("+proj=longlat +ellps=WGS84 +datum=WGS84 +no_defs"),silent=F)
  try(pops[[i]]<-temp_population[[i]][SpP,],silent=F)
  print(i)
}
populations<-do.call(rbind, pops)

spTransform(populations,CRS=my_proj)->prj_populations
extent(prj_populations)[1:2]->x_lim
extent(prj_populations)[3:4]->y_lim
sampling_grid<-expand.grid(x=seq(from=x_lim[1],to=x_lim[2],grid_size),y=seq(from=y_lim[1],to=y_lim[2],grid_size))
sampling_grid->prediction_ground
prediction_ground$z<-1
rasterFromXYZ(prediction_ground)->prediction_ground
crs(prediction_ground)<-my_proj
mask(prediction_ground,SpP_prj)->prediction_ground
coordinates(sampling_grid)<-~x+y
gridded(sampling_grid)<-TRUE
crs(sampling_grid)<-my_proj
as(sampling_grid,"SpatialPolygons")->sampling_grid
lapply(pops,function(x)spTransform(x,CRS=my_proj))->prj_pops

cl <- makeCluster(2, type="SOCK")
registerDoSNOW (cl)
foreach(i=1:length(prj_pops),.packages=c("raster")) %dopar% {
  over(prj_pops[[i]],sampling_grid)->original_over_res
}->original_over_res
stopCluster(cl)
doParallel::stopImplicitCluster()
##

lapply(original_over_res,function(x){sampling_grid[unique(x)[!is.na(unique(x))]]->x;
  return(x)})->real_poly
for(i in 1:length(real_poly)) {
  rgeos::gUnaryUnion(real_poly[[i]])->real_poly[[i]]
  print(i)
}
##

sapply(real_poly,function(x)gArea(x))->areas
sapply(pops,function(x)length(x))->abundance

lapply(pops,function(x)unique(as.character(x$spec)))->pops_names
names(pops)<-pops_names
names(prj_pops)<-pops_names
names(real_poly)<-pops_names


set.seed(loc_seed)
sim_locs<-spsample(SpP_prj,locs_num,type = "clustered",nclusters=50)

lapply(real_poly,function(x){
  over(x,sim_locs,returnList=TRUE)  
})->over_res
which(sapply(over_res,function(x)length(x[[1]])!=0))->valid_specs
over_res[valid_specs]->over_res
over_res<-mapply(function(x,y) {data.frame(x,spec=rep(y,length(x)))->z;
  return(z)},over_res,names(over_res),SIMPLIFY = FALSE)
lapply(over_res,function(x){sim_locs[x$X1,]->z;
  z$loc_id<-x$X1;
  return(z)})->over_res
over_res<-mapply(function(x,y) { as.data.frame(x)->x;
  x$spec<-y;
  return(x)}, over_res,names(over_res),SIMPLIFY = FALSE )
over_res<-do.call(rbind,over_res)
rownames(over_res)<-NULL
colnames(over_res)[2:3]<-c("x","y")
coordinates(over_res)<-~x+y
crs(over_res)<-my_proj
over_res->general_sim_dat
spTransform(general_sim_dat,CRS=CRS("+proj=longlat +datum=WGS84"))->general_sim_dat
general_sim_dat<-as.data.frame(general_sim_dat)
as.character(general_sim_dat$spec)->general_sim_dat$spec
general_sim_dat->general_sim_locs
general_sim_locs$age<-1

set.seed(2047)
summary(to_rem<-round(rnorm(length(unique(general_sim_locs$loc_id)), mean=30,sd=10)))
id_list<-unique(general_sim_locs$loc_id)
reduce_list<-function(x,y,seed){
  to_keep<-sample(which(general_sim_locs$loc_id%in%x),round(length(which(general_sim_locs$loc_id%in%x))*((100-y)/100)))
  reduced_general_sim_locs<-general_sim_locs[to_keep,]
  return(reduced_general_sim_locs)
}
reduced_general_sim_locs<-mapply(function(x,y) reduce_list(x,y,seed=39), id_list, to_rem,SIMPLIFY=FALSE )
reduced_general_sim_locs<-do.call(rbind,reduced_general_sim_locs)
rownames(reduced_general_sim_locs)<-NULL



#### Performing MInOSSE ####
Sys.getenv("R_MAX_NUM_DLLs", unset = NA)
unique(as.character(reduced_general_sim_locs$spec))->spec_list

minosse_dat<-list()
minosse_res_list<-list()
for(i in 1:length(spec_list)){
  if(class(try(minosse_dat[[i]]<-minosse.data(
    obj=reduced_general_sim_locs,
    species_name=spec_list[i],
    domain="land",
    coc.by=NULL,
    min.occs=3,
    abiotic.covs=NULL,
    combine.covs=FALSE,   
    reduce_covs_by="pca",
    covs_th=0.95,
    c.size=100000,
    bkg.predictors="presence", 
    min.bkg=100,
    sampling.by.distance=TRUE,
    prediction.ground=prediction_ground,
    crop.by.mcp=FALSE,
    projection="laea",
    lon_0=85,
    lat_0=45,
    n.clusters="automatic", 
    seed=625)
  ))=="try-error") {next} else {minosse_dat[[i]]<-minosse_dat[[i]];
  
  
  if(class(try(minosse_res_list[[i]]<-minosse.target(
    resp=minosse_dat[[i]][[1]],
    predictors=minosse_dat[[i]][[2]],
    bkg="presence",
    min.bkg = 100,
    n.sims=10,
    sampling.by.distance=TRUE,
    n.folds=n.folds,
    n.sims.clusters="automatic",
    seed=625)))=="try-error") {next} else minosse_res_list[[i]]<-minosse_res_list[[i]] 
  }
  print(i)
}
gc()


#### save ####
save.image(paste(sim.dir,"200_100_clus_max_7_1789_no_coc.RData",sep=""))
###


#### seed 1789,  moderately clustered spatial simulations ####
rm(list=ls(all=TRUE)[-which(ls(all=TRUE)==dir.path_no_coc_100_200)]);setwd(dir.path_no_coc_100_200)
sim.dir<-"7-1789/"
dir.create(sim.dir, showWarnings = TRUE, recursive = TRUE) 

spec_seed<-7
loc_seed<-1789
spec_num<-100
locs_num<-200
lon_0<-85
lat_0<-45
my_proj<-CRS(paste("+proj=laea +lon_0=",lon_0," +lat_0=",lat_0," +x_0=0 +y_0=0 +ellps=WGS84 +units=m +no_defs",sep="")) 
grid_size<-100000
div<-1000

data(countriesCoarseLessIslands)
data(countriesCoarseLessIslands)
eurasia<-countriesCoarseLessIslands[grep("Eurasia",countriesCoarseLessIslands$continent),]
eu<-unionSpatialPolygons(eurasia, cut(coordinates(eurasia)[,1], range(coordinates(eurasia)[,1]), include.lowest=F))
poly<-eu@polygons[[1]]@Polygons[47][[1]]@coords
poly<-as.matrix(poly)
Sr1 = Polygon(poly)
Srs1 = Polygons(list(Sr1), "s1")
SpP = SpatialPolygons(list(Srs1))
proj4string(SpP)<-CRS("+proj=longlat +ellps=WGS84 +datum=WGS84 +no_defs")
spTransform(SpP,CRS=my_proj)->SpP_prj


set.seed(spec_seed)
origins<-spsample(SpP, spec_num,type="clustered",nclusters=150)
origins<-as.data.frame(origins)
data_ck<-origins
coordinates(data_ck)<-~x1+x2
clarkevans.test(as(data_ck,"ppp"),alternative="clustered")

set.seed(spec_seed)
acca<-rbeta(100,1,5)
range(acca)

length(acca)
set.seed(spec_seed)
abba<-sample(2^(rnorm(100,log(1000,2),log(1000,2)/10)),100)
sort(acca)->acca
sort(abba)->abba

seed<-seq(1:100)
x_zero<-list()
brown.points<-list()
temp_sample<-list()
for(i in 1:100){
  set.seed(seed[i])
  x_zero[[i]]<-as.vector(origins[sample(as.numeric(rownames(origins)),1),])
  set.seed(seed[i])
  brown.points[[i]]<-simm.mou(date=1:abba[i] ,b=c(sample(seq(from=x_zero[[i]]$x1,to=x_zero[[i]]$x1+(5),by=1),1),sample(seq(from=x_zero[[i]]$x2,to=x_zero[[i]]$x2+(5),by=1),1)),a=diag(c(acca[i]/div,acca[i]/div)),x0=c(x_zero[[i]]$x1,x_zero[[i]]$x2)) 
  brown.points[[i]]<-brown.points[[i]][[1]][,1:2]
  temp_sample[[i]]<-brown.points[[i]]
  try(temp_sample[[i]]<-cbind(temp_sample[[i]], paste("spec", i, sep="")),silent=F)
  print(i)
}
gc()

temp_population<-list()
pops<-list()
for(i in 1:nrow(origins)){
  try(colnames(temp_sample[[i]])[3]<-"spec",silent=F)
  try(temp_population[[i]]<-temp_sample[[i]][which(point.in.polygon(temp_sample[[i]]$x,temp_sample[[i]]$y, SpP@polygons[[1]]@Polygons[[1]]@coords[,1],SpP@polygons[[1]]@Polygons[[1]]@coords[,2])>0),],silent=F)
  try(coordinates(temp_population[[i]])<-~x+y,silent=F)
  try(proj4string(temp_population[[i]])<-CRS("+proj=longlat +ellps=WGS84 +datum=WGS84 +no_defs"),silent=F)
  try(pops[[i]]<-temp_population[[i]][SpP,],silent=F)
  print(i)
}
populations<-do.call(rbind, pops)
spTransform(populations,CRS=my_proj)->prj_populations
extent(prj_populations)[1:2]->x_lim
extent(prj_populations)[3:4]->y_lim
sampling_grid<-expand.grid(x=seq(from=x_lim[1],to=x_lim[2],grid_size),y=seq(from=y_lim[1],to=y_lim[2],grid_size))
sampling_grid->prediction_ground
prediction_ground$z<-1
rasterFromXYZ(prediction_ground)->prediction_ground
crs(prediction_ground)<-my_proj
mask(prediction_ground,SpP_prj)->prediction_ground
coordinates(sampling_grid)<-~x+y
gridded(sampling_grid)<-TRUE
crs(sampling_grid)<-my_proj
as(sampling_grid,"SpatialPolygons")->sampling_grid
lapply(pops,function(x)spTransform(x,CRS=my_proj))->prj_pops

cl <- makeCluster(2, type="SOCK")
registerDoSNOW (cl)
foreach(i=1:length(prj_pops),.packages=c("raster")) %dopar% {
  over(prj_pops[[i]],sampling_grid)->original_over_res
}->original_over_res
stopCluster(cl)
doParallel::stopImplicitCluster()
##

lapply(original_over_res,function(x){sampling_grid[unique(x)[!is.na(unique(x))]]->x;
  return(x)})->real_poly
for(i in 1:length(real_poly)) {
  rgeos::gUnaryUnion(real_poly[[i]])->real_poly[[i]]
  print(i)
}
##

sapply(real_poly,function(x)gArea(x))->areas
lapply(pops,function(x)unique(as.character(x$spec)))->pops_names
names(pops)<-pops_names
names(prj_pops)<-pops_names
names(real_poly)<-pops_names


set.seed(loc_seed)
sim_locs<-spsample(SpP_prj,locs_num,type = "clustered",nclusters=90)

lapply(real_poly,function(x){
  over(x,sim_locs,returnList=TRUE)  
})->over_res
which(sapply(over_res,function(x)length(x[[1]])!=0))->valid_specs
over_res[valid_specs]->over_res
over_res<-mapply(function(x,y) {data.frame(x,spec=rep(y,length(x)))->z;
  return(z)},over_res,names(over_res),SIMPLIFY = FALSE)
lapply(over_res,function(x){sim_locs[x$X1,]->z;
  z$loc_id<-x$X1;
  return(z)})->over_res
over_res<-mapply(function(x,y) { as.data.frame(x)->x;
  x$spec<-y;
  return(x)}, over_res,names(over_res),SIMPLIFY = FALSE )
over_res<-do.call(rbind,over_res)
rownames(over_res)<-NULL
colnames(over_res)[2:3]<-c("x","y")
coordinates(over_res)<-~x+y
crs(over_res)<-my_proj
over_res->general_sim_dat
spTransform(general_sim_dat,CRS=CRS("+proj=longlat +datum=WGS84"))->general_sim_dat
general_sim_dat<-as.data.frame(general_sim_dat)
as.character(general_sim_dat$spec)->general_sim_dat$spec
general_sim_dat->general_sim_locs
general_sim_locs$age<-1

set.seed(2047)
summary(to_rem<-round(rnorm(length(unique(general_sim_locs$loc_id)), mean=30,sd=10)))
id_list<-unique(general_sim_locs$loc_id)
reduce_list<-function(x,y,seed){
  to_keep<-sample(which(general_sim_locs$loc_id%in%x),round(length(which(general_sim_locs$loc_id%in%x))*((100-y)/100)))
  reduced_general_sim_locs<-general_sim_locs[to_keep,]
  return(reduced_general_sim_locs)
}
reduced_general_sim_locs<-mapply(function(x,y) reduce_list(x,y,seed=39), id_list, to_rem,SIMPLIFY=FALSE )
reduced_general_sim_locs<-do.call(rbind,reduced_general_sim_locs)
rownames(reduced_general_sim_locs)<-NULL


#### Performing MInOSSE ####
Sys.getenv("R_MAX_NUM_DLLs", unset = NA)
unique(as.character(reduced_general_sim_locs$spec))->spec_list

minosse_dat<-list()
minosse_res_list<-list()
for(i in 1:length(spec_list)){
  if(class(try(minosse_dat[[i]]<-minosse.data(
    obj=reduced_general_sim_locs,
    species_name=spec_list[i],
    domain="land",
    coc.by=NULL,
    min.occs=3,
    abiotic.covs=NULL,
    combine.covs=FALSE,   
    reduce_covs_by="pca",
    covs_th=0.95,
    c.size=100000,
    bkg.predictors="presence", 
    min.bkg=100,
    sampling.by.distance=TRUE,
    prediction.ground=prediction_ground,
    crop.by.mcp=FALSE,
    projection="laea",
    lon_0=85,
    lat_0=45,
    n.clusters="automatic", 
    seed=625)
  ))=="try-error") {next} else {minosse_dat[[i]]<-minosse_dat[[i]];
  
  
  if(class(try(minosse_res_list[[i]]<-minosse.target(
    resp=minosse_dat[[i]][[1]],
    predictors=minosse_dat[[i]][[2]],
    bkg="presence",
    min.bkg = 100,
    n.sims=10,
    sampling.by.distance=TRUE,
    n.folds=n.folds,
    n.sims.clusters="automatic",
    seed=625)))=="try-error") {next} else minosse_res_list[[i]]<-minosse_res_list[[i]] 
  }
  print(i)
}
gc()


#### save ####
save.image(paste(sim.dir,"200_100_clus_min_7_1789_no_coc.RData",sep=""))
##


#### seed 1789,  randomly distributed spatial simulations ####
rm(list=ls(all=TRUE)[-which(ls(all=TRUE)==dir.path_no_coc_100_200)]);setwd(dir.path_no_coc_100_200)
sim.dir<-"7-1789/"
dir.create(sim.dir, showWarnings = TRUE, recursive = TRUE) 

spec_seed<-7
loc_seed<-1789
spec_num<-100
locs_num<-200
lon_0<-85
lat_0<-45
my_proj<-CRS(paste("+proj=laea +lon_0=",lon_0," +lat_0=",lat_0," +x_0=0 +y_0=0 +ellps=WGS84 +units=m +no_defs",sep="")) 
grid_size<-100000
div<-1000

data(countriesCoarseLessIslands)
data(countriesCoarseLessIslands)
eurasia<-countriesCoarseLessIslands[grep("Eurasia",countriesCoarseLessIslands$continent),]
eu<-unionSpatialPolygons(eurasia, cut(coordinates(eurasia)[,1], range(coordinates(eurasia)[,1]), include.lowest=F))
poly<-eu@polygons[[1]]@Polygons[47][[1]]@coords
poly<-as.matrix(poly)
Sr1 = Polygon(poly)
Srs1 = Polygons(list(Sr1), "s1")
SpP = SpatialPolygons(list(Srs1))
proj4string(SpP)<-CRS("+proj=longlat +ellps=WGS84 +datum=WGS84 +no_defs")
spTransform(SpP,CRS=my_proj)->SpP_prj


set.seed(spec_seed)
origins<-spsample(SpP, spec_num,type="random")
origins<-as.data.frame(origins)
data_ck<-origins
coordinates(data_ck)<-~x+y
clarkevans.test(as(data_ck,"ppp"),alternative="clustered")

set.seed(spec_seed)
acca<-rbeta(100,1,5)
range(acca)

length(acca)

set.seed(spec_seed)
abba<-sample(2^(rnorm(100,log(1000,2),log(1000,2)/10)),100)
sort(acca)->acca
sort(abba)->abba

seed<-seq(1:100)
x_zero<-list()
brown.points<-list()
temp_sample<-list()
for(i in 1:100){
  set.seed(seed[i])
  x_zero[[i]]<-as.vector(origins[sample(as.numeric(rownames(origins)),1),])
  set.seed(seed[i])
  brown.points[[i]]<-simm.mou(date=1:abba[i],b=c(sample(seq(from=x_zero[[i]]$x,to=x_zero[[i]]$x+(5),by=1),1),sample(seq(from=x_zero[[i]]$y,to=x_zero[[i]]$y+(5),by=1),1)),a=diag(c(acca[i]/div,acca[i]/div)),x0=c(x_zero[[i]]$x,x_zero[[i]]$y)) 
  brown.points[[i]]<-brown.points[[i]][[1]][,1:2]
  temp_sample[[i]]<-brown.points[[i]]
  try(temp_sample[[i]]<-cbind(temp_sample[[i]], paste("spec", i, sep="")),silent=F)
  print(i)
}
gc()

temp_population<-list()
pops<-list()
for(i in 1:nrow(origins)){
  try(colnames(temp_sample[[i]])[3]<-"spec",silent=F)
  try(temp_population[[i]]<-temp_sample[[i]][which(point.in.polygon(temp_sample[[i]]$x,temp_sample[[i]]$y, SpP@polygons[[1]]@Polygons[[1]]@coords[,1],SpP@polygons[[1]]@Polygons[[1]]@coords[,2])>0),],silent=F)
  try(coordinates(temp_population[[i]])<-~x+y,silent=F)
  try(proj4string(temp_population[[i]])<-CRS("+proj=longlat +ellps=WGS84 +datum=WGS84 +no_defs"),silent=F)
  try(pops[[i]]<-temp_population[[i]][SpP,],silent=F)
  print(i)
}
populations<-do.call(rbind, pops)

spTransform(populations,CRS=my_proj)->prj_populations
extent(prj_populations)[1:2]->x_lim
extent(prj_populations)[3:4]->y_lim
sampling_grid<-expand.grid(x=seq(from=x_lim[1],to=x_lim[2],grid_size),y=seq(from=y_lim[1],to=y_lim[2],grid_size))
sampling_grid->prediction_ground
prediction_ground$z<-1
rasterFromXYZ(prediction_ground)->prediction_ground
crs(prediction_ground)<-my_proj
mask(prediction_ground,SpP_prj)->prediction_ground
coordinates(sampling_grid)<-~x+y
gridded(sampling_grid)<-TRUE
crs(sampling_grid)<-my_proj
as(sampling_grid,"SpatialPolygons")->sampling_grid
lapply(pops,function(x)spTransform(x,CRS=my_proj))->prj_pops

cl <- makeCluster(2, type="SOCK")
registerDoSNOW (cl)
foreach(i=1:length(prj_pops),.packages=c("raster")) %dopar% {
  over(prj_pops[[i]],sampling_grid)->original_over_res
}->original_over_res
stopCluster(cl)
doParallel::stopImplicitCluster()
##

lapply(original_over_res,function(x){sampling_grid[unique(x)[!is.na(unique(x))]]->x;
  return(x)})->real_poly
for(i in 1:length(real_poly)) {
  rgeos::gUnaryUnion(real_poly[[i]])->real_poly[[i]]
  print(i)
}
##

sapply(real_poly,function(x)gArea(x))->areas

lapply(pops,function(x)unique(as.character(x$spec)))->pops_names
names(pops)<-pops_names
names(prj_pops)<-pops_names
names(real_poly)<-pops_names


set.seed(loc_seed)
sim_locs<-spsample(SpP_prj,locs_num,type = "random")

lapply(real_poly,function(x){
  over(x,sim_locs,returnList=TRUE)  
})->over_res
which(sapply(over_res,function(x)length(x[[1]])!=0))->valid_specs
over_res[valid_specs]->over_res
over_res<-mapply(function(x,y) {data.frame(x,spec=rep(y,length(x)))->z;
  return(z)},over_res,names(over_res),SIMPLIFY = FALSE)
lapply(over_res,function(x){sim_locs[x$X1,]->z;
  z$loc_id<-x$X1;
  return(z)})->over_res
over_res<-mapply(function(x,y) { as.data.frame(x)->x;
  x$spec<-y;
  return(x)}, over_res,names(over_res),SIMPLIFY = FALSE )
over_res<-do.call(rbind,over_res)
rownames(over_res)<-NULL
colnames(over_res)[2:3]<-c("x","y")
coordinates(over_res)<-~x+y
crs(over_res)<-my_proj
over_res->general_sim_dat
spTransform(general_sim_dat,CRS=CRS("+proj=longlat +datum=WGS84"))->general_sim_dat
general_sim_dat<-as.data.frame(general_sim_dat)
as.character(general_sim_dat$spec)->general_sim_dat$spec
general_sim_dat->general_sim_locs
general_sim_locs$age<-1

set.seed(2047)
summary(to_rem<-round(rnorm(length(unique(general_sim_locs$loc_id)), mean=30,sd=10)))
id_list<-unique(general_sim_locs$loc_id)
reduce_list<-function(x,y,seed){
  to_keep<-sample(which(general_sim_locs$loc_id%in%x),round(length(which(general_sim_locs$loc_id%in%x))*((100-y)/100)))
  reduced_general_sim_locs<-general_sim_locs[to_keep,]
  return(reduced_general_sim_locs)
}
reduced_general_sim_locs<-mapply(function(x,y) reduce_list(x,y,seed=39), id_list, to_rem,SIMPLIFY=FALSE )
reduced_general_sim_locs<-do.call(rbind,reduced_general_sim_locs)
rownames(reduced_general_sim_locs)<-NULL


#### Performing MInOSSE ####
Sys.getenv("R_MAX_NUM_DLLs", unset = NA)
unique(as.character(reduced_general_sim_locs$spec))->spec_list

minosse_dat<-list()
minosse_res_list<-list()
for(i in 1:length(spec_list)){
  if(class(try(minosse_dat[[i]]<-minosse.data(
    obj=reduced_general_sim_locs,
    species_name=spec_list[i],
    domain="land",
    coc.by=NULL,
    min.occs=3,
    abiotic.covs=NULL,
    combine.covs=FALSE,   
    reduce_covs_by="pca",
    covs_th=0.95,
    c.size=100000,
    bkg.predictors="presence", 
    min.bkg=100,
    sampling.by.distance=TRUE,
    prediction.ground=prediction_ground,
    crop.by.mcp=FALSE,
    projection="laea",
    lon_0=85,
    lat_0=45,
    n.clusters="automatic", 
    seed=625)
  ))=="try-error") {next} else {minosse_dat[[i]]<-minosse_dat[[i]];
  
  
  if(class(try(minosse_res_list[[i]]<-minosse.target(
    resp=minosse_dat[[i]][[1]],
    predictors=minosse_dat[[i]][[2]],
    bkg="presence",
    min.bkg = 100,
    n.sims=10,
    sampling.by.distance=TRUE,
    n.folds=n.folds,
    n.sims.clusters="automatic",
    seed=625)))=="try-error") {next} else minosse_res_list[[i]]<-minosse_res_list[[i]] 
  }
  print(i)
}
gc()


#### save ####
save.image(paste(sim.dir,"200_100_random_7_1789_no_coc.RData",sep=""))
##


#### seed 1789,  uniformly distributed spatial simulations ####
rm(list=ls(all=TRUE)[-which(ls(all=TRUE)==dir.path_no_coc_100_200)]);setwd(dir.path_no_coc_100_200)
sim.dir<-"7-1789/"
dir.create(sim.dir, showWarnings = TRUE, recursive = TRUE) 

spec_seed<-7
loc_seed<-1789
spec_num<-100
locs_num<-200
lon_0<-85
lat_0<-45
my_proj<-CRS(paste("+proj=laea +lon_0=",lon_0," +lat_0=",lat_0," +x_0=0 +y_0=0 +ellps=WGS84 +units=m +no_defs",sep="")) 
grid_size<-100000
div<-1000

data(countriesCoarseLessIslands)
data(countriesCoarseLessIslands)
eurasia<-countriesCoarseLessIslands[grep("Eurasia",countriesCoarseLessIslands$continent),]
eu<-unionSpatialPolygons(eurasia, cut(coordinates(eurasia)[,1], range(coordinates(eurasia)[,1]), include.lowest=F))
poly<-eu@polygons[[1]]@Polygons[47][[1]]@coords
poly<-as.matrix(poly)
Sr1 = Polygon(poly)
Srs1 = Polygons(list(Sr1), "s1")
SpP = SpatialPolygons(list(Srs1))
proj4string(SpP)<-CRS("+proj=longlat +ellps=WGS84 +datum=WGS84 +no_defs")
spTransform(SpP,CRS=my_proj)->SpP_prj


set.seed(spec_seed)
origins<-spsample(SpP, spec_num,type="regular")
origins<-as.data.frame(origins)
data_ck<-origins
coordinates(data_ck)<-~x1+x2
clarkevans.test(as(data_ck,"ppp"),alternative="clustered")

set.seed(spec_seed)
acca<-rbeta(100,1,5)
range(acca)

length(acca)

set.seed(spec_seed)
abba<-sample(2^(rnorm(100,log(1000,2),log(1000,2)/10)),100)
sort(acca)->acca
sort(abba)->abba

seed<-seq(1:100)
x_zero<-list()
brown.points<-list()
temp_sample<-list()
for(i in 1:100){
  set.seed(seed[i])
  x_zero[[i]]<-as.vector(origins[sample(as.numeric(rownames(origins)),1),])
  set.seed(seed[i])
  brown.points[[i]]<-simm.mou(date=1:abba[i],b=c(sample(seq(from=x_zero[[i]]$x1,to=x_zero[[i]]$x1+(5),by=1),1),sample(seq(from=x_zero[[i]]$x2,to=x_zero[[i]]$x2+(5),by=1),1)),a=diag(c(acca[i]/div,acca[i]/div)),x0=c(x_zero[[i]]$x1,x_zero[[i]]$x2)) 
  brown.points[[i]]<-brown.points[[i]][[1]][,1:2]
  temp_sample[[i]]<-brown.points[[i]]
  try(temp_sample[[i]]<-cbind(temp_sample[[i]], paste("spec", i, sep="")),silent=F)
  print(i)
}
gc()

temp_population<-list()
pops<-list()
for(i in 1:nrow(origins)){
  try(colnames(temp_sample[[i]])[3]<-"spec",silent=F)
  try(temp_population[[i]]<-temp_sample[[i]][which(point.in.polygon(temp_sample[[i]]$x,temp_sample[[i]]$y, SpP@polygons[[1]]@Polygons[[1]]@coords[,1],SpP@polygons[[1]]@Polygons[[1]]@coords[,2])>0),],silent=F)
  try(coordinates(temp_population[[i]])<-~x+y,silent=F)
  try(proj4string(temp_population[[i]])<-CRS("+proj=longlat +ellps=WGS84 +datum=WGS84 +no_defs"),silent=F)
  try(pops[[i]]<-temp_population[[i]][SpP,],silent=F)
  print(i)
}
populations<-do.call(rbind, pops)

spTransform(populations,CRS=my_proj)->prj_populations
extent(prj_populations)[1:2]->x_lim
extent(prj_populations)[3:4]->y_lim
sampling_grid<-expand.grid(x=seq(from=x_lim[1],to=x_lim[2],grid_size),y=seq(from=y_lim[1],to=y_lim[2],grid_size))
sampling_grid->prediction_ground
prediction_ground$z<-1
rasterFromXYZ(prediction_ground)->prediction_ground
crs(prediction_ground)<-my_proj
mask(prediction_ground,SpP_prj)->prediction_ground
coordinates(sampling_grid)<-~x+y
gridded(sampling_grid)<-TRUE
crs(sampling_grid)<-my_proj
as(sampling_grid,"SpatialPolygons")->sampling_grid
lapply(pops,function(x)spTransform(x,CRS=my_proj))->prj_pops

cl <- makeCluster(2, type="SOCK")
registerDoSNOW (cl)
foreach(i=1:length(prj_pops),.packages=c("raster")) %dopar% {
  over(prj_pops[[i]],sampling_grid)->original_over_res
}->original_over_res
stopCluster(cl)
doParallel::stopImplicitCluster()
##

lapply(original_over_res,function(x){sampling_grid[unique(x)[!is.na(unique(x))]]->x;
  return(x)})->real_poly
for(i in 1:length(real_poly)) {
  rgeos::gUnaryUnion(real_poly[[i]])->real_poly[[i]]
  print(i)
}
##

sapply(real_poly,function(x)gArea(x))->areas

lapply(pops,function(x)unique(as.character(x$spec)))->pops_names
names(pops)<-pops_names
names(prj_pops)<-pops_names
names(real_poly)<-pops_names


set.seed(loc_seed)
sim_locs<-spsample(SpP_prj,locs_num,type = "regular")

lapply(real_poly,function(x){
  over(x,sim_locs,returnList=TRUE)  
})->over_res
which(sapply(over_res,function(x)length(x[[1]])!=0))->valid_specs
over_res[valid_specs]->over_res
over_res<-mapply(function(x,y) {data.frame(x,spec=rep(y,length(x)))->z;
  return(z)},over_res,names(over_res),SIMPLIFY = FALSE)
lapply(over_res,function(x){sim_locs[x$X1,]->z;
  z$loc_id<-x$X1;
  return(z)})->over_res
over_res<-mapply(function(x,y) { as.data.frame(x)->x;
  x$spec<-y;
  return(x)}, over_res,names(over_res),SIMPLIFY = FALSE )
over_res<-do.call(rbind,over_res)
rownames(over_res)<-NULL
colnames(over_res)[2:3]<-c("x","y")
coordinates(over_res)<-~x+y
crs(over_res)<-my_proj
over_res->general_sim_dat
spTransform(general_sim_dat,CRS=CRS("+proj=longlat +datum=WGS84"))->general_sim_dat
general_sim_dat<-as.data.frame(general_sim_dat)
as.character(general_sim_dat$spec)->general_sim_dat$spec
general_sim_dat->general_sim_locs
general_sim_locs$age<-1

set.seed(2047)
summary(to_rem<-round(rnorm(length(unique(general_sim_locs$loc_id)), mean=30,sd=10)))
id_list<-unique(general_sim_locs$loc_id)
reduce_list<-function(x,y,seed){
  to_keep<-sample(which(general_sim_locs$loc_id%in%x),round(length(which(general_sim_locs$loc_id%in%x))*((100-y)/100)))
  reduced_general_sim_locs<-general_sim_locs[to_keep,]
  return(reduced_general_sim_locs)
}
reduced_general_sim_locs<-mapply(function(x,y) reduce_list(x,y,seed=39), id_list, to_rem,SIMPLIFY=FALSE )
reduced_general_sim_locs<-do.call(rbind,reduced_general_sim_locs)
rownames(reduced_general_sim_locs)<-NULL


#### Performing MInOSSE ####
Sys.getenv("R_MAX_NUM_DLLs", unset = NA)
unique(as.character(reduced_general_sim_locs$spec))->spec_list

minosse_dat<-list()
minosse_res_list<-list()
for(i in 1:length(spec_list)){
  if(class(try(minosse_dat[[i]]<-minosse.data(
    obj=reduced_general_sim_locs,
    species_name=spec_list[i],
    domain="land",
    coc.by=NULL,
    min.occs=3,
    abiotic.covs=NULL,
    combine.covs=FALSE,   
    reduce_covs_by="pca",
    covs_th=0.95,
    c.size=100000,
    bkg.predictors="presence", 
    min.bkg=100,
    sampling.by.distance=TRUE,
    prediction.ground=prediction_ground,
    crop.by.mcp=FALSE,
    projection="laea",
    lon_0=85,
    lat_0=45,
    n.clusters="automatic", 
    seed=625)
  ))=="try-error") {next} else {minosse_dat[[i]]<-minosse_dat[[i]];
  
  
  if(class(try(minosse_res_list[[i]]<-minosse.target(
    resp=minosse_dat[[i]][[1]],
    predictors=minosse_dat[[i]][[2]],
    bkg="presence",
    min.bkg = 100,
    n.sims=10,
    sampling.by.distance=TRUE,
    n.folds=n.folds,
    n.sims.clusters="automatic",
    seed=625)))=="try-error") {next} else minosse_res_list[[i]]<-minosse_res_list[[i]] 
  }
  print(i)
}
gc()


#### save ####
save.image(paste(sim.dir,"200_100_uniform_7_1789_no_coc.RData",sep=""))
##









#### seed 1979,  highly clustered spatial simulations ####
rm(list=ls(all=TRUE)[-which(ls(all=TRUE)==dir.path_no_coc_100_200)]);setwd(dir.path_no_coc_100_200)
sim.dir<-"1979-2015/"
dir.create(sim.dir, showWarnings = TRUE, recursive = TRUE) 

spec_seed<-1979
loc_seed<-2015
spec_num<-100
locs_num<-200
lon_0<-85
lat_0<-45
my_proj<-CRS(paste("+proj=laea +lon_0=",lon_0," +lat_0=",lat_0," +x_0=0 +y_0=0 +ellps=WGS84 +units=m +no_defs",sep="")) 
grid_size<-100000
div<-1000

data(countriesCoarseLessIslands)
data(countriesCoarseLessIslands)
eurasia<-countriesCoarseLessIslands[grep("Eurasia",countriesCoarseLessIslands$continent),]
eu<-unionSpatialPolygons(eurasia, cut(coordinates(eurasia)[,1], range(coordinates(eurasia)[,1]), include.lowest=F))
poly<-eu@polygons[[1]]@Polygons[47][[1]]@coords
poly<-as.matrix(poly)
Sr1 = Polygon(poly)
Srs1 = Polygons(list(Sr1), "s1")
SpP = SpatialPolygons(list(Srs1))
proj4string(SpP)<-CRS("+proj=longlat +ellps=WGS84 +datum=WGS84 +no_defs")
spTransform(SpP,CRS=my_proj)->SpP_prj


set.seed(spec_seed)
origins<-spsample(SpP, spec_num,type="clustered",nclusters=100)
origins<-as.data.frame(origins)
data_ck<-origins
coordinates(data_ck)<-~x1+x2
clarkevans.test(as(data_ck,"ppp"),alternative="clustered")

set.seed(spec_seed)
acca<-rbeta(100,1,5)
range(acca)

length(acca)

set.seed(spec_seed)
abba<-sample(2^(rnorm(100,log(1000,2),log(1000,2)/10)),100)
sort(acca)->acca
sort(abba)->abba

seed<-seq(1:100)
x_zero<-list()
brown.points<-list()
temp_sample<-list()
for(i in 1:100){
  set.seed(seed[i])
  x_zero[[i]]<-as.vector(origins[sample(as.numeric(rownames(origins)),1),])
  set.seed(seed[i])
  brown.points[[i]]<-simm.mou(date=1:abba[i] ,b=c(sample(seq(from=x_zero[[i]]$x1,to=x_zero[[i]]$x1+(5),by=1),1),sample(seq(from=x_zero[[i]]$x2,to=x_zero[[i]]$x2+(5),by=1),1)),a=diag(c(acca[i]/div,acca[i]/div)),x0=c(x_zero[[i]]$x1,x_zero[[i]]$x2)) 
  brown.points[[i]]<-brown.points[[i]][[1]][,1:2]
  temp_sample[[i]]<-brown.points[[i]]
  try(temp_sample[[i]]<-cbind(temp_sample[[i]], paste("spec", i, sep="")),silent=F)
  print(i)
}
gc()

temp_population<-list()
pops<-list()
for(i in 1:nrow(origins)){
  try(colnames(temp_sample[[i]])[3]<-"spec",silent=F)
  try(temp_population[[i]]<-temp_sample[[i]][which(point.in.polygon(temp_sample[[i]]$x,temp_sample[[i]]$y, SpP@polygons[[1]]@Polygons[[1]]@coords[,1],SpP@polygons[[1]]@Polygons[[1]]@coords[,2])>0),],silent=F)
  try(coordinates(temp_population[[i]])<-~x+y,silent=F)
  try(proj4string(temp_population[[i]])<-CRS("+proj=longlat +ellps=WGS84 +datum=WGS84 +no_defs"),silent=F)
  try(pops[[i]]<-temp_population[[i]][SpP,],silent=F)
  print(i)
}
populations<-do.call(rbind, pops)
spTransform(populations,CRS=my_proj)->prj_populations
extent(prj_populations)[1:2]->x_lim
extent(prj_populations)[3:4]->y_lim
sampling_grid<-expand.grid(x=seq(from=x_lim[1],to=x_lim[2],grid_size),y=seq(from=y_lim[1],to=y_lim[2],grid_size))
sampling_grid->prediction_ground
prediction_ground$z<-1
rasterFromXYZ(prediction_ground)->prediction_ground
crs(prediction_ground)<-my_proj
mask(prediction_ground,SpP_prj)->prediction_ground
coordinates(sampling_grid)<-~x+y
gridded(sampling_grid)<-TRUE
crs(sampling_grid)<-my_proj
as(sampling_grid,"SpatialPolygons")->sampling_grid
lapply(pops,function(x)spTransform(x,CRS=my_proj))->prj_pops

cl <- makeCluster(2, type="SOCK")
registerDoSNOW (cl)
foreach(i=1:length(prj_pops),.packages=c("raster")) %dopar% {
  over(prj_pops[[i]],sampling_grid)->original_over_res
}->original_over_res
stopCluster(cl)
doParallel::stopImplicitCluster()
##

lapply(original_over_res,function(x){sampling_grid[unique(x)[!is.na(unique(x))]]->x;
  return(x)})->real_poly
for(i in 1:length(real_poly)) {
  rgeos::gUnaryUnion(real_poly[[i]])->real_poly[[i]]
  print(i)
}
##

sapply(real_poly,function(x)gArea(x))->areas

sapply(pops,function(x)length(x))->abundance

lapply(pops,function(x)unique(as.character(x$spec)))->pops_names
names(pops)<-pops_names
names(prj_pops)<-pops_names
names(real_poly)<-pops_names


set.seed(loc_seed)
sim_locs<-spsample(SpP_prj,locs_num,type = "clustered",nclusters=50)

lapply(real_poly,function(x){
  over(x,sim_locs,returnList=TRUE)  
})->over_res
which(sapply(over_res,function(x)length(x[[1]])!=0))->valid_specs
over_res[valid_specs]->over_res
over_res<-mapply(function(x,y) {data.frame(x,spec=rep(y,length(x)))->z;
  return(z)},over_res,names(over_res),SIMPLIFY = FALSE)
lapply(over_res,function(x){sim_locs[x$X1,]->z;
  z$loc_id<-x$X1;
  return(z)})->over_res
over_res<-mapply(function(x,y) { as.data.frame(x)->x;
  x$spec<-y;
  return(x)}, over_res,names(over_res),SIMPLIFY = FALSE )
over_res<-do.call(rbind,over_res)
rownames(over_res)<-NULL
colnames(over_res)[2:3]<-c("x","y")
coordinates(over_res)<-~x+y
crs(over_res)<-my_proj
over_res->general_sim_dat
spTransform(general_sim_dat,CRS=CRS("+proj=longlat +datum=WGS84"))->general_sim_dat
general_sim_dat<-as.data.frame(general_sim_dat)
as.character(general_sim_dat$spec)->general_sim_dat$spec
general_sim_dat->general_sim_locs
general_sim_locs$age<-1

set.seed(2047)
summary(to_rem<-round(rnorm(length(unique(general_sim_locs$loc_id)), mean=30,sd=10)))
id_list<-unique(general_sim_locs$loc_id)
reduce_list<-function(x,y,seed){
  to_keep<-sample(which(general_sim_locs$loc_id%in%x),round(length(which(general_sim_locs$loc_id%in%x))*((100-y)/100)))
  reduced_general_sim_locs<-general_sim_locs[to_keep,]
  return(reduced_general_sim_locs)
}
reduced_general_sim_locs<-mapply(function(x,y) reduce_list(x,y,seed=39), id_list, to_rem,SIMPLIFY=FALSE )
reduced_general_sim_locs<-do.call(rbind,reduced_general_sim_locs)
rownames(reduced_general_sim_locs)<-NULL


#### Performing MInOSSE ####
Sys.getenv("R_MAX_NUM_DLLs", unset = NA)
unique(as.character(reduced_general_sim_locs$spec))->spec_list

minosse_dat<-list()
minosse_res_list<-list()
for(i in 1:length(spec_list)){
  if(class(try(minosse_dat[[i]]<-minosse.data(
    obj=reduced_general_sim_locs,
    species_name=spec_list[i],
    domain="land",
    coc.by=NULL,
    min.occs=3,
    abiotic.covs=NULL,
    combine.covs=FALSE,   
    reduce_covs_by="pca",
    covs_th=0.95,
    c.size=100000,
    bkg.predictors="presence", 
    min.bkg=100,
    sampling.by.distance=TRUE,
    prediction.ground=prediction_ground,
    crop.by.mcp=FALSE,
    projection="laea",
    lon_0=85,
    lat_0=45,
    n.clusters="automatic", 
    seed=625)
  ))=="try-error") {next} else {minosse_dat[[i]]<-minosse_dat[[i]];
  
  
  if(class(try(minosse_res_list[[i]]<-minosse.target(
    resp=minosse_dat[[i]][[1]],
    predictors=minosse_dat[[i]][[2]],
    bkg="presence",
    min.bkg = 100,
    n.sims=10,
    sampling.by.distance=TRUE,
    n.folds=n.folds,
    n.sims.clusters="automatic",
    seed=625)))=="try-error") {next} else minosse_res_list[[i]]<-minosse_res_list[[i]] 
  }
  print(i)
}
gc()


#### save ####
save.image(paste(sim.dir,"200_100_clus_max_1979_2015_no_coc.RData",sep=""))
##
###










#### seed 1979,  moderately clustered spatial simulations ####
rm(list=ls(all=TRUE)[-which(ls(all=TRUE)==dir.path_no_coc_100_200)]);setwd(dir.path_no_coc_100_200)
sim.dir<-"1979-2015/"
dir.create(sim.dir, showWarnings = TRUE, recursive = TRUE) 

spec_seed<-1979
loc_seed<-2015
spec_num<-100
locs_num<-200
lon_0<-85
lat_0<-45
my_proj<-CRS(paste("+proj=laea +lon_0=",lon_0," +lat_0=",lat_0," +x_0=0 +y_0=0 +ellps=WGS84 +units=m +no_defs",sep="")) 
grid_size<-100000
div<-1000

data(countriesCoarseLessIslands)
data(countriesCoarseLessIslands)
eurasia<-countriesCoarseLessIslands[grep("Eurasia",countriesCoarseLessIslands$continent),]
eu<-unionSpatialPolygons(eurasia, cut(coordinates(eurasia)[,1], range(coordinates(eurasia)[,1]), include.lowest=F))
poly<-eu@polygons[[1]]@Polygons[47][[1]]@coords
poly<-as.matrix(poly)
Sr1 = Polygon(poly)
Srs1 = Polygons(list(Sr1), "s1")
SpP = SpatialPolygons(list(Srs1))
proj4string(SpP)<-CRS("+proj=longlat +ellps=WGS84 +datum=WGS84 +no_defs")
spTransform(SpP,CRS=my_proj)->SpP_prj


set.seed(spec_seed)
origins<-spsample(SpP, spec_num,type="clustered",nclusters=150)
origins<-as.data.frame(origins)
data_ck<-origins
coordinates(data_ck)<-~x1+x2
clarkevans.test(as(data_ck,"ppp"),alternative="clustered")

set.seed(spec_seed)
acca<-rbeta(100,1,5)
range(acca)

length(acca)
set.seed(spec_seed)
abba<-sample(2^(rnorm(100,log(1000,2),log(1000,2)/10)),100)
sort(acca)->acca
sort(abba)->abba

seed<-seq(1:100)
x_zero<-list()
brown.points<-list()
temp_sample<-list()
for(i in 1:100){
  set.seed(seed[i])
  x_zero[[i]]<-as.vector(origins[sample(as.numeric(rownames(origins)),1),])
  set.seed(seed[i])
  brown.points[[i]]<-simm.mou(date=1:abba[i] ,b=c(sample(seq(from=x_zero[[i]]$x1,to=x_zero[[i]]$x1+(5),by=1),1),sample(seq(from=x_zero[[i]]$x2,to=x_zero[[i]]$x2+(5),by=1),1)),a=diag(c(acca[i]/div,acca[i]/div)),x0=c(x_zero[[i]]$x1,x_zero[[i]]$x2)) 
  brown.points[[i]]<-brown.points[[i]][[1]][,1:2]
  temp_sample[[i]]<-brown.points[[i]]
  try(temp_sample[[i]]<-cbind(temp_sample[[i]], paste("spec", i, sep="")),silent=F)
  print(i)
}
gc()

temp_population<-list()
pops<-list()
for(i in 1:nrow(origins)){
  try(colnames(temp_sample[[i]])[3]<-"spec",silent=F)
  try(temp_population[[i]]<-temp_sample[[i]][which(point.in.polygon(temp_sample[[i]]$x,temp_sample[[i]]$y, SpP@polygons[[1]]@Polygons[[1]]@coords[,1],SpP@polygons[[1]]@Polygons[[1]]@coords[,2])>0),],silent=F)
  try(coordinates(temp_population[[i]])<-~x+y,silent=F)
  try(proj4string(temp_population[[i]])<-CRS("+proj=longlat +ellps=WGS84 +datum=WGS84 +no_defs"),silent=F)
  try(pops[[i]]<-temp_population[[i]][SpP,],silent=F)
  print(i)
}
populations<-do.call(rbind, pops)
spTransform(populations,CRS=my_proj)->prj_populations
extent(prj_populations)[1:2]->x_lim
extent(prj_populations)[3:4]->y_lim
sampling_grid<-expand.grid(x=seq(from=x_lim[1],to=x_lim[2],grid_size),y=seq(from=y_lim[1],to=y_lim[2],grid_size))
sampling_grid->prediction_ground
prediction_ground$z<-1
rasterFromXYZ(prediction_ground)->prediction_ground
crs(prediction_ground)<-my_proj
mask(prediction_ground,SpP_prj)->prediction_ground
coordinates(sampling_grid)<-~x+y
gridded(sampling_grid)<-TRUE
crs(sampling_grid)<-my_proj
as(sampling_grid,"SpatialPolygons")->sampling_grid
lapply(pops,function(x)spTransform(x,CRS=my_proj))->prj_pops

cl <- makeCluster(2, type="SOCK")
registerDoSNOW (cl)
foreach(i=1:length(prj_pops),.packages=c("raster")) %dopar% {
  over(prj_pops[[i]],sampling_grid)->original_over_res
}->original_over_res
stopCluster(cl)
doParallel::stopImplicitCluster()
##

lapply(original_over_res,function(x){sampling_grid[unique(x)[!is.na(unique(x))]]->x;
  return(x)})->real_poly
for(i in 1:length(real_poly)) {
  rgeos::gUnaryUnion(real_poly[[i]])->real_poly[[i]]
  print(i)
}
##

sapply(real_poly,function(x)gArea(x))->areas
lapply(pops,function(x)unique(as.character(x$spec)))->pops_names
names(pops)<-pops_names
names(prj_pops)<-pops_names
names(real_poly)<-pops_names


set.seed(loc_seed)
sim_locs<-spsample(SpP_prj,locs_num,type = "clustered",nclusters=90)

lapply(real_poly,function(x){
  over(x,sim_locs,returnList=TRUE)  
})->over_res
which(sapply(over_res,function(x)length(x[[1]])!=0))->valid_specs
over_res[valid_specs]->over_res
over_res<-mapply(function(x,y) {data.frame(x,spec=rep(y,length(x)))->z;
  return(z)},over_res,names(over_res),SIMPLIFY = FALSE)
lapply(over_res,function(x){sim_locs[x$X1,]->z;
  z$loc_id<-x$X1;
  return(z)})->over_res
over_res<-mapply(function(x,y) { as.data.frame(x)->x;
  x$spec<-y;
  return(x)}, over_res,names(over_res),SIMPLIFY = FALSE )
over_res<-do.call(rbind,over_res)
rownames(over_res)<-NULL
colnames(over_res)[2:3]<-c("x","y")
coordinates(over_res)<-~x+y
crs(over_res)<-my_proj
over_res->general_sim_dat
spTransform(general_sim_dat,CRS=CRS("+proj=longlat +datum=WGS84"))->general_sim_dat
general_sim_dat<-as.data.frame(general_sim_dat)
as.character(general_sim_dat$spec)->general_sim_dat$spec
general_sim_dat->general_sim_locs
general_sim_locs$age<-1

set.seed(2047)
summary(to_rem<-round(rnorm(length(unique(general_sim_locs$loc_id)), mean=30,sd=10)))
id_list<-unique(general_sim_locs$loc_id)
reduce_list<-function(x,y,seed){
  to_keep<-sample(which(general_sim_locs$loc_id%in%x),round(length(which(general_sim_locs$loc_id%in%x))*((100-y)/100)))
  reduced_general_sim_locs<-general_sim_locs[to_keep,]
  return(reduced_general_sim_locs)
}
reduced_general_sim_locs<-mapply(function(x,y) reduce_list(x,y,seed=39), id_list, to_rem,SIMPLIFY=FALSE )
reduced_general_sim_locs<-do.call(rbind,reduced_general_sim_locs)
rownames(reduced_general_sim_locs)<-NULL


#### Performing MInOSSE ####
Sys.getenv("R_MAX_NUM_DLLs", unset = NA)
unique(as.character(reduced_general_sim_locs$spec))->spec_list

minosse_dat<-list()
minosse_res_list<-list()
for(i in 1:length(spec_list)){
  if(class(try(minosse_dat[[i]]<-minosse.data(
    obj=reduced_general_sim_locs,
    species_name=spec_list[i],
    domain="land",
    coc.by=NULL,
    min.occs=3,
    abiotic.covs=NULL,
    combine.covs=FALSE,   
    reduce_covs_by="pca",
    covs_th=0.95,
    c.size=100000,
    bkg.predictors="presence", 
    min.bkg=100,
    sampling.by.distance=TRUE,
    prediction.ground=prediction_ground,
    crop.by.mcp=FALSE,
    projection="laea",
    lon_0=85,
    lat_0=45,
    n.clusters="automatic", 
    seed=625)
  ))=="try-error") {next} else {minosse_dat[[i]]<-minosse_dat[[i]];
  
  
  if(class(try(minosse_res_list[[i]]<-minosse.target(
    resp=minosse_dat[[i]][[1]],
    predictors=minosse_dat[[i]][[2]],
    bkg="presence",
    min.bkg = 100,
    n.sims=10,
    sampling.by.distance=TRUE,
    n.folds=n.folds,
    n.sims.clusters="automatic",
    seed=625)))=="try-error") {next} else minosse_res_list[[i]]<-minosse_res_list[[i]] 
  }
  print(i)
}
gc()


#### save ####
save.image(paste(sim.dir,"200_100_clus_min_1979_2015_no_coc.RData",sep=""))
##






#### seed 1979,  randomly distributed spatial simulations ####
rm(list=ls(all=TRUE)[-which(ls(all=TRUE)==dir.path_no_coc_100_200)]);setwd(dir.path_no_coc_100_200)
sim.dir<-"1979-2015/"
dir.create(sim.dir, showWarnings = TRUE, recursive = TRUE) 

spec_seed<-1979
loc_seed<-2015
spec_num<-100
locs_num<-200
lon_0<-85
lat_0<-45
my_proj<-CRS(paste("+proj=laea +lon_0=",lon_0," +lat_0=",lat_0," +x_0=0 +y_0=0 +ellps=WGS84 +units=m +no_defs",sep="")) 
grid_size<-100000
div<-1000

data(countriesCoarseLessIslands)
data(countriesCoarseLessIslands)
eurasia<-countriesCoarseLessIslands[grep("Eurasia",countriesCoarseLessIslands$continent),]
eu<-unionSpatialPolygons(eurasia, cut(coordinates(eurasia)[,1], range(coordinates(eurasia)[,1]), include.lowest=F))
poly<-eu@polygons[[1]]@Polygons[47][[1]]@coords
poly<-as.matrix(poly)
Sr1 = Polygon(poly)
Srs1 = Polygons(list(Sr1), "s1")
SpP = SpatialPolygons(list(Srs1))
proj4string(SpP)<-CRS("+proj=longlat +ellps=WGS84 +datum=WGS84 +no_defs")
spTransform(SpP,CRS=my_proj)->SpP_prj


set.seed(spec_seed)
origins<-spsample(SpP, spec_num,type="random")
origins<-as.data.frame(origins)
data_ck<-origins
coordinates(data_ck)<-~x+y
clarkevans.test(as(data_ck,"ppp"),alternative="clustered")

set.seed(spec_seed)
acca<-rbeta(100,1,5)
range(acca)

length(acca)

set.seed(spec_seed)
abba<-sample(2^(rnorm(100,log(1000,2),log(1000,2)/10)),100)
sort(acca)->acca
sort(abba)->abba

seed<-seq(1:100)
x_zero<-list()
brown.points<-list()
temp_sample<-list()
for(i in 1:100){
  set.seed(seed[i])
  x_zero[[i]]<-as.vector(origins[sample(as.numeric(rownames(origins)),1),])
  set.seed(seed[i])
  brown.points[[i]]<-simm.mou(date=1:abba[i],b=c(sample(seq(from=x_zero[[i]]$x,to=x_zero[[i]]$x+(5),by=1),1),sample(seq(from=x_zero[[i]]$y,to=x_zero[[i]]$y+(5),by=1),1)),a=diag(c(acca[i]/div,acca[i]/div)),x0=c(x_zero[[i]]$x,x_zero[[i]]$y)) 
  brown.points[[i]]<-brown.points[[i]][[1]][,1:2]
  temp_sample[[i]]<-brown.points[[i]]
  try(temp_sample[[i]]<-cbind(temp_sample[[i]], paste("spec", i, sep="")),silent=F)
  print(i)
}
gc()

temp_population<-list()
pops<-list()
for(i in 1:nrow(origins)){
  try(colnames(temp_sample[[i]])[3]<-"spec",silent=F)
  try(temp_population[[i]]<-temp_sample[[i]][which(point.in.polygon(temp_sample[[i]]$x,temp_sample[[i]]$y, SpP@polygons[[1]]@Polygons[[1]]@coords[,1],SpP@polygons[[1]]@Polygons[[1]]@coords[,2])>0),],silent=F)
  try(coordinates(temp_population[[i]])<-~x+y,silent=F)
  try(proj4string(temp_population[[i]])<-CRS("+proj=longlat +ellps=WGS84 +datum=WGS84 +no_defs"),silent=F)
  try(pops[[i]]<-temp_population[[i]][SpP,],silent=F)
  print(i)
}
populations<-do.call(rbind, pops)

spTransform(populations,CRS=my_proj)->prj_populations
extent(prj_populations)[1:2]->x_lim
extent(prj_populations)[3:4]->y_lim
sampling_grid<-expand.grid(x=seq(from=x_lim[1],to=x_lim[2],grid_size),y=seq(from=y_lim[1],to=y_lim[2],grid_size))
sampling_grid->prediction_ground
prediction_ground$z<-1
rasterFromXYZ(prediction_ground)->prediction_ground
crs(prediction_ground)<-my_proj
mask(prediction_ground,SpP_prj)->prediction_ground
coordinates(sampling_grid)<-~x+y
gridded(sampling_grid)<-TRUE
crs(sampling_grid)<-my_proj
as(sampling_grid,"SpatialPolygons")->sampling_grid
lapply(pops,function(x)spTransform(x,CRS=my_proj))->prj_pops

cl <- makeCluster(2, type="SOCK")
registerDoSNOW (cl)
foreach(i=1:length(prj_pops),.packages=c("raster")) %dopar% {
  over(prj_pops[[i]],sampling_grid)->original_over_res
}->original_over_res
stopCluster(cl)
doParallel::stopImplicitCluster()
##

lapply(original_over_res,function(x){sampling_grid[unique(x)[!is.na(unique(x))]]->x;
  return(x)})->real_poly
for(i in 1:length(real_poly)) {
  rgeos::gUnaryUnion(real_poly[[i]])->real_poly[[i]]
  print(i)
}
##

sapply(real_poly,function(x)gArea(x))->areas

lapply(pops,function(x)unique(as.character(x$spec)))->pops_names
names(pops)<-pops_names
names(prj_pops)<-pops_names
names(real_poly)<-pops_names


set.seed(loc_seed)
sim_locs<-spsample(SpP_prj,locs_num,type = "random")

lapply(real_poly,function(x){
  over(x,sim_locs,returnList=TRUE)  
})->over_res
which(sapply(over_res,function(x)length(x[[1]])!=0))->valid_specs
over_res[valid_specs]->over_res
over_res<-mapply(function(x,y) {data.frame(x,spec=rep(y,length(x)))->z;
  return(z)},over_res,names(over_res),SIMPLIFY = FALSE)
lapply(over_res,function(x){sim_locs[x$X1,]->z;
  z$loc_id<-x$X1;
  return(z)})->over_res
over_res<-mapply(function(x,y) { as.data.frame(x)->x;
  x$spec<-y;
  return(x)}, over_res,names(over_res),SIMPLIFY = FALSE )
over_res<-do.call(rbind,over_res)
rownames(over_res)<-NULL
colnames(over_res)[2:3]<-c("x","y")
coordinates(over_res)<-~x+y
crs(over_res)<-my_proj
over_res->general_sim_dat
spTransform(general_sim_dat,CRS=CRS("+proj=longlat +datum=WGS84"))->general_sim_dat
general_sim_dat<-as.data.frame(general_sim_dat)
as.character(general_sim_dat$spec)->general_sim_dat$spec
general_sim_dat->general_sim_locs
general_sim_locs$age<-1

set.seed(2047)
summary(to_rem<-round(rnorm(length(unique(general_sim_locs$loc_id)), mean=30,sd=10)))
id_list<-unique(general_sim_locs$loc_id)
reduce_list<-function(x,y,seed){
  to_keep<-sample(which(general_sim_locs$loc_id%in%x),round(length(which(general_sim_locs$loc_id%in%x))*((100-y)/100)))
  reduced_general_sim_locs<-general_sim_locs[to_keep,]
  return(reduced_general_sim_locs)
}
reduced_general_sim_locs<-mapply(function(x,y) reduce_list(x,y,seed=39), id_list, to_rem,SIMPLIFY=FALSE )
reduced_general_sim_locs<-do.call(rbind,reduced_general_sim_locs)
rownames(reduced_general_sim_locs)<-NULL


#### Performing MInOSSE ####
Sys.getenv("R_MAX_NUM_DLLs", unset = NA)
unique(as.character(reduced_general_sim_locs$spec))->spec_list

minosse_dat<-list()
minosse_res_list<-list()
for(i in 1:length(spec_list)){
  if(class(try(minosse_dat[[i]]<-minosse.data(
    obj=reduced_general_sim_locs,
    species_name=spec_list[i],
    domain="land",
    coc.by=NULL,
    min.occs=3,
    abiotic.covs=NULL,
    combine.covs=FALSE,   
    reduce_covs_by="pca",
    covs_th=0.95,
    c.size=100000,
    bkg.predictors="presence", 
    min.bkg=100,
    sampling.by.distance=TRUE,
    prediction.ground=prediction_ground,
    crop.by.mcp=FALSE,
    projection="laea",
    lon_0=85,
    lat_0=45,
    n.clusters="automatic", 
    seed=625)
  ))=="try-error") {next} else {minosse_dat[[i]]<-minosse_dat[[i]];
  
  
  if(class(try(minosse_res_list[[i]]<-minosse.target(
    resp=minosse_dat[[i]][[1]],
    predictors=minosse_dat[[i]][[2]],
    bkg="presence",
    min.bkg = 100,
    n.sims=10,
    sampling.by.distance=TRUE,
    n.folds=n.folds,
    n.sims.clusters="automatic",
    seed=625)))=="try-error") {next} else minosse_res_list[[i]]<-minosse_res_list[[i]] 
  }
  print(i)
}
gc()


#### save ####
save.image(paste(sim.dir,"200_100_random_1979_2015_no_coc.RData",sep=""))
##



#### seed 1979,  uniformly distributed spatial simulations ####
rm(list=ls(all=TRUE)[-which(ls(all=TRUE)==dir.path_no_coc_100_200)]);setwd(dir.path_no_coc_100_200)
sim.dir<-"1979-2015/"
dir.create(sim.dir, showWarnings = TRUE, recursive = TRUE) 

spec_seed<-1979
loc_seed<-2015
spec_num<-100
locs_num<-200
lon_0<-85
lat_0<-45
my_proj<-CRS(paste("+proj=laea +lon_0=",lon_0," +lat_0=",lat_0," +x_0=0 +y_0=0 +ellps=WGS84 +units=m +no_defs",sep="")) 
grid_size<-100000
div<-1000

data(countriesCoarseLessIslands)
data(countriesCoarseLessIslands)
eurasia<-countriesCoarseLessIslands[grep("Eurasia",countriesCoarseLessIslands$continent),]
eu<-unionSpatialPolygons(eurasia, cut(coordinates(eurasia)[,1], range(coordinates(eurasia)[,1]), include.lowest=F))
poly<-eu@polygons[[1]]@Polygons[47][[1]]@coords
poly<-as.matrix(poly)
Sr1 = Polygon(poly)
Srs1 = Polygons(list(Sr1), "s1")
SpP = SpatialPolygons(list(Srs1))
proj4string(SpP)<-CRS("+proj=longlat +ellps=WGS84 +datum=WGS84 +no_defs")
spTransform(SpP,CRS=my_proj)->SpP_prj


set.seed(spec_seed)
origins<-spsample(SpP, spec_num,type="regular")
origins<-as.data.frame(origins)
data_ck<-origins
coordinates(data_ck)<-~x1+x2
clarkevans.test(as(data_ck,"ppp"),alternative="clustered")

set.seed(spec_seed)
acca<-rbeta(100,1,5)
range(acca)

length(acca)
set.seed(spec_seed)
abba<-sample(2^(rnorm(100,log(1000,2),log(1000,2)/10)),100)
sort(acca)->acca
sort(abba)->abba

seed<-seq(1:100)
x_zero<-list()
brown.points<-list()
temp_sample<-list()
for(i in 1:100){
  set.seed(seed[i])
  x_zero[[i]]<-as.vector(origins[sample(as.numeric(rownames(origins)),1),])
  set.seed(seed[i])
  brown.points[[i]]<-simm.mou(date=1:abba[i],b=c(sample(seq(from=x_zero[[i]]$x1,to=x_zero[[i]]$x1+(5),by=1),1),sample(seq(from=x_zero[[i]]$x2,to=x_zero[[i]]$x2+(5),by=1),1)),a=diag(c(acca[i]/div,acca[i]/div)),x0=c(x_zero[[i]]$x1,x_zero[[i]]$x2)) 
  brown.points[[i]]<-brown.points[[i]][[1]][,1:2]
  temp_sample[[i]]<-brown.points[[i]]
  try(temp_sample[[i]]<-cbind(temp_sample[[i]], paste("spec", i, sep="")),silent=F)
  print(i)
}
gc()

temp_population<-list()
pops<-list()
for(i in 1:nrow(origins)){
  try(colnames(temp_sample[[i]])[3]<-"spec",silent=F)
  try(temp_population[[i]]<-temp_sample[[i]][which(point.in.polygon(temp_sample[[i]]$x,temp_sample[[i]]$y, SpP@polygons[[1]]@Polygons[[1]]@coords[,1],SpP@polygons[[1]]@Polygons[[1]]@coords[,2])>0),],silent=F)
  try(coordinates(temp_population[[i]])<-~x+y,silent=F)
  try(proj4string(temp_population[[i]])<-CRS("+proj=longlat +ellps=WGS84 +datum=WGS84 +no_defs"),silent=F)
  try(pops[[i]]<-temp_population[[i]][SpP,],silent=F)
  print(i)
}
populations<-do.call(rbind, pops)

spTransform(populations,CRS=my_proj)->prj_populations
extent(prj_populations)[1:2]->x_lim
extent(prj_populations)[3:4]->y_lim
sampling_grid<-expand.grid(x=seq(from=x_lim[1],to=x_lim[2],grid_size),y=seq(from=y_lim[1],to=y_lim[2],grid_size))
sampling_grid->prediction_ground
prediction_ground$z<-1
rasterFromXYZ(prediction_ground)->prediction_ground
crs(prediction_ground)<-my_proj
mask(prediction_ground,SpP_prj)->prediction_ground
coordinates(sampling_grid)<-~x+y
gridded(sampling_grid)<-TRUE
crs(sampling_grid)<-my_proj
as(sampling_grid,"SpatialPolygons")->sampling_grid
lapply(pops,function(x)spTransform(x,CRS=my_proj))->prj_pops

cl <- makeCluster(2, type="SOCK")
registerDoSNOW (cl)
foreach(i=1:length(prj_pops),.packages=c("raster")) %dopar% {
  over(prj_pops[[i]],sampling_grid)->original_over_res
}->original_over_res
stopCluster(cl)
doParallel::stopImplicitCluster()
##

lapply(original_over_res,function(x){sampling_grid[unique(x)[!is.na(unique(x))]]->x;
  return(x)})->real_poly
for(i in 1:length(real_poly)) {
  rgeos::gUnaryUnion(real_poly[[i]])->real_poly[[i]]
  print(i)
}
##

sapply(real_poly,function(x)gArea(x))->areas
lapply(pops,function(x)unique(as.character(x$spec)))->pops_names
names(pops)<-pops_names
names(prj_pops)<-pops_names
names(real_poly)<-pops_names


set.seed(loc_seed)
sim_locs<-spsample(SpP_prj,locs_num,type = "regular")

lapply(real_poly,function(x){
  over(x,sim_locs,returnList=TRUE)  
})->over_res
which(sapply(over_res,function(x)length(x[[1]])!=0))->valid_specs
over_res[valid_specs]->over_res
over_res<-mapply(function(x,y) {data.frame(x,spec=rep(y,length(x)))->z;
  return(z)},over_res,names(over_res),SIMPLIFY = FALSE)
lapply(over_res,function(x){sim_locs[x$X1,]->z;
  z$loc_id<-x$X1;
  return(z)})->over_res
over_res<-mapply(function(x,y) { as.data.frame(x)->x;
  x$spec<-y;
  return(x)}, over_res,names(over_res),SIMPLIFY = FALSE )
over_res<-do.call(rbind,over_res)
rownames(over_res)<-NULL
colnames(over_res)[2:3]<-c("x","y")
coordinates(over_res)<-~x+y
crs(over_res)<-my_proj
over_res->general_sim_dat
spTransform(general_sim_dat,CRS=CRS("+proj=longlat +datum=WGS84"))->general_sim_dat
general_sim_dat<-as.data.frame(general_sim_dat)
as.character(general_sim_dat$spec)->general_sim_dat$spec
general_sim_dat->general_sim_locs
general_sim_locs$age<-1

set.seed(2047)
summary(to_rem<-round(rnorm(length(unique(general_sim_locs$loc_id)), mean=30,sd=10)))
id_list<-unique(general_sim_locs$loc_id)
reduce_list<-function(x,y,seed){
  to_keep<-sample(which(general_sim_locs$loc_id%in%x),round(length(which(general_sim_locs$loc_id%in%x))*((100-y)/100)))
  reduced_general_sim_locs<-general_sim_locs[to_keep,]
  return(reduced_general_sim_locs)
}
reduced_general_sim_locs<-mapply(function(x,y) reduce_list(x,y,seed=39), id_list, to_rem,SIMPLIFY=FALSE )
reduced_general_sim_locs<-do.call(rbind,reduced_general_sim_locs)
rownames(reduced_general_sim_locs)<-NULL


#### Performing MInOSSE ####
Sys.getenv("R_MAX_NUM_DLLs", unset = NA)
unique(as.character(reduced_general_sim_locs$spec))->spec_list

minosse_dat<-list()
minosse_res_list<-list()
for(i in 1:length(spec_list)){
  if(class(try(minosse_dat[[i]]<-minosse.data(
    obj=reduced_general_sim_locs,
    species_name=spec_list[i],
    domain="land",
    coc.by=NULL,
    min.occs=3,
    abiotic.covs=NULL,
    combine.covs=FALSE,   
    reduce_covs_by="pca",
    covs_th=0.95,
    c.size=100000,
    bkg.predictors="presence", 
    min.bkg=100,
    sampling.by.distance=TRUE,
    prediction.ground=prediction_ground,
    crop.by.mcp=FALSE,
    projection="laea",
    lon_0=85,
    lat_0=45,
    n.clusters="automatic", 
    seed=625)
  ))=="try-error") {next} else {minosse_dat[[i]]<-minosse_dat[[i]];
  
  
  if(class(try(minosse_res_list[[i]]<-minosse.target(
    resp=minosse_dat[[i]][[1]],
    predictors=minosse_dat[[i]][[2]],
    bkg="presence",
    min.bkg = 100,
    n.sims=10,
    sampling.by.distance=TRUE,
    n.folds=n.folds,
    n.sims.clusters="automatic",
    seed=625)))=="try-error") {next} else minosse_res_list[[i]]<-minosse_res_list[[i]] 
  }
  print(i)
}
gc()


#### save ####
save.image(paste(sim.dir,"200_100_uniform_1979_2015_no_coc.RData",sep=""))
##

 