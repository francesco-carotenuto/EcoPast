### This script is used to get the pairwise MANOVA and the Tukey's honest significance test to compare MInOSSE vs. hull methods ####

#rm(list=ls(all=TRUE))
#ls()

eco_sims_results_path_coc_loc_R<-results_path
eco_sims_results_path_no_coc_R<-results_path_no_coc

eco_sims_results_path_coc_loc_RANDOM<-results_path_RANDOM
eco_sims_results_path_no_coc_RANDOM<-results_path_no_coc_RANDOM


eco_sims_results_path_coc_loc_CLUSTERED<-results_path_CLUSTERED
eco_sims_results_path_no_coc_CLUSTERED<-results_path_no_coc_CLUSTERED


files_names_coc_loc<-list.files(eco_sims_results_path_coc_loc_R,pattern = "stats")
files_names_no_coc<-list.files(eco_sims_results_path_no_coc_R,pattern = "stats")


files_names_coc_loc_RANDOM<-list.files(eco_sims_results_path_coc_loc_RANDOM,pattern = "stats")
files_names_no_coc_RANDOM<-list.files(eco_sims_results_path_no_coc_RANDOM,pattern = "stats")

files_names_coc_loc_CLUSTERED<-list.files(eco_sims_results_path_coc_loc_CLUSTERED,pattern = "stats")
files_names_no_coc_CLUSTERED<-list.files(eco_sims_results_path_no_coc_CLUSTERED,pattern = "stats")



stats_coc_loc<-lapply(files_names_coc_loc,function(x)read.table(paste(eco_sims_results_path_coc_loc_R,x,sep="")))
stats_no_coc<-lapply(files_names_no_coc,function(x)read.table(paste(eco_sims_results_path_no_coc_R,x,sep="")))


stats_coc_loc_RANDOM<-lapply(files_names_coc_coc_RANDOM,function(x)read.table(paste(eco_sims_results_path_coc_loc_RANDOM,x,sep="")))
stats_no_coc_RANDOM<-lapply(files_names_no_coc_RANDOM,function(x)read.table(paste(eco_sims_results_path_no_coc_RANDOM,x,sep="")))

stats_coc_loc_CLUSTERED<-lapply(files_names_coc_loc_CLUSTERED,function(x)read.table(paste(eco_sims_results_path_coc_loc_CLUSTERED,x,sep="")))
stats_no_coc_CLUSTERED<-lapply(files_names_no_coc_CLUSTERED,function(x)read.table(paste(eco_sims_results_path_no_coc_CLUSTERED,x,sep="")))



lapply(stats_coc_loc,function(x){data.frame(x,coc=TRUE)->y;
  return(y)})->TRUE_coc
lapply(stats_no_coc,function(x){data.frame(x,coc=FALSE)->y;
  return(y)})->FALSE_coc

lapply(stats_coc_loc_RANDOM,function(x){data.frame(x,coc=TRUE)->y;
  return(y)})->TRUE_coc_RANDOM
lapply(stats_no_coc_RANDOM,function(x){data.frame(x,coc=FALSE)->y;
  return(y)})->FALSE_coc_RANDOM

lapply(stats_coc_loc_CLUSTERED,function(x){data.frame(x,coc=TRUE)->y;
  return(y)})->TRUE_coc_CLUSTERED
lapply(stats_no_coc_CLUSTERED,function(x){data.frame(x,coc=FALSE)->y;
  return(y)})->FALSE_coc_CLUSTERED



names(TRUE_coc)<-files_names_coc_loc
names(FALSE_coc)<-files_names_no_coc

names(TRUE_coc_RANDOM)<-files_names_coc_loc_RANDOM
names(FALSE_coc_RANDOM)<-files_names_no_coc_RANDOM

names(TRUE_coc_CLUSTERED)<-files_names_coc_loc_CLUSTERED
names(FALSE_coc_CLUSTERED)<-files_names_no_coc_CLUSTERED


sims<-c("100km","200km","300km","semi","mean")

TRUE_coc<-TRUE_coc[unlist(sapply(sims,function(x)grep(x,names(TRUE_coc),useBytes=TRUE) ))]
FALSE_coc<-FALSE_coc[unlist(sapply(sims,function(x)grep(x,names(FALSE_coc)) ))]

TRUE_coc_RANDOM<-TRUE_coc_RANDOM[unlist(sapply(sims,function(x)grep(x,names(TRUE_coc_RANDOM),useBytes=TRUE) ))]
FALSE_coc_RANDOM<-FALSE_coc_RANDOM[unlist(sapply(sims,function(x)grep(x,names(FALSE_coc_RANDOM)) ))]

TRUE_coc_CLUSTERED<-TRUE_coc_CLUSTERED[unlist(sapply(sims,function(x)grep(x,names(TRUE_coc_CLUSTERED),useBytes=TRUE) ))]
FALSE_coc_CLUSTERED<-FALSE_coc_CLUSTERED[unlist(sapply(sims,function(x)grep(x,names(FALSE_coc_CLUSTERED)) ))]





lapply(seq(1:5),function(x)data.frame(TRUE_coc[[x]],cell_size=sims[x]))->manova_TRUE_coc
lapply(seq(1:5),function(x)data.frame(FALSE_coc[[x]],cell_size=sims[x]))->manova_FALSE_coc

lapply(seq(1:5),function(x)data.frame(TRUE_coc_RANDOM[[x]],cell_size=sims[x]))->manova_TRUE_coc_RANDOM
lapply(seq(1:5),function(x)data.frame(FALSE_coc_RANDOM[[x]],cell_size=sims[x]))->manova_FALSE_coc_RANDOM

lapply(seq(1:5),function(x)data.frame(TRUE_coc_CLUSTERED[[x]],cell_size=sims[x]))->manova_TRUE_coc_CLUSTERED
lapply(seq(1:5),function(x)data.frame(FALSE_coc_CLUSTERED[[x]],cell_size=sims[x]))->manova_FALSE_coc_CLUSTERED

gimme.data<-function(stats){
  stats->stats_4_boxplot
  lapply(stats_4_boxplot[,-which(colnames(stats_4_boxplot)%in%c("spec","occ","coc"))],function(x)cbind(stats_4_boxplot[,which(colnames(stats_4_boxplot)%in%c("spec","occ"))],x))->ciccio_box
  do.call(rbind,ciccio_box)->ciccio_box
  lapply(colnames(stats_4_boxplot)[-which(colnames(stats_4_boxplot)%in%c("spec","occ","coc"))],function(x)rep(x,nrow(stats_4_boxplot)))->col_names_box
  unlist(col_names_box)->col_names_box
  data.frame(model_th=col_names_box,ciccio_box)->ciccio_box
  return(ciccio_box)  
}

lapply(manova_FALSE_coc,function(x)gimme.data(x))->anova_FALSE_coc
lapply(manova_TRUE_coc,function(x)gimme.data(x))->anova_TRUE_coc

lapply(manova_FALSE_coc_RANDOM,function(x)gimme.data(x))->anova_FALSE_coc_RANDOM
lapply(manova_TRUE_coc_RANDOM,function(x)gimme.data(x))->anova_TRUE_coc_RANDOM

lapply(manova_FALSE_coc_CLUSTERED,function(x)gimme.data(x))->anova_FALSE_coc_CLUSTERED
lapply(manova_TRUE_coc_CLUSTERED,function(x)gimme.data(x))->anova_TRUE_coc_CLUSTERED



#### MANOVA data #
do.call(rbind,manova_FALSE_coc)->manova_FALSE_coc
manova_FALSE_coc$distribution<-"actual"
do.call(rbind,manova_TRUE_coc)->manova_TRUE_coc
manova_TRUE_coc$distribution<-"actual"

do.call(rbind,manova_FALSE_coc_RANDOM)->manova_FALSE_coc_RANDOM
manova_FALSE_coc_RANDOM$distribution<-"random"
do.call(rbind,manova_TRUE_coc_RANDOM)->manova_TRUE_coc_RANDOM
manova_TRUE_coc_RANDOM$distribution<-"random"

do.call(rbind,manova_FALSE_coc_CLUSTERED)->manova_FALSE_coc_CLUSTERED
manova_FALSE_coc_CLUSTERED$distribution<-"clustered"
do.call(rbind,manova_TRUE_coc_CLUSTERED)->manova_TRUE_coc_CLUSTERED
manova_TRUE_coc_CLUSTERED$distribution<-"clustered"


library(usdm)
dataset<-rbind(manova_FALSE_coc,manova_TRUE_coc)
dataset_RANDOM<-rbind(manova_FALSE_coc_RANDOM,manova_TRUE_coc_RANDOM)
dataset_CLUSTERED<-rbind(manova_FALSE_coc_CLUSTERED,manova_TRUE_coc_CLUSTERED)

#### lgm LOCALITY BASED MANOVA
#### Permutational and Pairwise Permutational MANOVA is used to test if there are significant differences 
# between the different MInOSSE settings dealing with interpolation cell resolutions or the use of cooccurrence analysis  #### 
#library(devtools)
#devtools::install_github("pmartinezarbizu/pairwiseAdonis/pairwiseAdonis")
library(pairwiseAdonis)
chosen_axis<-min(which(summary(pca_dataset<-prcomp(dataset[,c("Sens.Spec","MaxSens.Spec","MaxKappa","MaxPCC","PredPrev.Obs","ObsPrev","MeanProb","MinROCdist")]))$importance[3,]>=0.95))
pca_dataset<-pca_dataset$x[,1:chosen_axis]
ado_res_LGM_LOCS<-adonis(pca_dataset~coc+cell_size, data=dataset,method = "euclidean",permutations = 500,parallel=5)
pw_ado_res_LGM_LOCS<-pairwise.adonis(x=pca_dataset,factors=dataset$"cell_size",sim.method = "euclidean",perm = 500)

# ado_res_LGM_LOCS is the output of the permutational MANOVA showing that there ara no differences in the MInOSSE
# outputs yielded by using or not using cooccurrence analysis. Cell resolution is, on the contrary important when pereforming
# MInoSSE as the test found significant differences between cell resolutions. pw_ado_res_LGM_LOCS is the output of Pairwise permutational
# MANOVA showing that coarse grained MInOSSE model performing better than fine grained ones.
# This results strictly depends on the simulations parameters we used and should not be taken as a universally valid.


#### RANDOM LOCALITY BASED MANOVA
#### Permutational MANOVA is used to test if there are significant differences 
# between the different MInOSSE settings dealing with interpolation cell resolutions or the use of cooccurrence analysis  #### 
chosen_axis_RANDOM<-min(which(summary(pca_dataset_RANDOM<-prcomp(dataset_RANDOM[,c("Sens.Spec","MaxSens.Spec","MaxKappa","MaxPCC","PredPrev.Obs","ObsPrev","MeanProb","MinROCdist")]))$importance[3,]>=0.95))
pca_dataset_RANDOM<-pca_dataset_RANDOM$x[,1:chosen_axis_RANDOM]
ado_res_RANDOM<-adonis(pca_dataset_RANDOM~coc+cell_size, data=dataset_RANDOM,method = "euclidean",permutations = 500,parallel=5)

# This is the output of the permutational MANOVA showing that there ara no differences in the MInOSSE
# outputs yielded by using different interpolation cell resolutions or by using or not using cooccurrence analysis ###
#ado_res_RANDOM


#### CLUSTERED LOCALITY BASED MANOVA
#### Permutational MANOVA is used to test if there are significant differences 
# between the different MInOSSE settings dealing with interpolation cell resolutions or the use of cooccurrence analysis  #### 

chosen_axis_CLUSTERED<-min(which(summary(pca_dataset_CLUSTERED<-prcomp(dataset_CLUSTERED[,c("Sens.Spec","MaxSens.Spec","MaxKappa","MaxPCC","PredPrev.Obs","ObsPrev","MeanProb","MinROCdist")]))$importance[3,]>=0.95))
pca_dataset_CLUSTERED<-pca_dataset_CLUSTERED$x[,1:chosen_axis_CLUSTERED]
ado_res_CLUSTERED<-adonis(pca_dataset_CLUSTERED~coc+cell_size, data=dataset_CLUSTERED,method = "euclidean",permutations = 500,parallel=5)

# This is the output of the permutational MANOVA showing that there ara no differences in the MInOSSE
# outputs yielded by using different interpolation cell resolutions or by using or not using cooccurrence analysis ###
#ado_res_CLUSTERED




### Here we perform ANOVA with the TSS scores of MInOSSE output types 
# (with different thresholds) and the TSS scores of the other hull-based methods. 
# This analysis is performed for each interpolation cell resolution, separately.
# With the cooccurrence-based MInOSSE output # 

#### by using true fossil localities of mammal species during the LGM
lapply(anova_TRUE_coc,function(z){
  z$is_minosse<-"no";
  z[-which(z$model_th%in%c("MCP","alpha_hull")),]$is_minosse<-"yes"
  return(z)
})->new_anova_TRUE_coc

anov_res_TRUE_coc<-lapply(new_anova_TRUE_coc,function(z){
  aov_summary<-summary.aov(aov_res<-aov(as.numeric(x)~model_th,data=z))
  Tukey_res<-TukeyHSD(aov_res, which = "model_th") 
return(list(aov_summary=aov_summary,Tukey_res=Tukey_res))
  })
## ANOVA results #
#anov_res_TRUE_coc

#####

#### Tukey
Tukey_res_TRUE_coc<-lapply(anov_res_TRUE_coc,function(x){
  minosse.vs.hulls<-x[[2]][[1]][grep("MCP|alpha_hull",rownames(x[[2]][[1]])),]
  minosse.vs.minosse<-x[[2]][[1]][-grep("MCP|alpha_hull",rownames(x[[2]][[1]])),]
  return(list(minosse.vs.hulls=minosse.vs.hulls,minosse.vs.minosse=minosse.vs.minosse)) 
})
## Tukey HSD results #
#Tukey_res_TRUE_coc


### Here we perform ANOVA with all the TSS scores of MInOSSE output types 
# (with different thresholds) and the TSS scores of the other hull-based methods.
# This analysis is performed for each interpolation cell resolution, separately.
# Without the cooccurrence-based MInOSSE output # 
lapply(anova_FALSE_coc,function(z){
  z$is_minosse<-"no";
  z[-which(z$model_th%in%c("MCP","alpha_hull")),]$is_minosse<-"yes"
  return(z)
})->new_anova_FALSE_coc

anov_res_FALSE_coc<-lapply(new_anova_FALSE_coc,function(z){
  aov_summary<-summary.aov(aov_res<-aov(as.numeric(x)~model_th,data=z))
  Tukey_res<-TukeyHSD(aov_res, which = "model_th") 
  return(list(aov_summary=aov_summary,Tukey_res=Tukey_res))
})
## ANOVA results#
#anov_res_FALSE_coc

#####

#### Tukey
Tukey_res_FALSE_coc<-lapply(anov_res_FALSE_coc,function(x){
  minosse.vs.hulls<-x[[2]][[1]][grep("MCP|alpha_hull",rownames(x[[2]][[1]])),]
  minosse.vs.minosse<-x[[2]][[1]][-grep("MCP|alpha_hull",rownames(x[[2]][[1]])),]
  return(list(minosse.vs.hulls=minosse.vs.hulls,minosse.vs.minosse=minosse.vs.minosse)) 
})
# Tukey HSD results #
#Tukey_res_FALSE_coc




#### with a random distribution of the fossil localities
lapply(anova_TRUE_coc_RANDOM,function(z){
  z$is_minosse<-"no";
  z[-which(z$model_th%in%c("MCP","alpha_hull")),]$is_minosse<-"yes"
  return(z)
})->new_anova_TRUE_coc_RANDOM

anov_res_TRUE_coc_RANDOM<-lapply(new_anova_TRUE_coc_RANDOM,function(z){
  aov_summary<-summary.aov(aov_res<-aov(as.numeric(x)~model_th,data=z))
  Tukey_res<-TukeyHSD(aov_res, which = "model_th") 
  return(list(aov_summary=aov_summary,Tukey_res=Tukey_res))
})
## ANOVA results #
#anov_res_TRUE_coc_RANDOM

#####

#### Tukey
Tukey_res_TRUE_coc_RANDOM<-lapply(anov_res_TRUE_coc_RANDOM,function(x){
  minosse.vs.hulls<-x[[2]][[1]][grep("MCP|alpha_hull",rownames(x[[2]][[1]])),]
  minosse.vs.minosse<-x[[2]][[1]][-grep("MCP|alpha_hull",rownames(x[[2]][[1]])),]
  return(list(minosse.vs.hulls=minosse.vs.hulls,minosse.vs.minosse=minosse.vs.minosse)) 
})
## Tukey HSD results #
#Tukey_res_TRUE_coc_RANDOM


### Here we perform ANOVA with all the TSS scores of MInOSSE output types 
# (with different thresholds) and the TSS scores of the other hull-based methods.
# This analysis is performed for each interpolation cell resolution, separately.
# Without the cooccurrence-based MInOSSE output # 
lapply(anova_FALSE_coc_RANDOM,function(z){
  z$is_minosse<-"no";
  z[-which(z$model_th%in%c("MCP","alpha_hull")),]$is_minosse<-"yes"
  return(z)
})->new_anova_FALSE_coc_RANDOM

anov_res_FALSE_coc_RANDOM<-lapply(new_anova_FALSE_coc_RANDOM,function(z){
  aov_summary<-summary.aov(aov_res<-aov(as.numeric(x)~model_th,data=z))
  Tukey_res<-TukeyHSD(aov_res, which = "model_th") 
  return(list(aov_summary=aov_summary,Tukey_res=Tukey_res))
})
## ANOVA results#
#anov_res_FALSE_coc_RANDOM

#####

#### Tukey
Tukey_res_FALSE_coc_RANDOM<-lapply(anov_res_FALSE_coc_RANDOM,function(x){
  minosse.vs.hulls<-x[[2]][[1]][grep("MCP|alpha_hull",rownames(x[[2]][[1]])),]
  minosse.vs.minosse<-x[[2]][[1]][-grep("MCP|alpha_hull",rownames(x[[2]][[1]])),]
  return(list(minosse.vs.hulls=minosse.vs.hulls,minosse.vs.minosse=minosse.vs.minosse)) 
})
# Tukey HSD results #
#Tukey_res_FALSE_coc_RANDOM





#### with a clustered distribution of the fossil localities
lapply(anova_TRUE_coc_CLUSTERED,function(z){
  z$is_minosse<-"no";
  z[-which(z$model_th%in%c("MCP","alpha_hull")),]$is_minosse<-"yes"
  return(z)
})->new_anova_TRUE_coc_CLUSTERED

anov_res_TRUE_coc_CLUSTERED<-lapply(new_anova_TRUE_coc_CLUSTERED,function(z){
  aov_summary<-summary.aov(aov_res<-aov(as.numeric(x)~model_th,data=z))
  Tukey_res<-TukeyHSD(aov_res, which = "model_th") 
  return(list(aov_summary=aov_summary,Tukey_res=Tukey_res))
})
## ANOVA results #
#anov_res_TRUE_coc_CLUSTERED

#####

#### Tukey
Tukey_res_TRUE_coc_CLUSTERED<-lapply(anov_res_TRUE_coc_CLUSTERED,function(x){
  minosse.vs.hulls<-x[[2]][[1]][grep("MCP|alpha_hull",rownames(x[[2]][[1]])),]
  minosse.vs.minosse<-x[[2]][[1]][-grep("MCP|alpha_hull",rownames(x[[2]][[1]])),]
  return(list(minosse.vs.hulls=minosse.vs.hulls,minosse.vs.minosse=minosse.vs.minosse)) 
})
## Tukey HSD results #
#Tukey_res_TRUE_coc_CLUSTERED


### Here we perform ANOVA with all the TSS scores of MInOSSE output types 
# (with different thresholds) and the TSS scores of the other hull-based methods.
# This analysis is performed for each interpolation cell resolution, separately.
# Without the cooccurrence-based MInOSSE output # 
lapply(anova_FALSE_coc_CLUSTERED,function(z){
  z$is_minosse<-"no";
  z[-which(z$model_th%in%c("MCP","alpha_hull")),]$is_minosse<-"yes"
  return(z)
})->new_anova_FALSE_coc_CLUSTERED

anov_res_FALSE_coc_CLUSTERED<-lapply(new_anova_FALSE_coc_CLUSTERED,function(z){
  aov_summary<-summary.aov(aov_res<-aov(as.numeric(x)~model_th,data=z))
  Tukey_res<-TukeyHSD(aov_res, which = "model_th") 
  return(list(aov_summary=aov_summary,Tukey_res=Tukey_res))
})
## ANOVA results#
#anov_res_FALSE_coc_CLUSTERED

#####

#### Tukey
Tukey_res_FALSE_coc_CLUSTERED<-lapply(anov_res_FALSE_coc_CLUSTERED,function(x){
  minosse.vs.hulls<-x[[2]][[1]][grep("MCP|alpha_hull",rownames(x[[2]][[1]])),]
  minosse.vs.minosse<-x[[2]][[1]][-grep("MCP|alpha_hull",rownames(x[[2]][[1]])),]
  return(list(minosse.vs.hulls=minosse.vs.hulls,minosse.vs.minosse=minosse.vs.minosse)) 
})
# Tukey HSD results #
#Tukey_res_FALSE_coc_CLUSTERED


