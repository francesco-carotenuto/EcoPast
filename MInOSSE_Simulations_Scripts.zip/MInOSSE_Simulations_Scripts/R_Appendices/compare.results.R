compare.results<-function(i,use.mess=FALSE,general_sim_locs,species_list,minosse_res,compare.with,real_population,real_polygon,mask_res,use.dist){
  
  
  
  library(rgeos)
  library(dismo)
  library(PresenceAbsence)
  library(alphahull)
  gBuffer(SpP_prj,width = 0)->SpP_prj
  dist_th<-function(x){
    presenze<-x$pts[x$pts$value==1,]
    lapply(x[[1]],function(y){
      maschera<-y;
      maschera[maschera<1,]<-NA;
      dist_ras<-distanceFromPoints(y,presenze );
      dist_ras<-mask(dist_ras,maschera);
      library(breakpoint);
      CE.Normal.Mean(data.frame(sort(dist_ras[!is.na(dist_ras)])),Nmax=1)->break_point;
      if(class(break_point)=="character") break_point$BP.Loc<-max(sort(dist_ras[!is.na(dist_ras)])) else  break_point<-break_point
      sort(dist_ras[!is.na(dist_ras)])[break_point$BP.Loc]->break_dist;
      new_bin_map<-dist_ras<break_dist;
      return(new_bin_map)
    })->new_bin_maps
    stack(new_bin_maps)->new_bin_maps
    return(new_bin_maps)
  }
  
  
  if(use.dist==TRUE) {
    minosse_ras<-dist_th(minosse_res[[i]])
    bin_base<-!is.na(minosse_res[[i]][[2]])
    bin_base[bin_base==0]<-NA
    bin_base[bin_base==1]<-0
    minosse_ras<-lapply(unstack(minosse_ras),function(x){bin_base[x==1]<-1;
    return(bin_base)})
    
  } else if(use.dist==FALSE) { minosse_ras<-minosse_res[[i]][[1]]}
  
  
  if(isTRUE(use.mess)) {
    extract(minosse_res[[i]]$predictors,minosse_res[[i]]$pts)->cal
    library(dismo)
    dismo::mess(minosse_res[[i]]$predictors,cal,full=FALSE)->mess_mask
    mess_mask[mess_mask==Inf]<-NA
    mess_mask>=-10->mess_mask
    minosse_ras<-lapply(minosse_ras,function(x)raster::mask(x,mess_mask,maskvalue=0))
    bin_base<-!is.na(minosse_res[[i]][[2]])
    bin_base[bin_base==0]<-NA
    bin_base[bin_base==1]<-0
    minosse_ras<-lapply(minosse_ras,function(x){bin_base[x==1]<-1;
    return(bin_base)})
    } else minosse_ras<-minosse_ras
  
  
  
  
  general_sim_locs[which(general_sim_locs$spec==species_list[i]),c("x","y")]->fossil_spec
  coordinates(fossil_spec)<-~x+y
  proj4string(fossil_spec)<-CRS("+proj=longlat +datum=WGS84")
  spTransform(fossil_spec,CRS=laea_prj)->fossil_spec
  
  general_sim_locs[,c("x","y")]->fossil_domain
  coordinates(fossil_domain)<-~x+y
  proj4string(fossil_domain)<-CRS("+proj=longlat +datum=WGS84")
  spTransform(fossil_domain,CRS=laea_prj)->fossil_domain
  
  lapply(minosse_ras,function(x){projectRaster(x,crs=crs(minosse_ras[[1]]),res=c(100000,100000))->y;
    return(y)})->minosse_ras
  
  
  if(compare.with=="occupancy") {
    species_real_polygon<-real_polygon[which(names(real_polygon)==species_list[[i]])][[1]];
    sampling_raster<-rasterize(species_real_polygon,minosse_ras[[1]])
    sampling_raster[is.na(sampling_raster),]<-0
    sampling_raster[is.na(minosse_ras[[1]]),]<-NA
    } 
  
  
  
  if(compare.with=="mcp") {
    real_population<-real_population[which(names(real_population)==species_list[[i]])][[1]]  
    real_population<-spTransform(real_population,CRS=crs(minosse_ras[[1]]))
    sampling_raster<-convHull(real_population);
    polygons(sampling_raster)->sampling_raster
    sampling_raster<-rasterize(sampling_raster,minosse_ras[[1]])
    sampling_raster[is.na(sampling_raster),]<-0
    sampling_raster[is.na(minosse_ras[[1]]),]<-NA
    sampling_raster<-mask(sampling_raster,minosse_ras[[1]])
  }

  species_real_polygon<-real_polygon[which(names(real_polygon)==species_list[[i]])][[1]]
  raspoly<-function(x,th){
    library(raster)
    r1<-rasterToPolygons(x,fun=function(x){x>th}, dissolve=TRUE)
    rgeos::gUnaryUnion(r1)->r1
    return(r1)  
  } 
  
  
  gimme.locoh<-function(x,cont,radi){
    if(length(zerodist(x)[,2])!=0) {
      x[-zerodist(x)[,2],]->x  
    }
    
    library(geosphere)
    library(adehabitatHR)
    library(rgeos)
    spTransform(x,CRS=CRS("+proj=longlat +datum=WGS84"))->x_wgs84
    distm(x_wgs84)->dista
    if(is.null(radi)){
      radi<-max(apply(dista,1,function(x)min(x[x!=0])))
    } else radi<-radi
    if(class(try(locoh<-adehabitatHR::LoCoH.r(x, r=radi, unin = "m",
                                              unout = "m2",
                                              duplicates=c("remove")),silent=TRUE))=="try-error") {
      locoh<-adehabitatHR::LoCoH.r(x, r=2*radi, unin = "m",
                                   unout = "m2",duplicates=c("remove"))} else locoh<-locoh
    if(length(locoh)>1){
      gBuffer(locoh,width=0)->locoh;
      gUnaryUnion(locoh)->locoh;
      gIntersection(locoh,cont)->locoh;
      gUnaryUnion(locoh)->locoh
    } else if(length(locoh)==1)  {
      gBuffer(locoh[[1]],width=0)->locoh;
      gUnaryUnion(locoh)->locoh;
      gIntersection(locoh,cont)->locoh;
      gUnaryUnion(locoh)->locoh}
    return(locoh)
  }
  
  gimme.alphahull<-function(x,cont) {
    library(geosphere)
    library(ConR)
    library(rgeos)
    spTransform(x,CRS=CRS("+proj=longlat +datum=WGS84"))->x_wgs84
    distm(x_wgs84)/1000->dista
    diag(dista)<-NA
    #radi<-max(dista,na.rm=TRUE) 
    #if(class(try(a_hull<-EOO.computing(cbind(coordinates(x_wgs84)[,2],coordinates(x_wgs84)[,1]), alpha=radi,method.range="alpha.hull",export_shp=TRUE),silent=TRUE))=="try-error") {
    #  a_hull<-EOO.computing(cbind(coordinates(x_wgs84)[,2],coordinates(x_wgs84)[,1]), alpha=radi,method.range="convex.hull",export_shp=TRUE,method.less.than3="arbitrary")
    # } else a_hull<-a_hull
    
    
    
    library(bbmle)
    minA<-function(radi)
    {
      
      if(class(try(a_hull<-EOO.computing(cbind(coordinates(x_wgs84)[,2],coordinates(x_wgs84)[,1]), alpha=radi,method.range="alpha.hull",export_shp=TRUE),silent=TRUE))=="try-error") {
        a_hull<-NA
      } else {a_hull<-a_hull}
      
      a_hull<-sp::disaggregate(a_hull$spatial.polygon_1)
      a_hull_length<-length(a_hull)
      abs(a_hull_length*radi)
    } 
    min(dista,na.rm=TRUE)->r1
    max(dista,na.rm=TRUE)->r2
    mean(dista,na.rm=TRUE)->rm
    
    mle2(minA, start=list(radi=rm),lower=list(radi=r1),upper=list(radi=r2),method="L-BFGS-B")->Opt.rad
    
    a_hull<-EOO.computing(cbind(coordinates(x_wgs84)[,2],coordinates(x_wgs84)[,1]), alpha=100,method.range="alpha.hull",export_shp=TRUE)
    
    
    
    
    
    a_hull<-a_hull$spatial.polygon_1
    crs(a_hull)<-crs(x_wgs84)
    spTransform(a_hull,CRS=crs(cont))->a_hull
    gBuffer(cont,width=0)->cont
    gIntersection(a_hull,cont)->a_hull;
    gUnaryUnion(a_hull)->a_hull
    return(a_hull)
  }
  
  gimme.alphahull(fossil_spec,SpP_prj)->fossil_locoh
  polygons(convHull(fossil_spec))->conv_foss
  gBuffer(SpP_prj,width = 0)->SpP_prj
  gIntersection(conv_foss,SpP_prj)->conv_foss
  gUnaryUnion(conv_foss)->conv_foss
  
  polygons(convHull(fossil_domain))->fossil_domain
  gIntersection(fossil_domain,SpP_prj)->fossil_domain
  gUnaryUnion(fossil_domain)->fossil_domain
  

  
  rasterize(fossil_locoh,minosse_ras[[1]])->locoh_raster
  locoh_raster[is.na(locoh_raster)]<-0
  locoh_raster<-mask(locoh_raster,minosse_ras[[1]])
  locoh_raster[is.na(minosse_ras[[1]]),]<-NA
  rasterize(conv_foss,minosse_ras[[1]])->conv_foss
  conv_foss[is.na(conv_foss)]<-0
  conv_foss<-mask(conv_foss,minosse_ras[[1]])
  all_preds<-stack(sampling_raster,locoh_raster,conv_foss,stack(minosse_ras))
  real_ext<-as(extent(species_real_polygon),"SpatialPolygons") # rectangle includig actual species polygon
  library(rgeos)
  gBuffer(SpP_prj,width=0)->SpP_prj
  real_ext<-gIntersection(real_ext,SpP_prj,drop_lower_td=TRUE,checkValidity=TRUE)
  gUnaryUnion(real_ext)->real_ext
  if(mask_res==TRUE) {mask(all_preds,real_ext)->all_preds} else all_preds->all_preds # cropping all predictions by actual species rectangular extent

  names(all_preds)<-c("real_poly","alpha_hull","mcp","Default","Sens=Spec","MaxSens+Spec",
                      "MaxKappa","MaxPCC","PredPrev=Obs","ObsPrev","MeanProb",
                      "MinROCdist","ReqSens","ReqSpec","Cost")
  
  
  rasterToPoints(all_preds)[,-c(1,2)]->all_preds_points
  all_preds_points[which(complete.cases(all_preds_points)),]->all_preds_points
  cbind(plotID=1:nrow(all_preds_points),all_preds_points)->all_preds_points
  presence.absence.accuracy(all_preds_points)->temp_results
  
  apply(as.matrix(temp_results),1,function(x)(as.numeric(x[4])+as.numeric(x[5])-1))->TSS_temp_results
  apply(as.matrix(temp_results),1,function(x)(as.numeric(x[4])))->sensitivity_temp_results
  apply(as.matrix(temp_results),1,function(x)(as.numeric(x[5])))->specificity_temp_results
  list(TSS=TSS_temp_results,Sens=sensitivity_temp_results,Spec=specificity_temp_results)->temp_results
  temp_results<-lapply(temp_results,function(x) {names(x)<-c("alpha_hull","mcp","Default","Sens=Spec","MaxSens+Spec",
                                                             "MaxKappa","MaxPCC","PredPrev=Obs","ObsPrev","MeanProb",
                                                             "MinROCdist","ReqSens","ReqSpec","Cost")
  return(x)})
  
  return(temp_results)
}
