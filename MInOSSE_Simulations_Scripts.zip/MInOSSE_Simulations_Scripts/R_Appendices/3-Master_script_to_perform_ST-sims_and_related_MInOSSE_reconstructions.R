# The following code lines perform the creation of artificial species to be used 
# to test MInOSSE's performance. In details, by this script, we simulate artificial
# species' occurrences according to a core-periphery abundance model, which implies
# a higher occurrence density towards the core and a positive relationship between
# abundance and geographic range size. At the interspecific level, the distribution
# of species' abundances follows the log2-normal. These species' occurrences were 
# simulated using as geographical domain the polygon describing the Eurasian continent's
# boundaries. For each simulated species, we computed the occpupancy
# maps that we used as species'geographic ranges. These geographic distribution 
# were considered as the actual realized geographic ranges of the simulated species.
# We generated four kinds of such simulations differing in the way the centre of species
# of the simulated community were distributed over the spatial domain. We considered a
# highly clustered, a moderately clustered, a random and in the end a uniformly spatial
# distribution of species' centres.
# The successive step was to simulate a fossilization process in order to create a
# fossil record from these species and, then, running MInOSSE with this rediced dataset
# and reconstruct the original actual species'geographic ranges. After generating 
# the actual species'gepgraphic ranges, we had to simulate the spatial distribution of fossil 
# localities. Also in this case we distinguished between four different scenario for the 
# spatial distribution of the fossil localites. To this aim, to simulate the fossil sites,
# we used the same kind of spatial pattern used for simulating the speicies' centres of distribution.
# These simulated fossil localities were, then, overlapped on the actual simulated 
# species ranges in order to extract the identity of species there occurring. 
# After generating a species list, for each fossil localities, we simulated a 
# fossilization bias by removing for each sampled species, from the 50 to the 80%
# of its occurrences in the fossil localites. 
# The removal of species occurrences was not random but was proportional
# to the simulated actual species geographic ranges, in order to give higher occurrence
# probability to the very wide and abundant species, as it happens in the real fossil
# record. We used these simulated species in order to run MInOSSE with several 
# parametes'settings. In details. we tested if reducing the number of predictors
# (and hence reducing compuntational time) by means of co-occurence analysis badly
# impacted the performance of MInOSSE in predicting the simulated actual species'geographic
# ranges. Additionally, as MInOSSE to run needs the setting of a spatial resolution
# to properly perform Kriging interpolations and Regression Kriging algorithms,
# we used these simulations to test if MInOSSE correctly estimated the simulated 
# actual species'geographic ranges by using different spatial resolutions.
# Please, refer the paper Carotenuto et al.... and the related supplementary Information for details about simulations.




#### This is the main script that runs all at once all the ST-sims as described in the main manuscript
# and performs the related MInOSSE geographic ranges reconstrictions. The user has to install the required
# packages (described below) and enter the path to the folder where appendices are stored ("appendices_folder")
# and where to store all the simulations results (my.path). An additional parameter to set is the number of 
# folds for AUC-based cross-validations. A default parameter is n.folds=1, which speeds up MInOSSE 
# predictions without affecting any result but the AUC computation (see below).

install.packages(c("sdmvspecies","rgeos","scales","KernSmooth","adehabitatLT"))
#library(devtools) 
#install_github("francesco-carotenuto/EcoPast") # run this line only the first time you have to install PaleoCore.

rm(list=ls(all=TRUE))

library(EcoPast)
library(spatstat)
library(rworldmap)
library(maptools)
library(rgdal) 
library(adehabitatLT)
library(sp)
library(raster)
library(foreach)
library(doSNOW)
library(doParallel) 
library(rgeos)


#### General setting ####
memory.size(max=TRUE)
#### Enter the path to the folder where you stored all appendices
appendices_folder<-"C:/MInOSSE_Simulations_Scripts/R_Appendices/" # ending slash required!

#### Enter the path where you want to store all the simulations ####
my.path<-"C:/MInOSSE_Simulations_Scripts/R_Tests_minosse/"  # ending slash required!

#### this is the path of the folder where to store 100 species and 100 fossil localities simulations used to run MInOSSE with cooccurrence analysis ####
dir.path_coc_loc_100_100<-paste(my.path,"st-sims/coc_loc/spec100/locs100/",sep="") 
dir.create(dir.path_coc_loc_100_100, showWarnings = TRUE, recursive = TRUE)

#### this is the path of the folder where to store 100 species and 200 fossil localities simulations used to run MInOSSE with cooccurrence analysis ####
dir.path_coc_loc_100_200<-paste(my.path,"st-sims/coc_loc/spec100/locs200/",sep="") 
dir.create(dir.path_coc_loc_100_200, showWarnings = TRUE, recursive = TRUE)

#### this is the path of the folder where to store 100 species and 100 fossil localities simulations used to run MInOSSE without cooccurrence analysis ####
dir.path_no_coc_100_100<-paste(my.path,"st-sims/no_coc/spec100/locs100/",sep="") 
dir.create(dir.path_no_coc_100_100, showWarnings = TRUE, recursive = TRUE)

#### this is the path of the folder where to store 100 species and 200 fossil localities simulations used to run MInOSSE without cooccurrence analysis ####
dir.path_no_coc_100_200<-paste(my.path,"st-sims/no_coc/spec100/locs200/",sep="") 
dir.create(dir.path_no_coc_100_200, showWarnings = TRUE, recursive = TRUE)







#### Set the number of folds for AUC-based cross-validations of MInOSSE models.
# AUC-based cross-validations are additional analyses we allow to perform to test MInOSSE models performance
# and that add to the internal 5-folds cross-validation of Regression Kriging model performance measure.
# AUC-based cross-validations increase MInOSSE computational time as each pseudo-absences simulation 
# (default number = 10) is repeated as many times as the folds' number. As a consequence, we set 1 fold to 
# speed up MInOSSE, but the AUC values presented in the main manuscript (and related supplementary 
# informations) are based on a 5 folds AUC-based cross-validation procedure (see the main text).

n.folds<-1


#### By using cooccurrence analysis ####
##  Simulations of  100 speciess and 100 fossil localities considering, separately, highly clustered, moderately clustered,
# random and uniform spatial distributions, of both species' centres of distribution and fossil localities.
source(paste(appendices_folder,"st_sims_coc_loc_100specs_100locs.R",sep=""))
gc()

##  Simulations of  100 speciess and 200 fossil localities considering, separately, highly clustered, moderately clustered,
# random and uniform spatial distributions, of both species' centres of distribution and fossil localities.
rm(list=ls(all=TRUE)[-which(ls(all=TRUE)%in%c("appendices_folder","my.path","dir.path_coc_loc_100_100","dir.path_coc_loc_100_200","dir.path_no_coc_100_100","dir.path_no_coc_100_200","n.folds"))])
source(paste(appendices_folder,"st_sims_coc_loc_100specs_200locs.R",sep=""))
gc()






#### Without cooccurrence analysis ####
##  Simulations of  100 speciess and 100 fossil localities considering highly clustered, moderately clustered,
# random and uniform spatial distributions, separately, of both species' centres of distribution and fossil localities.
rm(list=ls(all=TRUE)[-which(ls(all=TRUE)%in%c("appendices_folder","my.path","dir.path_coc_loc_100_100","dir.path_coc_loc_100_200","dir.path_no_coc_100_100","dir.path_no_coc_100_200","n.folds"))])
source(paste(appendices_folder,"st_sims_no_coc_100specs_100locs.R",sep=""))
gc()

##  Simulations of  100 speciess and 200 fossil localities considering highly clustered, moderately clustered,
# random and uniform spatial distributions, separately, of both species' centres of distribution and fossil localities.
rm(list=ls(all=TRUE)[-which(ls(all=TRUE)%in%c("appendices_folder","my.path","dir.path_coc_loc_100_100","dir.path_coc_loc_100_200","dir.path_no_coc_100_100","dir.path_no_coc_100_200","n.folds"))])
source(paste(appendices_folder,"st_sims_no_coc_100specs_200locs.R",sep=""))
gc()


