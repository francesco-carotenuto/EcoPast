#### Random simulations ####
#### Description of the script ####
# These command lines are used to:
# 1) extract MInOSSE output computed for a specific set of simulations all at once;
# 2) perform the computation of MInOSSE, MCP and Alpha-hull outputs TSS scores as a comparative performance measures 
# in predicting actual simualted species geographic ranges and to store these results in a specific folder for further analyses;
# 3) perform a first comparison of all the three methods' TSS scores by means of the Student's t test.
# 4) prepare a graphical visualization of all the three methods' TSS scores.

#rm(list=ls(all=TRUE))
library(raster)
library(EcoPast)

##### Enter the path where you stored all the simulations ####
#my.path<-"E:/Tests_minosse/" 
#
##### Enter the path where you stored all the appendix files ####
#appendices_folder<-"E:/RICERCA/MINOSSE/Manuscript/Appendices/"

#### Enter the path where you want to save all the methods' performance metrics ####
results_path<-paste(my.path,"100_100_random_no_coc/",sep="")
dir.create(results_path, showWarnings = TRUE, recursive = TRUE)


##### Setting geographic projection ####
laea_prj<-CRS("+proj=laea +lon_0=85 +lat_0=45 +x_0=0 +y_0=0 +ellps=WGS84 +units=m +no_defs")

### loading 100_100_random_3_1861_no_coc data ####
tmp.env <- new.env() # creating a temporary environment
load(paste(my.path,"st-sims/no_coc/spec100/locs100/3-1861/100_100_random_3_1861_no_coc.RData",sep=""), envir=tmp.env) # loading workspace into temporary environment
minosse_res_list <- get("minosse_res_list", pos=tmp.env) # getting the required objects into the globalenv()
minosse_res_list<-lapply(minosse_res_list,function(x){x[[3]]<-NULL;
return(x)})
real_poly<-get("real_poly", pos=tmp.env)
pops<-get("pops", pos=tmp.env)
spec_list<-get("spec_list", pos=tmp.env)
spec_num<-get("spec_num", pos=tmp.env)
locs_num<-get("locs_num", pos=tmp.env)
spec_seed<-get("spec_seed", pos=tmp.env)
loc_seed<-get("loc_seed", pos=tmp.env)
reduced_general_sim_locs<-get("reduced_general_sim_locs", pos=tmp.env)
SpP_prj<-get("SpP_prj", pos=tmp.env)
rm(tmp.env)
gc()


#### Removing null results ####
valid_minosse<-sapply(minosse_res_list,function(x)!is.null(x))
which(valid_minosse!="FALSE")->valid_minosse
red_minosse_res_list<-minosse_res_list[valid_minosse]
red_spec_list<-spec_list[valid_minosse]
red_real_poly<-real_poly[which(names(real_poly)%in%red_spec_list)]
red_real_population<-pops[which(names(pops)%in%red_spec_list)]
name_part<-paste(spec_num,locs_num,spec_seed,loc_seed,"random",sep="_")


#### Assigning temporary environment stored object to final global environment and assigning them a name ####
test<-lapply(c("red_minosse_res_list",
               "red_real_population",
               "red_real_poly",
               "red_spec_list",
               "reduced_general_sim_locs"), function(x)eval(parse(text=paste(paste(x, name_part, sep="_"), x, sep="<<-"))))
# removing some stuff #
rm("loc_seed","locs_num","minosse_res_list","name_part","pops","real_poly","red_minosse_res_list","red_real_poly","red_real_population","red_spec_list","reduced_general_sim_locs","spec_list","spec_num","spec_seed","test","valid_minosse")
gc()


### loading 100_100_random_4_2004_no_coc data ####
tmp.env <- new.env()
load(paste(my.path,"st-sims/no_coc/spec100/locs100/4-2004/100_100_random_4_2004_no_coc.RData",sep=""), envir=tmp.env)
minosse_res_list <- get("minosse_res_list", pos=tmp.env)
minosse_res_list<-lapply(minosse_res_list,function(x){x[[3]]<-NULL;
return(x)})
real_poly<-get("real_poly", pos=tmp.env)
pops<-get("pops", pos=tmp.env)
spec_list<-get("spec_list", pos=tmp.env)
spec_num<-get("spec_num", pos=tmp.env)
locs_num<-get("locs_num", pos=tmp.env)
spec_seed<-get("spec_seed", pos=tmp.env)
loc_seed<-get("loc_seed", pos=tmp.env)
reduced_general_sim_locs<-get("reduced_general_sim_locs", pos=tmp.env)
SpP_prj<-get("SpP_prj", pos=tmp.env)
rm(tmp.env)
gc()



valid_minosse<-sapply(minosse_res_list,function(x)!is.null(x))
which(valid_minosse!="FALSE")->valid_minosse
red_minosse_res_list<-minosse_res_list[valid_minosse]
red_spec_list<-spec_list[valid_minosse]
red_real_poly<-real_poly[which(names(real_poly)%in%red_spec_list)]
red_real_population<-pops[which(names(pops)%in%red_spec_list)]
name_part<-paste(spec_num,locs_num,spec_seed,loc_seed,"random",sep="_")

test<-lapply(c("red_minosse_res_list",
               "red_real_population",
               "red_real_poly",
               "red_spec_list",
               "reduced_general_sim_locs"), function(x)eval(parse(text=paste(paste(x, name_part, sep="_"), x, sep="<<-"))))
rm("loc_seed","locs_num","minosse_res_list","name_part","pops","real_poly","red_minosse_res_list","red_real_poly","red_real_population","red_spec_list","reduced_general_sim_locs","spec_list","spec_num","spec_seed","test","valid_minosse")
gc()


### loading 100_100_random_6_2014_no_coc data ####
tmp.env <- new.env()
load(paste(my.path,"st-sims/no_coc/spec100/locs100/6-2014/100_100_random_6_2014_no_coc.RData",sep=""), envir=tmp.env)
minosse_res_list <- get("minosse_res_list", pos=tmp.env)
minosse_res_list<-lapply(minosse_res_list,function(x){x[[3]]<-NULL;
return(x)})
real_poly<-get("real_poly", pos=tmp.env)
pops<-get("pops", pos=tmp.env)
spec_list<-get("spec_list", pos=tmp.env)
spec_num<-get("spec_num", pos=tmp.env)
locs_num<-get("locs_num", pos=tmp.env)
spec_seed<-get("spec_seed", pos=tmp.env)
loc_seed<-get("loc_seed", pos=tmp.env)
reduced_general_sim_locs<-get("reduced_general_sim_locs", pos=tmp.env)
SpP_prj<-get("SpP_prj", pos=tmp.env)
rm(tmp.env)
gc()




valid_minosse<-sapply(minosse_res_list,function(x)!is.null(x))
which(valid_minosse!="FALSE")->valid_minosse
red_minosse_res_list<-minosse_res_list[valid_minosse]
red_spec_list<-spec_list[valid_minosse]
red_real_poly<-real_poly[which(names(real_poly)%in%red_spec_list)]
red_real_population<-pops[which(names(pops)%in%red_spec_list)]
name_part<-paste(spec_num,locs_num,spec_seed,loc_seed,"random",sep="_")

test<-lapply(c("red_minosse_res_list",
               "red_real_population",
               "red_real_poly",
               "red_spec_list",
               "reduced_general_sim_locs"), function(x)eval(parse(text=paste(paste(x, name_part, sep="_"), x, sep="<<-"))))
rm("loc_seed","locs_num","minosse_res_list","name_part","pops","real_poly","red_minosse_res_list","red_real_poly","red_real_population","red_spec_list","reduced_general_sim_locs","spec_list","spec_num","spec_seed","test","valid_minosse")
gc()


### loading 100_100_random_7_1789_no_coc data ####
tmp.env <- new.env()
load(paste(my.path,"st-sims/no_coc/spec100/locs100/7-1789/100_100_random_7_1789_no_coc.RData",sep=""), envir=tmp.env)
minosse_res_list <- get("minosse_res_list", pos=tmp.env)
minosse_res_list<-lapply(minosse_res_list,function(x){x[[3]]<-NULL;
return(x)})
real_poly<-get("real_poly", pos=tmp.env)
pops<-get("pops", pos=tmp.env)
spec_list<-get("spec_list", pos=tmp.env)
spec_num<-get("spec_num", pos=tmp.env)
locs_num<-get("locs_num", pos=tmp.env)
spec_seed<-get("spec_seed", pos=tmp.env)
loc_seed<-get("loc_seed", pos=tmp.env)
reduced_general_sim_locs<-get("reduced_general_sim_locs", pos=tmp.env)
SpP_prj<-get("SpP_prj", pos=tmp.env)
rm(tmp.env)
gc()




valid_minosse<-sapply(minosse_res_list,function(x)!is.null(x))
which(valid_minosse!="FALSE")->valid_minosse
red_minosse_res_list<-minosse_res_list[valid_minosse]
red_spec_list<-spec_list[valid_minosse]
red_real_poly<-real_poly[which(names(real_poly)%in%red_spec_list)]
red_real_population<-pops[which(names(pops)%in%red_spec_list)]
name_part<-paste(spec_num,locs_num,spec_seed,loc_seed,"random",sep="_")

test<-lapply(c("red_minosse_res_list",
               "red_real_population",
               "red_real_poly",
               "red_spec_list",
               "reduced_general_sim_locs"), function(x)eval(parse(text=paste(paste(x, name_part, sep="_"), x, sep="<<-"))))
rm("loc_seed","locs_num","minosse_res_list","name_part","pops","real_poly","red_minosse_res_list","red_real_poly","red_real_population","red_spec_list","reduced_general_sim_locs","spec_list","spec_num","spec_seed","test","valid_minosse")
gc()




### loading 100_100_random_1979_2015_no_coc data ####
tmp.env <- new.env()
load(paste(my.path,"st-sims/no_coc/spec100/locs100/1979-2015/100_100_random_1979_2015_no_coc.RData",sep=""), envir=tmp.env)
minosse_res_list <- get("minosse_res_list", pos=tmp.env)
minosse_res_list<-lapply(minosse_res_list,function(x){x[[3]]<-NULL;
return(x)})
real_poly<-get("real_poly", pos=tmp.env)
pops<-get("pops", pos=tmp.env)
spec_list<-get("spec_list", pos=tmp.env)
spec_num<-get("spec_num", pos=tmp.env)
locs_num<-get("locs_num", pos=tmp.env)
spec_seed<-get("spec_seed", pos=tmp.env)
loc_seed<-get("loc_seed", pos=tmp.env)
reduced_general_sim_locs<-get("reduced_general_sim_locs", pos=tmp.env)
SpP_prj<-get("SpP_prj", pos=tmp.env)
rm(tmp.env)
gc()




valid_minosse<-sapply(minosse_res_list,function(x)!is.null(x))
which(valid_minosse!="FALSE")->valid_minosse
red_minosse_res_list<-minosse_res_list[valid_minosse]
red_spec_list<-spec_list[valid_minosse]
red_real_poly<-real_poly[which(names(real_poly)%in%red_spec_list)]
red_real_population<-pops[which(names(pops)%in%red_spec_list)]
name_part<-paste(spec_num,locs_num,spec_seed,loc_seed,"random",sep="_")

test<-lapply(c("red_minosse_res_list",
               "red_real_population",
               "red_real_poly",
               "red_spec_list",
               "reduced_general_sim_locs"), function(x)eval(parse(text=paste(paste(x, name_part, sep="_"), x, sep="<<-"))))
rm("loc_seed","locs_num","minosse_res_list","name_part","pops","real_poly","red_minosse_res_list","red_real_poly","red_real_population","red_spec_list","reduced_general_sim_locs","spec_list","spec_num","spec_seed","test","valid_minosse")
gc()




#### Loading the function to compute methods' performance ####
source(paste(appendices_folder,"compare.results.R",sep=""))







#### Computing MInOSSE, MCP and Alpha-hull methods performances in predicting simulated actual species geographic ranges by TSS scores ####
comp_res_100_100_3_1861_random<-list()
for(j in 1:length(red_spec_list_100_100_3_1861_random)){
  if(class(try(comp_res_100_100_3_1861_random[[j]]<-compare.results(i=j,mask_res=TRUE,use.dist = FALSE,general_sim_locs=reduced_general_sim_locs_100_100_3_1861_random,compare.with="occupancy",species_list=red_spec_list_100_100_3_1861_random,minosse_res=red_minosse_res_list_100_100_3_1861_random,real_polygon=red_real_poly_100_100_3_1861_random,real_population=red_real_population_100_100_3_1861_random)))=="try-error") {next} 
  print(j)
}
comp_res_100_100_4_2004_random<-list()
for(j in 1:length(red_spec_list_100_100_4_2004_random)){
  if(class(try(comp_res_100_100_4_2004_random[[j]]<-compare.results(i=j,mask_res=TRUE,use.dist = FALSE,general_sim_locs=reduced_general_sim_locs_100_100_4_2004_random,compare.with="occupancy",species_list=red_spec_list_100_100_4_2004_random,minosse_res=red_minosse_res_list_100_100_4_2004_random,real_polygon=red_real_poly_100_100_4_2004_random,real_population=red_real_population_100_100_4_2004_random)))=="try-error") {next} 
  print(j)
}
comp_res_100_100_6_2014_random<-list()
for(j in 1:length(red_spec_list_100_100_6_2014_random)){
  if(class(try(comp_res_100_100_6_2014_random[[j]]<-compare.results(i=j,mask_res=TRUE,use.dist = FALSE,general_sim_locs=reduced_general_sim_locs_100_100_6_2014_random,compare.with="occupancy",species_list=red_spec_list_100_100_6_2014_random,minosse_res=red_minosse_res_list_100_100_6_2014_random,real_polygon=red_real_poly_100_100_6_2014_random,real_population=red_real_population_100_100_6_2014_random)))=="try-error") {next} 
  print(j)
}
comp_res_100_100_7_1789_random<-list()
for(j in 1:length(red_spec_list_100_100_7_1789_random)){
  if(class(try(comp_res_100_100_7_1789_random[[j]]<-compare.results(i=j,mask_res=TRUE,use.dist = FALSE,general_sim_locs=reduced_general_sim_locs_100_100_7_1789_random,compare.with="occupancy",species_list=red_spec_list_100_100_7_1789_random,minosse_res=red_minosse_res_list_100_100_7_1789_random,real_polygon=red_real_poly_100_100_7_1789_random,real_population=red_real_population_100_100_7_1789_random)))=="try-error") {next} 
  print(j)
}
comp_res_100_100_1979_2015_random<-list()
for(j in 1:length(red_spec_list_100_100_1979_2015_random)){
  if(class(try(comp_res_100_100_1979_2015_random[[j]]<-compare.results(i=j,mask_res=TRUE,use.dist = FALSE,general_sim_locs=reduced_general_sim_locs_100_100_1979_2015_random,compare.with="occupancy",species_list=red_spec_list_100_100_1979_2015_random,minosse_res=red_minosse_res_list_100_100_1979_2015_random,real_polygon=red_real_poly_100_100_1979_2015_random,real_population=red_real_population_100_100_1979_2015_random)))=="try-error") {next} 
  print(j)
}



#### Merging the results of all the simulations ####
whole_comp_res<-list(comp_res_100_100_3_1861_random,comp_res_100_100_4_2004_random,comp_res_100_100_6_2014_random,comp_res_100_100_7_1789_random,comp_res_100_100_1979_2015_random)
comp_res<-lapply(whole_comp_res,function(x)lapply(x,function(y) y$TSS))
valid_comp_res<-lapply(comp_res,function(x)which(sapply(x,function(y)!is.null(y))))
combined_results<-mapply(function(z,y) z[y], comp_res, valid_comp_res,SIMPLIFY=FALSE)
lapply(combined_results,function(x)do.call(rbind,x))->combined_results
red_minosse_res_list<-list(red_minosse_res_list_100_100_3_1861_random,red_minosse_res_list_100_100_4_2004_random,red_minosse_res_list_100_100_6_2014_random,red_minosse_res_list_100_100_7_1789_random,red_minosse_res_list_100_100_1979_2015_random)
red_spec_list<-list(red_spec_list_100_100_3_1861_random,red_spec_list_100_100_4_2004_random,red_spec_list_100_100_6_2014_random,red_spec_list_100_100_7_1789_random,red_spec_list_100_100_1979_2015_random)
red_real_poly<-list(red_real_poly_100_100_3_1861_random,red_real_poly_100_100_4_2004_random,red_real_poly_100_100_6_2014_random,red_real_poly_100_100_7_1789_random,red_real_poly_100_100_1979_2015_random)
reduced_general_sim_locs<-list(reduced_general_sim_locs_100_100_3_1861_random,reduced_general_sim_locs_100_100_4_2004_random,reduced_general_sim_locs_100_100_6_2014_random,reduced_general_sim_locs_100_100_7_1789_random,reduced_general_sim_locs_100_100_1979_2015_random)
red_real_population<-list(red_real_population_100_100_3_1861_random,red_real_population_100_100_4_2004_random,red_real_population_100_100_6_2014_random,red_real_population_100_100_7_1789_random,red_real_population_100_100_1979_2015_random)

#### Extracting the occurrence number of all the simulated fossil species ####
pres_num<-mapply(function(z,y,q) data.frame(spec=q[y],occ=sapply(z[y],function(x)length(x$pts))), red_minosse_res_list,valid_comp_res,red_spec_list,SIMPLIFY=FALSE  )

#### Assigning species names to all the simulated occurrences populations #### 
red_real_population<-mapply(function(x,y) {x[match(y,names(x))]->x;
  return(x)}, red_real_population, red_spec_list, SIMPLIFY=FALSE )

#### Combining occurrence number and performance results ####
test<-mapply(function(x,y) data.frame(x,y),pres_num,combined_results,SIMPLIFY=FALSE)
do.call(rbind,test)->test
test->stats
colnames(stats)<-c("spec","occ","alpha_hull","MCP","Default","Sens=Spec","MaxSens+Spec","MaxKappa","MaxPCC","PredPrev=Obs","ObsPrev","MeanProb","MinROCdist","ReqSens","ReqSpec","Cost")


#### Setting performance data for saving and statistical analyses ####
stats_4_line_plot<-apply(test[which(complete.cases(test[,-1])),-1],2,function(x)aggregate(x~occ,data=test[which(complete.cases(test[,-1])),-1],FUN=mean)[,2])
colnames(stats_4_line_plot)<-c("occ","alpha_hull","MCP","Default","Sens=Spec","MaxSens+Spec","MaxKappa","MaxPCC","PredPrev=Obs","ObsPrev","MeanProb","MinROCdist","ReqSens","ReqSpec","Cost")
stats<-as.data.frame(stats)
stats<-stats[,-c(5,14,15,16)]
stats_4_line_plot<-as.data.frame(stats_4_line_plot)
stats_4_line_plot<-stats_4_line_plot[,-c(4,13,14,15)]
write.table(stats,paste(results_path_100_100_no_coc,"stats_100_100_random_no_coc.txt",sep=""))

#### Comparing MInOSSE to alpha hull performance by the student's T test ####
stats->stats_for_student
student_results_alpha_hull<-apply(stats_for_student[,-c(1,2,4)],2,function(x) try(t.test(stats_for_student[,3],x,alternative = "less",paired=TRUE)))
#### Comparing MInOSSE to MCP performance by the student's T test ####
student_results_MCP<-apply(stats_for_student[,-c(1,2,3)],2,function(x) try(t.test(stats_for_student[,4],x,alternative = "less",paired=TRUE)))
versus_alpha_hull<-do.call(rbind,lapply(student_results_alpha_hull[-1],function(x) data.frame(t=x$statistic,df=x$parameter,p_value=x$p.value)))
versus_MCP<-do.call(rbind,lapply(student_results_MCP[-1],function(x) data.frame(t=x$statistic,df=x$parameter,p_value=x$p.value)))

#### See the comparisons' results ####
versus_alpha_hull
versus_MCP


#### Plotting the comparisons' results ####
lapply(stats_4_line_plot[,-which(colnames(stats_4_line_plot)=="occ")],function(x)cbind(stats_4_line_plot[,which(colnames(stats_4_line_plot)=="occ")],x))->ciccio
do.call(rbind,ciccio)->ciccio
lapply(colnames(stats_4_line_plot)[-which(colnames(stats_4_line_plot)=="occ")],function(x)rep(x,nrow(stats_4_line_plot)))->col_names
unlist(col_names)->col_names
data.frame(model_th=col_names,ciccio)->ciccio
set.seed(10)
ciccio->new_ciccio
jitter(new_ciccio$x,amount=abs(min(new_ciccio$x))/10)->new_ciccio$x # adding some variability to the different MInOSSE binarized maps' TSS scores to make them all visible in the plot

#### A line plot showing the models' performances with the number of occurrences ####
library(ggplot2)
line_plot<-ggplot(new_ciccio, aes(V1, x, colour = model_th)) +
  geom_line(size=1.5)+ scale_colour_brewer(type = "div",palette ="Spectral")
  
#### A box plot showing the models' performances by means of TSS scores ####
stats->stats_4_boxplot
lapply(stats_4_boxplot[,-which(colnames(stats_4_boxplot)%in%c("spec","occ"))],function(x)cbind(stats_4_boxplot[,which(colnames(stats_4_boxplot)%in%c("spec","occ"))],x))->ciccio_box
do.call(rbind,ciccio_box)->ciccio_box
lapply(colnames(stats_4_boxplot)[-which(colnames(stats_4_boxplot)%in%c("spec","occ"))],function(x)rep(x,nrow(stats_4_boxplot)))->col_names_box
unlist(col_names_box)->col_names_box
data.frame(model_th=col_names_box,ciccio_box)->ciccio_box
box_plot<-ggplot(ciccio_box,aes(model_th, x, fill = model_th)) +
  geom_boxplot()+
  scale_x_discrete(limits=unique(as.character(ciccio_box[,1])))+
  scale_fill_brewer(type = "div",palette ="Spectral")
###

