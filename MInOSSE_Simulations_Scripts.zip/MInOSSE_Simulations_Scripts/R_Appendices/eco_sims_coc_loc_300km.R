#rm(list=ls(all=T))
#gc()

library(EcoPast)
library(raster)
library(sdmvspecies)
library(foreach)
library(doSNOW)
library(doParallel)
library(rgeos)
library(scales)
library(KernSmooth)
library(dismo)


##### Enter the path where you want to store all the simulations ####
#my.path<-"E:/Tests_minosse/" 
#
##### this is the path where to store 100 species and 100 fossil localities simulations used to run MInOSSE with cooccurrence analysis ####
#dir.path<-paste(my.path,"eco-sims/coc_loc/",sep="") 
#dir.create(dir.path, showWarnings = TRUE, recursive = TRUE)
#
##### Download LGM time period bioclimatic variables and store files into "my.path" folder ####
#download.file("http://biogeo.ucdavis.edu/data/climate/cmip5/lgm/cclgmbi_10m.zip", paste(my.path,"cclgmbi_10m.zip",sep=""))
#unzip(zipfile=paste(my.path,"cclgmbi_10m.zip",sep=""),exdir=paste(my.path,"LGM",sep=""))

#### LGM 2014 coc by locality ####
#### Create the folder where storing LGM mammalian species simulations ####
setwd(dir.path)
sim.dir<-"6-2014/"
dir.create(sim.dir, showWarnings = TRUE, recursive = TRUE) 

#### Setting seeds for actual simulated populations experiment replication ####
spec_seed<-6 # the seed for populations simulations
loc_seed<-2014 # the seed for fossil localities simulations
fossil_seed<-13 # the seed for fossilization bias simulation

#### Loading LGM bioclimatic rasters ####
bioclim<-stack(lapply(list.files(paste(my.path,"LGM",sep=""),pattern=".tif"),function(x)raster(paste(paste(my.path,"LGM/",sep=""),x,sep=""))))
# reordering bioclim variables 
target_order<-1:19
bioclim<-bioclim[[match(target_order,do.call(rbind,strsplit(names(bioclim),"cclgmbi"))[,2])]]
#### Cropping raster stack by Eurasia spatial extent ####
crop(bioclim,extent(c(-18,180),c(-10.33333,83.66667)))->bioclim

#### Projecting LGM bioclimatic stack into a Lambert Azimuthal equal area projection ####
lon_0<-85
lat_0<-45
laea_prj<-CRS(paste("+proj=laea +lon_0=",lon_0," +lat_0=",lat_0," +x_0=0 +y_0=0 +ellps=WGS84 +units=m +no_defs",sep="")) 

#### Forcing a cell resulution of 100 x 100 km ####
projectRaster(bioclim,crs=laea_prj,res = c(100000,100000))->bioclim_100

#### Isolating Eurasia continent ####
x_coords<-c(-7373890.7,-5322231.2,-4850585.4,-4426104.1,-2893255.1,-2751761.3,-2173995.1,-1594755.0,
            -896129.6,-235825.4,484908.4,1381035.5,3190976.5,4051730.2,5018604.2,5472563.4,
            5848947.6,5909452.4,6036051.4,5549823.8,5618804.5,4983230.8,4617705.2,4688452.1,
            4546958.4,4228597.4,3780533.8,3108438.5,2389178.6,986032.1,-806222.1,-1089209.6,
            -1478317.5,-1855634.2,-2197577.4,-2905046.2,-3482812.4,-3883711.4,-4178490.0,-4319983.8,
            -4520433.3,-4650135.9,-4599286.6,-4575704.3,-4583810.7,-4968496.8,-5168946.3,-5734921.4,
            -5970744.3,-6088655.7,-6171193.8,-6241940.6,-6277314.1,-6348061.0,-6442390.1,-6583883.9,
            -6713586.5,-6807915.7,-6937618.3,-7102694.3,-7255979.2,-7468219.9,-7586131.3,-7704042.8,
            -7833745.4,-7928074.6,-8022403.8,-8081359.5,-8222853.3,-8376138.2,-8482258.5,-8352555.9,
            -8152106.4,-7869118.9,-7739416.2,-7621504.8,-7373890.7)

y_coords<-c(6766768.2,7320952.1,7462445.8,7816180.2,8405737.5,8523649.0,8635664.9,8672512.2,
            8696094.5,8696094.5,8681355.6,8623873.7,8535440.1,8364468.5,8264243.8,8175810.2,
            7408450.5,7145631.3,6918495.8,6596434.9,6145951.0,1401796.5, 505669.4,-366875.4,
            -838521.3,-1156882.3,-1274793.7,-1369122.9,-1251211.4,-826730.2,375966.8,717910.0,
            1142391.3,1790904.4,2121056.5,1826277.8,1590454.9,1448961.1,1590454.9,2168221.0,
            2875689.8,3370918.0,3589791.1,3730548.0,3860987.5,3972266.5,4054804.5,4137342.5,
            4149133.7,4149133.7,4196298.2,4278836.3,4373165.4,4502868.0,4538241.5,4573614.9,
            4585406.1,4561823.8,4538241.5,4502868.0,4467494.6,4420330.0,4396747.7,4337792.0,
            4326000.9,4314209.7,4337792.0,4326000.9,4314209.7,4326000.9,4467494.6,4844811.3,
            5257501.4,5681982.7,5847058.7,6483780.7,6766768.2)

Polygon(data.frame(x_coords,y_coords))->lgm_w
list(Polygons(list(lgm_w), ID="lgm"))->lgm_w
lgm_w<-SpatialPolygons(lgm_w,proj4string=CRS("+proj=moll +lon_0=85 +x_0=0 +y_0=0 +ellps=WGS84 +units=m +no_defs"))
spTransform(lgm_w,CRS=laea_prj)->lgm_w
mask(bioclim_100,lgm_w)->bioclim_100

#### Selecting the variables representing temperature and precipitation annual mean values
# and their temporal range of variation 
bioclim_100<-bioclim_100[[c(1,8,9,12,16,17)]]
values(bioclim_100[[1]])/10->values(bioclim_100[[1]])
values(bioclim_100[[2]])/10->values(bioclim_100[[2]])
values(bioclim_100[[3]])/10->values(bioclim_100[[3]])


#### Loading the LGM mammal species dataset used to derive bioclimatic preferences of simulated species ####
data(lgm)
lgm$spec<-as.character(lgm$spec)
lgm[order(lgm$spec),]->lgm
coordinates(lgm)<-~x+y
proj4string(lgm)<-CRS("+proj=longlat +datum=WGS84")
spTransform(lgm,CRS=crs(bioclim_100))->lgm
lgm[lgm_w,]->lgm
split(lgm,lgm$spec)->lgm

#### Subsetting LGM species with more than 4 occurrences ####
valid_lgm_spec<-which(sapply(lgm,function(x)length(x))>4)
lgm[valid_lgm_spec]->lgm

#### Extracting bioclimatic variables at LGM species fossil sites ####
lapply(lgm,function(x)extract(bioclim_100,x))->lgm_values


#bioclim_100->all_ras
#### Computation of empirical values for the setting of the "Artificial Bell Response" method for virtual species simulations. Varela et al. (2014) ####
## Computing mean values of the selected bioclimatic variables for each species ## 
bio_1_mean<-as.vector(na.omit(sapply(lgm_values,function(x)mean(x[,1]))))
bio_8_mean<-as.vector(na.omit(sapply(lgm_values,function(x)mean(x[,2]))))  
bio_9_mean<-as.vector(na.omit(sapply(lgm_values,function(x)mean(x[,3]))))  
bio_12_mean<-as.vector(na.omit(sapply(lgm_values,function(x)mean(x[,4]))))  
bio_16_mean<-as.vector(na.omit(sapply(lgm_values,function(x)mean(x[,5]))))  
bio_17_mean<-as.vector(na.omit(sapply(lgm_values,function(x)mean(x[,6]))))  
bio_names<-names(bioclim_100)    

#### Computing the standard deviations of the selected bioclimatic variables for each species #### 
bio_1_sd<-as.vector(na.omit(sapply(lgm_values,function(x)sd(x[,1]))))  
bio_8_sd<-as.vector(na.omit(sapply(lgm_values,function(x)sd(x[,2]))))  
bio_9_sd<-as.vector(na.omit(sapply(lgm_values,function(x)sd(x[,3]))))  
bio_12_sd<-as.vector(na.omit(sapply(lgm_values,function(x)sd(x[,4]))))  
bio_16_sd<-as.vector(na.omit(sapply(lgm_values,function(x)sd(x[,5]))))  
bio_17_sd<-as.vector(na.omit(sapply(lgm_values,function(x)sd(x[,6]))))  

bio1<-paste(bio_names[1],bio_1_mean,bio_1_sd)
bio8<-paste(bio_names[2],bio_8_mean,bio_8_sd)
bio9<-paste(bio_names[3],bio_9_mean,bio_9_sd)
bio12<-paste(bio_names[4],bio_12_mean,bio_12_sd)
bio16<-paste(bio_names[5],bio_16_mean,bio_16_sd)
bio17<-paste(bio_names[6],bio_17_mean,bio_17_sd)

configs_100<-list()
for(i in 1:length(bio1)){
  configs_100[[i]]<-list(as.vector(strsplit(bio1[i]," ")[[1]]),as.vector(strsplit(bio8[i]," ")[[1]]),as.vector(strsplit(bio9[i]," ")[[1]]),as.vector(strsplit(bio12[i]," ")[[1]]),as.vector(strsplit(bio16[i]," ")[[1]]),as.vector(strsplit(bio17[i]," ")[[1]]))
}

#### Using the artificial bell response algorithm for simulating species suitability maps with well-defined bioclimatic preferences ####
species.raster<-list()
for(i in 1:length(bio1)) {
  species.raster[[i]] <- artificialBellResponse(stack(bioclim_100), configs_100[[i]])  
}
valid_raster<-sapply(species.raster,function(x)diff(range(as.vector(na.omit(values(x))))))!=0
species.raster[valid_raster]->species.raster

#### Generating species occurrences' populations inside suitability maps ####
gimme.pop<-function(ras,pop.num,Replace,seed){
  my.randomPoints<-function (mask, n, p, ext = NULL, extf = 1.1, excludep = TRUE, 
                             prob = FALSE, cellnumbers = FALSE, tryf = 3, warn = 2, lonlatCorrection = TRUE,Replace=Replace) 
  {
    if (nlayers(mask) > 1) {
      mask <- raster(mask, 1)
    }
    tryf <- max(round(tryf[1]), 1)
    if (missing(p)) {
      excludep <- FALSE
    }
    else {
      if (inherits(p, "SpatialPoints")) {
        p <- coordinates(p)
      }
    }
    if (class(ext) == "character") {
      if (!ext %in% c("points")) {
        stop("if ext is a character variable it should be 'points'")
      }
      else if (missing(p)) {
        warning("if p is missing, 'ext=points' is meaningless")
        ext <- extent(mask)
      }
      else {
        ext <- extent(min(p[, 1]), max(p[, 1]), min(p[, 2]), 
                      max(p[, 2]))
      }
    }
    if (!is.null(ext)) {
      ext <- extent(ext)
      ext <- ext * extf
      ext <- intersect(ext, extent(mask))
      mask2 <- crop(raster(mask), ext)
    }
    else {
      mask2 <- raster(mask)
    }
    if (n > ncell(mask2)) {
      n <- ncell(mask2)
      if (warn > 0) {
        warning("changed n to ncell of the mask (extent)")
      }
    }
    nn <- n * tryf
    nn <- max(nn, 10)
    if (prob) {
      stopifnot(hasValues(mask))
      cells <- crop(mask, mask2)
      cells <- try(stats::na.omit(cbind(1:ncell(cells), getValues(cells))))
      if (class(cells) == "try-error") {
        stop("the raster is too large to be used with 'prob=TRUE'")
      }
      prob <- cells[, 2]
      cells <- cells[, 1]
      if (couldBeLonLat(mask)) {
        rows <- rowFromCell(mask2, cells)
        y <- yFromRow(mask2, rows)
        dx <- pointDistance(cbind(0, y), cbind(xres(mask2), 
                                               y), longlat = TRUE)
        prob <- prob * dx
      }
      cells <- sample(cells, nn, prob = prob,replace =Replace)
      xy <- xyFromCell(mask2, cells)
      cells <- cellFromXY(mask, xy)
    }
    else if (canProcessInMemory(mask2)) {
      cells <- crop(mask, mask2)
      if (hasValues(cells)) {
        cells <- which(!is.na(getValues(cells)))
      }
      else {
        cells <- 1:ncell(cells)
      }
      nn <- min(length(cells), nn)
      if (lonlatCorrection & couldBeLonLat(mask)) {
        rows <- rowFromCell(mask2, cells)
        y <- yFromRow(mask2, rows)
        dx <- pointDistance(cbind(0, y), cbind(xres(mask2), 
                                               y), longlat = TRUE)
        cells <- sample(cells, nn, prob = dx)
      }
      else {
        cells <- sample(cells, nn)
      }
      xy <- xyFromCell(mask2, cells)
      cells <- cellFromXY(mask, xy)
    }
    else {
      nn <- min(ncell(mask2), nn)
      if (couldBeLonLat(mask2)) {
        cells <- .randomCellsLonLat(mask2, nn)
      }
      else {
        if (nn >= ncell(mask2)) {
          cells <- 1:ncell(mask2)
        }
        else {
          cells <- sampleInt(ncell(mask2), nn)
        }
      }
      xy <- xyFromCell(mask2, cells)
      cells <- cellFromXY(mask, xy)
      if (hasValues(mask)) {
        vals <- cbind(cells, extract(mask, cells))
        cells <- stats::na.omit(vals)[, 1]
      }
    }
    if (excludep) {
      pcells <- cellFromXY(mask, p)
      cells <- cells[!(cells %in% pcells)]
    }
    if (length(cells) > n) {
      cells <- sample(cells, n)
    }
    else if (length(cells) < n) {
      frac <- length(cells)/n
      if (frac < 0.1) {
        stop("generated random points = ", frac, " times requested number; Use a higher value for tryf")
      }
      if (frac < 0.5 & warn == 1) {
        warning("generated random points = ", frac, " times requested number; Use a higher value for tryf")
      }
      else if (warn > 1) {
        warning("generated random points = ", frac, " times requested number")
      }
    }
    if (cellnumbers) {
      return(cells)
    }
    else {
      return(xyFromCell(mask, cells))
    }
  }
  
  
  mask_spec_raster<-ras
  values(mask_spec_raster)[values(mask_spec_raster)<0.01]<-NA
  set.seed(seed)
  pop<-as.data.frame(my.randomPoints(mask_spec_raster,pop.num,prob=TRUE,Replace=Replace))
  
  coordinates(pop)<-~x+y
  crs(pop)<-crs(ras)
  return(pop)
}
ras_area<-sapply(species.raster,function(x)length(x[x>0.01])*prod(res(x)))
ras_area<-data.frame(are_order=1:length(ras_area),area=ras_area)
ras_area<-ras_area[order(ras_area$area),]

# Generating a log2(normal) distribution of species accurrences according to Preston, 1962 
set.seed(spec_seed)
pop_num<-sample(2^(rnorm(100,log(1000,2),log(1000,2)/10)),length(species.raster))
pop_num<-sort(pop_num)
data.frame(ras_area,pop_num=pop_num)->spec_eco
spec_eco<-spec_eco[order(spec_eco$are_order),]
pops<-lapply(seq(1:length(species.raster)),function(x)gimme.pop(ras=species.raster[[x]],pop.num=spec_eco[x,"pop_num"],Replace=TRUE,seed=spec_seed))
lapply(pops,function(x){x$age<-rep(1,length(x));
return(x)})->pops
names(pops)<-paste("species",1:length(pops),sep="_")
mapply(function(x,y){x$spec<-rep(y,length(x));
return(x)},pops,names(pops),SIMPLIFY = FALSE)->pops
populations<-do.call(rbind, pops)
populations->prj_populations
extent(lgm_w)[1:2]->x_lim
extent(lgm_w)[3:4]->y_lim

#### Generating simulated species geographic ranges by using a 100 x 100 km sampling grid ####
sampling_grid<-expand.grid(x=seq(from=x_lim[1],to=x_lim[2],100000),y=seq(from=y_lim[1],to=y_lim[2],100000))
bioclim_100[[1]]->prediction_ground
coordinates(sampling_grid)<-~x+y
gridded(sampling_grid)<-TRUE
crs(sampling_grid)<-laea_prj
as(sampling_grid,"SpatialPolygons")->sampling_grid


cl <- makeCluster(2, type="SOCK")
registerDoSNOW (cl)
foreach(i=1:length(pops),.packages=c("raster")) %dopar% {
  over(pops[[i]],sampling_grid)->original_over_res
}->original_over_res
stopCluster(cl)
doParallel::stopImplicitCluster()
##

lapply(original_over_res,function(x){sampling_grid[unique(x)[!is.na(unique(x))]]->x;
  return(x)})->real_poly
for(i in 1:length(real_poly)) {
  rgeos::gUnaryUnion(real_poly[[i]])->real_poly[[i]]
  print(i)
}
##

sapply(pops,function(x)length(x))->abundance

lapply(pops,function(x)unique(as.character(x$spec)))->pops_names
names(pops)<-pops_names
names(real_poly)<-pops_names
sapply(real_poly,function(x)gArea(x))->areas


#### Simulating spatial accurrences of fossil sites by using the spatial density of actual LGM mammalian fossil localiteis ####
data(lgm)
lgm$spec<-as.character(lgm$spec)
rownames(lgm)<-NULL
lgm[,c("x","y")]->lgm_distr
coordinates(lgm_distr)<-~x+y
proj4string(lgm_distr)<-CRS("+proj=longlat +datum=WGS84")
spTransform(lgm_distr,CRS=crs(species.raster[[1]]))->lgm_distr
lgm_distr<-lgm_distr[-zerodist(lgm_distr)[,2],]
point_dist<-dist(coordinates(lgm_distr),method = "euclidean")
bandw<-median(apply(as.matrix(point_dist),1,function(x)min(x[x!=0])))
est <- bkde2D(coordinates(lgm_distr), 
              bandwidth=c(bandw,bandw), 
              gridsize=c(nrow(species.raster[[1]]),ncol(species.raster[[1]])))
dens_layer = raster(list(x=est$x1,y=est$x2,z=est$fhat))
crs(dens_layer)<-crs(species.raster[[1]])
dens_layer<-projectRaster(from=dens_layer,to=species.raster[[1]]) ;
values(dens_layer)[!is.na(values(dens_layer))]<-scales:: rescale(values(dens_layer)[!is.na(values(dens_layer))],c(0,1))
values(dens_layer)[is.na(values(dens_layer))]<-0
dens_layer[!is.na(dens_layer)]<-scales:: rescale(dens_layer[!is.na(dens_layer)],c(0,1))
dens_layer[is.na(species.raster[[1]]),]<-NA
lapply(pops,function(x)extract(dens_layer,x,cellnumbers=TRUE))->lgm_ID_prob
pops<-mapply(function(x,y) {x$prob<-y[,2];
x$age<-1
return(x)}, pops,lgm_ID_prob,SIMPLIFY=FALSE)

set.seed(loc_seed)
sim_locs<-randomPoints(dens_layer,length(unique(as.character(lgm$loc_id))),prob = TRUE)
sim_locs<-as.data.frame(sim_locs)
coordinates(sim_locs)<-~x+y
crs(sim_locs)<-crs(species.raster[[1]])

#### Extracting species identity by overlapping species polygon geographic ranges by the simulated fossil localities ####
lapply(real_poly,function(x){
  over(x,sim_locs,returnList=TRUE)  
})->over_res

sapply(over_res,function(x)length(x[[1]]))->to_keep
names(which(to_keep>0))->to_keep
over_res[names(over_res)%in%to_keep]->over_res
real_poly[names(real_poly)%in%to_keep]->real_poly
pops[names(pops)%in%to_keep]->pops
populations[populations$spec%in%to_keep,]->populations
areas[names(areas)%in%to_keep]->areas

mapply(function(x,y) {data.frame(x,spec=rep(y,length(x)))->z;
  return(z)},over_res,names(over_res),SIMPLIFY = FALSE)->over_res
over_res<-lapply(over_res,function(x)data.frame(coordinates(sim_locs)[match(x$X1,rownames(coordinates(sim_locs))),],x))
over_res<-do.call(rbind,over_res)
rownames(over_res)<-NULL
over_res<-over_res[order(over_res$X1),]
colnames(over_res)[3]<-"loc_id"
coordinates(over_res)<-~x+y
crs(over_res)<-crs(species.raster[[1]])
over_res->lgm_sim_dat
spTransform(lgm_sim_dat,CRS=CRS("+proj=longlat +datum=WGS84"))->lgm_sim_dat
lgm_sim_dat<-as.data.frame(lgm_sim_dat)
as.character(lgm_sim_dat$spec)->lgm_sim_dat$spec
species_names<-unique(lgm_sim_dat$spec)


#### Simulating a nagative relationship between fossilization bias and species geographic ranges #### 
taf_bias<-seq(from=0.5,to=0.8,length.out = length(species_names))
data.frame(sort(areas),sort(taf_bias,decreasing=TRUE))->taf_data
set.seed(fossil_seed)
red_lgm_sim_dat<-lapply(1:nrow(taf_data),function(z){
  lgm_sim_dat[which(lgm_sim_dat$spec==rownames(taf_data)[z]),]->lgm_spec
  rownames(lgm_spec)<-NULL
  to_rem<-round(taf_data[z,2]*nrow(lgm_spec))
  lgm_spec[-as.numeric(sample(rownames(lgm_spec),to_rem)),]->lgm_spec;
  rownames(lgm_spec)<-NULL
  return(lgm_spec)
})
do.call(rbind,red_lgm_sim_dat)->red_lgm_sim_dat

red_lgm_sim_dat$age<-1
#### LGM simulation end ####



#### Performing MInOSSE ####
Sys.getenv("R_MAX_NUM_DLLs", unset = 1000)
unique(as.character(red_lgm_sim_dat$spec))->spec_list

minosse_dat<-list()
minosse_res_list<-list()
for(i in 1:length(spec_list)){
  if(class(try(minosse_dat[[i]]<-minosse.data(
    obj=red_lgm_sim_dat,
    species_name=spec_list[i],
    domain="land",
    coc.by="locality",
    min.occs=3,
    abiotic.covs=NULL,
    combine.covs=FALSE,   
    reduce_covs_by="pca",
    covs_th=0.95,
    c.size=300000,
    bkg.predictors="presence", 
    min.bkg=100,
    sampling.by.distance=TRUE,
    prediction.ground=prediction_ground,
    crop.by.mcp=FALSE,
    projection="laea",
    lon_0=85,
    lat_0=45,
    n.clusters=clus_num, 
    seed=625)
  ))=="try-error") {next} else {minosse_dat[[i]]<-minosse_dat[[i]];
  
  
  if(class(try(minosse_res_list[[i]]<-minosse.target(
    resp=minosse_dat[[i]][[1]],
    predictors=minosse_dat[[i]][[2]],
    bkg="presence",
    min.bkg = 100,
    n.sims=10,
    sampling.by.distance=TRUE,
    n.folds=n.folds,
    n.sims.clusters=clus_num,
    seed=625)))=="try-error") {next} else minosse_res_list[[i]]<-minosse_res_list[[i]] 
  }
  print(i)
}
gc()

#### Saving results ####

save.image(paste(paste(dir.path,sim.dir,sep=""),"LGM_13_6_2014_coc_loc_300km.RData",sep=""))
gc()






#### LGM 1789 coc by locality ####

rm(list=ls(all=TRUE)[-which(ls(all=TRUE)%in%c("dir.path","appendices_folder","n.folds","dir.path_no_coc","my.path","clus_num","species.raster","configs_100","lgm_w","lgm","bioclim_100","lgm_distr","dens_layer","laea_prj"))])
setwd(dir.path)
sim.dir<-"7-1789/"
dir.create(sim.dir, showWarnings = TRUE, recursive = TRUE) 


spec_seed<-7
loc_seed<-1789
fossil_seed<-14

gimme.pop<-function(ras,pop.num,Replace,seed){
  my.randomPoints<-function (mask, n, p, ext = NULL, extf = 1.1, excludep = TRUE, 
                             prob = FALSE, cellnumbers = FALSE, tryf = 3, warn = 2, lonlatCorrection = TRUE,Replace=Replace) 
  {
    if (nlayers(mask) > 1) {
      mask <- raster(mask, 1)
    }
    tryf <- max(round(tryf[1]), 1)
    if (missing(p)) {
      excludep <- FALSE
    }
    else {
      if (inherits(p, "SpatialPoints")) {
        p <- coordinates(p)
      }
    }
    if (class(ext) == "character") {
      if (!ext %in% c("points")) {
        stop("if ext is a character variable it should be 'points'")
      }
      else if (missing(p)) {
        warning("if p is missing, 'ext=points' is meaningless")
        ext <- extent(mask)
      }
      else {
        ext <- extent(min(p[, 1]), max(p[, 1]), min(p[, 2]), 
                      max(p[, 2]))
      }
    }
    if (!is.null(ext)) {
      ext <- extent(ext)
      ext <- ext * extf
      ext <- intersect(ext, extent(mask))
      mask2 <- crop(raster(mask), ext)
    }
    else {
      mask2 <- raster(mask)
    }
    if (n > ncell(mask2)) {
      n <- ncell(mask2)
      if (warn > 0) {
        warning("changed n to ncell of the mask (extent)")
      }
    }
    nn <- n * tryf
    nn <- max(nn, 10)
    if (prob) {
      stopifnot(hasValues(mask))
      cells <- crop(mask, mask2)
      cells <- try(stats::na.omit(cbind(1:ncell(cells), getValues(cells))))
      if (class(cells) == "try-error") {
        stop("the raster is too large to be used with 'prob=TRUE'")
      }
      prob <- cells[, 2]
      cells <- cells[, 1]
      if (couldBeLonLat(mask)) {
        rows <- rowFromCell(mask2, cells)
        y <- yFromRow(mask2, rows)
        dx <- pointDistance(cbind(0, y), cbind(xres(mask2), 
                                               y), longlat = TRUE)
        prob <- prob * dx
      }
      cells <- sample(cells, nn, prob = prob,replace =Replace)
      xy <- xyFromCell(mask2, cells)
      cells <- cellFromXY(mask, xy)
    }
    else if (canProcessInMemory(mask2)) {
      cells <- crop(mask, mask2)
      if (hasValues(cells)) {
        cells <- which(!is.na(getValues(cells)))
      }
      else {
        cells <- 1:ncell(cells)
      }
      nn <- min(length(cells), nn)
      if (lonlatCorrection & couldBeLonLat(mask)) {
        rows <- rowFromCell(mask2, cells)
        y <- yFromRow(mask2, rows)
        dx <- pointDistance(cbind(0, y), cbind(xres(mask2), 
                                               y), longlat = TRUE)
        cells <- sample(cells, nn, prob = dx)
      }
      else {
        cells <- sample(cells, nn)
      }
      xy <- xyFromCell(mask2, cells)
      cells <- cellFromXY(mask, xy)
    }
    else {
      nn <- min(ncell(mask2), nn)
      if (couldBeLonLat(mask2)) {
        cells <- .randomCellsLonLat(mask2, nn)
      }
      else {
        if (nn >= ncell(mask2)) {
          cells <- 1:ncell(mask2)
        }
        else {
          cells <- sampleInt(ncell(mask2), nn)
        }
      }
      xy <- xyFromCell(mask2, cells)
      cells <- cellFromXY(mask, xy)
      if (hasValues(mask)) {
        vals <- cbind(cells, extract(mask, cells))
        cells <- stats::na.omit(vals)[, 1]
      }
    }
    if (excludep) {
      pcells <- cellFromXY(mask, p)
      cells <- cells[!(cells %in% pcells)]
    }
    if (length(cells) > n) {
      cells <- sample(cells, n)
    }
    else if (length(cells) < n) {
      frac <- length(cells)/n
      if (frac < 0.1) {
        stop("generated random points = ", frac, " times requested number; Use a higher value for tryf")
      }
      if (frac < 0.5 & warn == 1) {
        warning("generated random points = ", frac, " times requested number; Use a higher value for tryf")
      }
      else if (warn > 1) {
        warning("generated random points = ", frac, " times requested number")
      }
    }
    if (cellnumbers) {
      return(cells)
    }
    else {
      return(xyFromCell(mask, cells))
    }
  }
  
  
  mask_spec_raster<-ras
  values(mask_spec_raster)[values(mask_spec_raster)<0.01]<-NA
  set.seed(seed)
  pop<-as.data.frame(my.randomPoints(mask_spec_raster,pop.num,prob=TRUE,Replace=Replace))
  
  coordinates(pop)<-~x+y
  crs(pop)<-crs(ras)
  return(pop)
}
ras_area<-sapply(species.raster,function(x)length(x[x>0.01])*prod(res(x)))
ras_area<-data.frame(are_order=1:length(ras_area),area=ras_area)
ras_area<-ras_area[order(ras_area$area),]
set.seed(spec_seed)
pop_num<-sample(2^(rnorm(100,log(1000,2),log(1000,2)/10)),length(species.raster))
pop_num<-sort(pop_num)
data.frame(ras_area,pop_num=pop_num)->spec_eco
spec_eco<-spec_eco[order(spec_eco$are_order),]
pops<-lapply(seq(1:length(species.raster)),function(x)gimme.pop(ras=species.raster[[x]],pop.num=spec_eco[x,"pop_num"],Replace=TRUE,seed=spec_seed))
lapply(pops,function(x){x$age<-rep(1,length(x));
return(x)})->pops
names(pops)<-paste("species",1:length(pops),sep="_")
mapply(function(x,y){x$spec<-rep(y,length(x));
return(x)},pops,names(pops),SIMPLIFY = FALSE)->pops
populations<-do.call(rbind, pops)
populations->prj_populations

extent(lgm_w)[1:2]->x_lim
extent(lgm_w)[3:4]->y_lim
sampling_grid<-expand.grid(x=seq(from=x_lim[1],to=x_lim[2],100000),y=seq(from=y_lim[1],to=y_lim[2],100000))
bioclim_100[[1]]->prediction_ground
coordinates(sampling_grid)<-~x+y
gridded(sampling_grid)<-TRUE
crs(sampling_grid)<-laea_prj
as(sampling_grid,"SpatialPolygons")->sampling_grid

cl <- makeCluster(2, type="SOCK")
registerDoSNOW (cl)
foreach(i=1:length(pops),.packages=c("raster")) %dopar% {
  over(pops[[i]],sampling_grid)->original_over_res
}->original_over_res
stopCluster(cl)
doParallel::stopImplicitCluster()
##


##
lapply(original_over_res,function(x){sampling_grid[unique(x)[!is.na(unique(x))]]->x;
  return(x)})->real_poly
for(i in 1:length(real_poly)) {
  rgeos::gUnaryUnion(real_poly[[i]])->real_poly[[i]]
  print(i)
}
##

sapply(pops,function(x)length(x))->abundance


lapply(pops,function(x)unique(as.character(x$spec)))->pops_names
names(pops)<-pops_names
names(real_poly)<-pops_names
sapply(real_poly,function(x)gArea(x))->areas

#### Simulating spatial accurrences of fossil sites by using the spatial density of actual LGM mammalian fossil localiteis ####
data(lgm)
lgm$spec<-as.character(lgm$spec)
rownames(lgm)<-NULL
lgm[,c("x","y")]->lgm_distr
coordinates(lgm_distr)<-~x+y
proj4string(lgm_distr)<-CRS("+proj=longlat +datum=WGS84")
spTransform(lgm_distr,CRS=crs(species.raster[[1]]))->lgm_distr
lgm_distr<-lgm_distr[-zerodist(lgm_distr)[,2],]
point_dist<-dist(coordinates(lgm_distr),method = "euclidean")
bandw<-median(apply(as.matrix(point_dist),1,function(x)min(x[x!=0])))
est <- bkde2D(coordinates(lgm_distr), 
              bandwidth=c(bandw,bandw), 
              gridsize=c(nrow(species.raster[[1]]),ncol(species.raster[[1]])))
dens_layer = raster(list(x=est$x1,y=est$x2,z=est$fhat))
crs(dens_layer)<-crs(species.raster[[1]])
dens_layer<-projectRaster(from=dens_layer,to=species.raster[[1]]) ;
values(dens_layer)[!is.na(values(dens_layer))]<-scales:: rescale(values(dens_layer)[!is.na(values(dens_layer))],c(0,1))
values(dens_layer)[is.na(values(dens_layer))]<-0
dens_layer[!is.na(dens_layer)]<-scales:: rescale(dens_layer[!is.na(dens_layer)],c(0,1))
dens_layer[is.na(species.raster[[1]]),]<-NA
lapply(pops,function(x)extract(dens_layer,x,cellnumbers=TRUE))->lgm_ID_prob
pops<-mapply(function(x,y) {x$prob<-y[,2];
x$age<-1
return(x)}, pops,lgm_ID_prob,SIMPLIFY=FALSE)

set.seed(loc_seed)
sim_locs<-randomPoints(dens_layer,length(unique(as.character(lgm$loc_id))),prob = TRUE)
sim_locs<-as.data.frame(sim_locs)
coordinates(sim_locs)<-~x+y
crs(sim_locs)<-crs(species.raster[[1]])

#### Extracting species identity by overlapping species polygon geographic ranges by the simulated fossil localities ####
lapply(real_poly,function(x){
  over(x,sim_locs,returnList=TRUE)  
})->over_res

sapply(over_res,function(x)length(x[[1]]))->to_keep
names(which(to_keep>0))->to_keep
over_res[names(over_res)%in%to_keep]->over_res
real_poly[names(real_poly)%in%to_keep]->real_poly
pops[names(pops)%in%to_keep]->pops
populations[populations$spec%in%to_keep,]->populations
areas[names(areas)%in%to_keep]->areas

mapply(function(x,y) {data.frame(x,spec=rep(y,length(x)))->z;
  return(z)},over_res,names(over_res),SIMPLIFY = FALSE)->over_res
over_res<-lapply(over_res,function(x)data.frame(coordinates(sim_locs)[match(x$X1,rownames(coordinates(sim_locs))),],x))
over_res<-do.call(rbind,over_res)
rownames(over_res)<-NULL
over_res<-over_res[order(over_res$X1),]
colnames(over_res)[3]<-"loc_id"
coordinates(over_res)<-~x+y
crs(over_res)<-crs(species.raster[[1]])
over_res->lgm_sim_dat
spTransform(lgm_sim_dat,CRS=CRS("+proj=longlat +datum=WGS84"))->lgm_sim_dat
lgm_sim_dat<-as.data.frame(lgm_sim_dat)
as.character(lgm_sim_dat$spec)->lgm_sim_dat$spec
species_names<-unique(lgm_sim_dat$spec)


#### Simulating a nagative relationship between fossilization bias and species geographic ranges #### 
taf_bias<-seq(from=0.5,to=0.8,length.out = length(species_names))
data.frame(sort(areas),sort(taf_bias,decreasing=TRUE))->taf_data
set.seed(fossil_seed)
red_lgm_sim_dat<-lapply(1:nrow(taf_data),function(z){
  lgm_sim_dat[which(lgm_sim_dat$spec==rownames(taf_data)[z]),]->lgm_spec
  rownames(lgm_spec)<-NULL
  to_rem<-round(taf_data[z,2]*nrow(lgm_spec))
  lgm_spec[-as.numeric(sample(rownames(lgm_spec),to_rem)),]->lgm_spec;
  rownames(lgm_spec)<-NULL
  return(lgm_spec)
})
do.call(rbind,red_lgm_sim_dat)->red_lgm_sim_dat

red_lgm_sim_dat$age<-1
#### LGM simulation end ####


#### Performing MInOSSE ####
Sys.getenv("R_MAX_NUM_DLLs", unset = 1000)
unique(as.character(red_lgm_sim_dat$spec))->spec_list

minosse_dat<-list()
minosse_res_list<-list()
for(i in 1:length(spec_list)){
  if(class(try(minosse_dat[[i]]<-minosse.data(
    obj=red_lgm_sim_dat,
    species_name=spec_list[i],
    domain="land",
    coc.by="locality",
    min.occs=3,
    abiotic.covs=NULL,
    combine.covs=FALSE,   
    reduce_covs_by="pca",
    covs_th=0.95,
    c.size=300000,
    bkg.predictors="presence", 
    min.bkg=100,
    sampling.by.distance=TRUE,
    prediction.ground=prediction_ground,
    crop.by.mcp=FALSE,
    projection="laea",
    lon_0=85,
    lat_0=45,
    n.clusters=clus_num, 
    seed=625)
  ))=="try-error") {next} else {minosse_dat[[i]]<-minosse_dat[[i]];
  
  
  if(class(try(minosse_res_list[[i]]<-minosse.target(
    resp=minosse_dat[[i]][[1]],
    predictors=minosse_dat[[i]][[2]],
    bkg="presence",
    min.bkg = 100,
    n.sims=10,
    sampling.by.distance=TRUE,
    n.folds=n.folds,
    n.sims.clusters=clus_num,
    seed=625)))=="try-error") {next} else minosse_res_list[[i]]<-minosse_res_list[[i]] 
  }
  print(i)
}
gc()


#### Saving results ####

save.image(paste(paste(dir.path,sim.dir,sep=""),"LGM_14_7_1789_coc_loc_300km.RData",sep=""))
gc()





#### LGM 1861 coc by locality ####

rm(list=ls(all=TRUE)[-which(ls(all=TRUE)%in%c("dir.path","appendices_folder","n.folds","dir.path_no_coc","my.path","clus_num","species.raster","configs_100","lgm_w","lgm","bioclim_100","lgm_distr","dens_layer","laea_prj"))])
setwd(dir.path)
sim.dir<-"3-1861/"
dir.create(sim.dir, showWarnings = TRUE, recursive = TRUE) 

spec_seed<-3
loc_seed<-1861
fossil_seed<-17

gimme.pop<-function(ras,pop.num,Replace,seed){
  #ras=species.raster[[2]];pop.num=1000 
  my.randomPoints<-function (mask, n, p, ext = NULL, extf = 1.1, excludep = TRUE, 
                             prob = FALSE, cellnumbers = FALSE, tryf = 3, warn = 2, lonlatCorrection = TRUE,Replace=Replace) 
  {
    if (nlayers(mask) > 1) {
      mask <- raster(mask, 1)
    }
    tryf <- max(round(tryf[1]), 1)
    if (missing(p)) {
      excludep <- FALSE
    }
    else {
      if (inherits(p, "SpatialPoints")) {
        p <- coordinates(p)
      }
    }
    if (class(ext) == "character") {
      if (!ext %in% c("points")) {
        stop("if ext is a character variable it should be 'points'")
      }
      else if (missing(p)) {
        warning("if p is missing, 'ext=points' is meaningless")
        ext <- extent(mask)
      }
      else {
        ext <- extent(min(p[, 1]), max(p[, 1]), min(p[, 2]), 
                      max(p[, 2]))
      }
    }
    if (!is.null(ext)) {
      ext <- extent(ext)
      ext <- ext * extf
      ext <- intersect(ext, extent(mask))
      mask2 <- crop(raster(mask), ext)
    }
    else {
      mask2 <- raster(mask)
    }
    if (n > ncell(mask2)) {
      n <- ncell(mask2)
      if (warn > 0) {
        warning("changed n to ncell of the mask (extent)")
      }
    }
    nn <- n * tryf
    nn <- max(nn, 10)
    if (prob) {
      stopifnot(hasValues(mask))
      cells <- crop(mask, mask2)
      cells <- try(stats::na.omit(cbind(1:ncell(cells), getValues(cells))))
      if (class(cells) == "try-error") {
        stop("the raster is too large to be used with 'prob=TRUE'")
      }
      prob <- cells[, 2]
      cells <- cells[, 1]
      if (couldBeLonLat(mask)) {
        rows <- rowFromCell(mask2, cells)
        y <- yFromRow(mask2, rows)
        dx <- pointDistance(cbind(0, y), cbind(xres(mask2), 
                                               y), longlat = TRUE)
        prob <- prob * dx
      }
      cells <- sample(cells, nn, prob = prob,replace =Replace)
      xy <- xyFromCell(mask2, cells)
      cells <- cellFromXY(mask, xy)
    }
    else if (canProcessInMemory(mask2)) {
      cells <- crop(mask, mask2)
      if (hasValues(cells)) {
        cells <- which(!is.na(getValues(cells)))
      }
      else {
        cells <- 1:ncell(cells)
      }
      nn <- min(length(cells), nn)
      if (lonlatCorrection & couldBeLonLat(mask)) {
        rows <- rowFromCell(mask2, cells)
        y <- yFromRow(mask2, rows)
        dx <- pointDistance(cbind(0, y), cbind(xres(mask2), 
                                               y), longlat = TRUE)
        cells <- sample(cells, nn, prob = dx)
      }
      else {
        cells <- sample(cells, nn)
      }
      xy <- xyFromCell(mask2, cells)
      cells <- cellFromXY(mask, xy)
    }
    else {
      nn <- min(ncell(mask2), nn)
      if (couldBeLonLat(mask2)) {
        cells <- .randomCellsLonLat(mask2, nn)
      }
      else {
        if (nn >= ncell(mask2)) {
          cells <- 1:ncell(mask2)
        }
        else {
          cells <- sampleInt(ncell(mask2), nn)
        }
      }
      xy <- xyFromCell(mask2, cells)
      cells <- cellFromXY(mask, xy)
      if (hasValues(mask)) {
        vals <- cbind(cells, extract(mask, cells))
        cells <- stats::na.omit(vals)[, 1]
      }
    }
    if (excludep) {
      pcells <- cellFromXY(mask, p)
      cells <- cells[!(cells %in% pcells)]
    }
    if (length(cells) > n) {
      cells <- sample(cells, n)
    }
    else if (length(cells) < n) {
      frac <- length(cells)/n
      if (frac < 0.1) {
        stop("generated random points = ", frac, " times requested number; Use a higher value for tryf")
      }
      if (frac < 0.5 & warn == 1) {
        warning("generated random points = ", frac, " times requested number; Use a higher value for tryf")
      }
      else if (warn > 1) {
        warning("generated random points = ", frac, " times requested number")
      }
    }
    if (cellnumbers) {
      return(cells)
    }
    else {
      return(xyFromCell(mask, cells))
    }
  }
  
  
  mask_spec_raster<-ras
  values(mask_spec_raster)[values(mask_spec_raster)<0.01]<-NA
  set.seed(seed)
  pop<-as.data.frame(my.randomPoints(mask_spec_raster,pop.num,prob=TRUE,Replace=Replace))
  
  coordinates(pop)<-~x+y
  crs(pop)<-crs(ras)
  return(pop)
}
ras_area<-sapply(species.raster,function(x)length(x[x>0.01])*prod(res(x)))
ras_area<-data.frame(are_order=1:length(ras_area),area=ras_area)
ras_area<-ras_area[order(ras_area$area),]
set.seed(spec_seed)
pop_num<-sample(2^(rnorm(100,log(1000,2),log(1000,2)/10)),length(species.raster))
pop_num<-sort(pop_num)
data.frame(ras_area,pop_num=pop_num)->spec_eco
spec_eco<-spec_eco[order(spec_eco$are_order),]
pops<-lapply(seq(1:length(species.raster)),function(x)gimme.pop(ras=species.raster[[x]],pop.num=spec_eco[x,"pop_num"],Replace=TRUE,seed=spec_seed))
lapply(pops,function(x){x$age<-rep(1,length(x));
return(x)})->pops
names(pops)<-paste("species",1:length(pops),sep="_")
mapply(function(x,y){x$spec<-rep(y,length(x));
return(x)},pops,names(pops),SIMPLIFY = FALSE)->pops
populations<-do.call(rbind, pops)
populations->prj_populations
extent(lgm_w)[1:2]->x_lim
extent(lgm_w)[3:4]->y_lim

sampling_grid<-expand.grid(x=seq(from=x_lim[1],to=x_lim[2],100000),y=seq(from=y_lim[1],to=y_lim[2],100000))
bioclim_100[[1]]->prediction_ground
coordinates(sampling_grid)<-~x+y
gridded(sampling_grid)<-TRUE
crs(sampling_grid)<-laea_prj
as(sampling_grid,"SpatialPolygons")->sampling_grid

cl <- makeCluster(2, type="SOCK")
registerDoSNOW (cl)
foreach(i=1:length(pops),.packages=c("raster")) %dopar% {
  over(pops[[i]],sampling_grid)->original_over_res
}->original_over_res
stopCluster(cl)
doParallel::stopImplicitCluster()
##
lapply(original_over_res,function(x){sampling_grid[unique(x)[!is.na(unique(x))]]->x;
  return(x)})->real_poly
for(i in 1:length(real_poly)) {
  rgeos::gUnaryUnion(real_poly[[i]])->real_poly[[i]]
  print(i)
}
##

sapply(pops,function(x)length(x))->abundance


lapply(pops,function(x)unique(as.character(x$spec)))->pops_names
names(pops)<-pops_names
names(real_poly)<-pops_names
sapply(real_poly,function(x)gArea(x))->areas

#### Simulating spatial accurrences of fossil sites by using the spatial density of actual LGM mammalian fossil localiteis ####
data(lgm)
lgm$spec<-as.character(lgm$spec)
rownames(lgm)<-NULL
lgm[,c("x","y")]->lgm_distr
coordinates(lgm_distr)<-~x+y
proj4string(lgm_distr)<-CRS("+proj=longlat +datum=WGS84")
spTransform(lgm_distr,CRS=crs(species.raster[[1]]))->lgm_distr
lgm_distr<-lgm_distr[-zerodist(lgm_distr)[,2],]
point_dist<-dist(coordinates(lgm_distr),method = "euclidean")
bandw<-median(apply(as.matrix(point_dist),1,function(x)min(x[x!=0])))
est <- bkde2D(coordinates(lgm_distr), 
              bandwidth=c(bandw,bandw), 
              gridsize=c(nrow(species.raster[[1]]),ncol(species.raster[[1]])))
dens_layer = raster(list(x=est$x1,y=est$x2,z=est$fhat))
crs(dens_layer)<-crs(species.raster[[1]])
dens_layer<-projectRaster(from=dens_layer,to=species.raster[[1]]) ;
values(dens_layer)[!is.na(values(dens_layer))]<-scales:: rescale(values(dens_layer)[!is.na(values(dens_layer))],c(0,1))
values(dens_layer)[is.na(values(dens_layer))]<-0
dens_layer[!is.na(dens_layer)]<-scales:: rescale(dens_layer[!is.na(dens_layer)],c(0,1))
dens_layer[is.na(species.raster[[1]]),]<-NA
lapply(pops,function(x)extract(dens_layer,x,cellnumbers=TRUE))->lgm_ID_prob
pops<-mapply(function(x,y) {x$prob<-y[,2];
x$age<-1
return(x)}, pops,lgm_ID_prob,SIMPLIFY=FALSE)

set.seed(loc_seed)
sim_locs<-randomPoints(dens_layer,length(unique(as.character(lgm$loc_id))),prob = TRUE)
sim_locs<-as.data.frame(sim_locs)
coordinates(sim_locs)<-~x+y
crs(sim_locs)<-crs(species.raster[[1]])

#### Extracting species identity by overlapping species polygon geographic ranges by the simulated fossil localities ####
lapply(real_poly,function(x){
  over(x,sim_locs,returnList=TRUE)  
})->over_res

sapply(over_res,function(x)length(x[[1]]))->to_keep
names(which(to_keep>0))->to_keep
over_res[names(over_res)%in%to_keep]->over_res
real_poly[names(real_poly)%in%to_keep]->real_poly
pops[names(pops)%in%to_keep]->pops
populations[populations$spec%in%to_keep,]->populations
areas[names(areas)%in%to_keep]->areas

mapply(function(x,y) {data.frame(x,spec=rep(y,length(x)))->z;
  return(z)},over_res,names(over_res),SIMPLIFY = FALSE)->over_res
over_res<-lapply(over_res,function(x)data.frame(coordinates(sim_locs)[match(x$X1,rownames(coordinates(sim_locs))),],x))
over_res<-do.call(rbind,over_res)
rownames(over_res)<-NULL
over_res<-over_res[order(over_res$X1),]
colnames(over_res)[3]<-"loc_id"
coordinates(over_res)<-~x+y
crs(over_res)<-crs(species.raster[[1]])
over_res->lgm_sim_dat
spTransform(lgm_sim_dat,CRS=CRS("+proj=longlat +datum=WGS84"))->lgm_sim_dat
lgm_sim_dat<-as.data.frame(lgm_sim_dat)
as.character(lgm_sim_dat$spec)->lgm_sim_dat$spec
species_names<-unique(lgm_sim_dat$spec)


#### Simulating a nagative relationship between fossilization bias and species geographic ranges #### 
taf_bias<-seq(from=0.5,to=0.8,length.out = length(species_names))
data.frame(sort(areas),sort(taf_bias,decreasing=TRUE))->taf_data
set.seed(fossil_seed)
red_lgm_sim_dat<-lapply(1:nrow(taf_data),function(z){
  lgm_sim_dat[which(lgm_sim_dat$spec==rownames(taf_data)[z]),]->lgm_spec
  rownames(lgm_spec)<-NULL
  to_rem<-round(taf_data[z,2]*nrow(lgm_spec))
  lgm_spec[-as.numeric(sample(rownames(lgm_spec),to_rem)),]->lgm_spec;
  rownames(lgm_spec)<-NULL
  return(lgm_spec)
})
do.call(rbind,red_lgm_sim_dat)->red_lgm_sim_dat

red_lgm_sim_dat$age<-1
#### LGM simulation end ####

#### Performing MInOSSE ####
Sys.getenv("R_MAX_NUM_DLLs", unset = 1000)
unique(as.character(red_lgm_sim_dat$spec))->spec_list

minosse_dat<-list()
minosse_res_list<-list()
for(i in 1:length(spec_list)){
  if(class(try(minosse_dat[[i]]<-minosse.data(
    obj=red_lgm_sim_dat,
    species_name=spec_list[i],
    domain="land",
    coc.by="locality",
    min.occs=3,
    abiotic.covs=NULL,
    combine.covs=FALSE,   
    reduce_covs_by="pca",
    covs_th=0.95,
    c.size=300000,
    bkg.predictors="presence", 
    min.bkg=100,
    sampling.by.distance=TRUE,
    prediction.ground=prediction_ground,
    crop.by.mcp=FALSE,
    projection="laea",
    lon_0=85,
    lat_0=45,
    n.clusters=clus_num, 
    seed=625)
  ))=="try-error") {next} else {minosse_dat[[i]]<-minosse_dat[[i]];
  
  
  if(class(try(minosse_res_list[[i]]<-minosse.target(
    resp=minosse_dat[[i]][[1]],
    predictors=minosse_dat[[i]][[2]],
    bkg="presence",
    min.bkg = 100,
    n.sims=10,
    sampling.by.distance=TRUE,
    n.folds=n.folds,
    n.sims.clusters=clus_num,
    seed=625)))=="try-error") {next} else minosse_res_list[[i]]<-minosse_res_list[[i]] 
  }
  print(i)
}
gc()

#### Saving results ####
save.image(paste(paste(dir.path,sim.dir,sep=""),"LGM_17_3_1861_coc_loc_300km.RData",sep=""))
gc()



#### LGM 2004 coc by locality ####

rm(list=ls(all=TRUE)[-which(ls(all=TRUE)%in%c("dir.path","appendices_folder","n.folds","dir.path_no_coc","my.path","clus_num","species.raster","configs_100","lgm_w","lgm","bioclim_100","lgm_distr","dens_layer","laea_prj"))])
setwd(dir.path)
sim.dir<-"4-2004/"
dir.create(sim.dir, showWarnings = TRUE, recursive = TRUE) 

spec_seed<-4
loc_seed<-2004
fossil_seed<-19

gimme.pop<-function(ras,pop.num,Replace,seed){
  my.randomPoints<-function (mask, n, p, ext = NULL, extf = 1.1, excludep = TRUE, 
                             prob = FALSE, cellnumbers = FALSE, tryf = 3, warn = 2, lonlatCorrection = TRUE,Replace=Replace) 
  {
    if (nlayers(mask) > 1) {
      mask <- raster(mask, 1)
    }
    tryf <- max(round(tryf[1]), 1)
    if (missing(p)) {
      excludep <- FALSE
    }
    else {
      if (inherits(p, "SpatialPoints")) {
        p <- coordinates(p)
      }
    }
    if (class(ext) == "character") {
      if (!ext %in% c("points")) {
        stop("if ext is a character variable it should be 'points'")
      }
      else if (missing(p)) {
        warning("if p is missing, 'ext=points' is meaningless")
        ext <- extent(mask)
      }
      else {
        ext <- extent(min(p[, 1]), max(p[, 1]), min(p[, 2]), 
                      max(p[, 2]))
      }
    }
    if (!is.null(ext)) {
      ext <- extent(ext)
      ext <- ext * extf
      ext <- intersect(ext, extent(mask))
      mask2 <- crop(raster(mask), ext)
    }
    else {
      mask2 <- raster(mask)
    }
    if (n > ncell(mask2)) {
      n <- ncell(mask2)
      if (warn > 0) {
        warning("changed n to ncell of the mask (extent)")
      }
    }
    nn <- n * tryf
    nn <- max(nn, 10)
    if (prob) {
      stopifnot(hasValues(mask))
      cells <- crop(mask, mask2)
      cells <- try(stats::na.omit(cbind(1:ncell(cells), getValues(cells))))
      if (class(cells) == "try-error") {
        stop("the raster is too large to be used with 'prob=TRUE'")
      }
      prob <- cells[, 2]
      cells <- cells[, 1]
      if (couldBeLonLat(mask)) {
        rows <- rowFromCell(mask2, cells)
        y <- yFromRow(mask2, rows)
        dx <- pointDistance(cbind(0, y), cbind(xres(mask2), 
                                               y), longlat = TRUE)
        prob <- prob * dx
      }
      cells <- sample(cells, nn, prob = prob,replace =Replace)
      xy <- xyFromCell(mask2, cells)
      cells <- cellFromXY(mask, xy)
    }
    else if (canProcessInMemory(mask2)) {
      cells <- crop(mask, mask2)
      if (hasValues(cells)) {
        cells <- which(!is.na(getValues(cells)))
      }
      else {
        cells <- 1:ncell(cells)
      }
      nn <- min(length(cells), nn)
      if (lonlatCorrection & couldBeLonLat(mask)) {
        rows <- rowFromCell(mask2, cells)
        y <- yFromRow(mask2, rows)
        dx <- pointDistance(cbind(0, y), cbind(xres(mask2), 
                                               y), longlat = TRUE)
        cells <- sample(cells, nn, prob = dx)
      }
      else {
        cells <- sample(cells, nn)
      }
      xy <- xyFromCell(mask2, cells)
      cells <- cellFromXY(mask, xy)
    }
    else {
      nn <- min(ncell(mask2), nn)
      if (couldBeLonLat(mask2)) {
        cells <- .randomCellsLonLat(mask2, nn)
      }
      else {
        if (nn >= ncell(mask2)) {
          cells <- 1:ncell(mask2)
        }
        else {
          cells <- sampleInt(ncell(mask2), nn)
        }
      }
      xy <- xyFromCell(mask2, cells)
      cells <- cellFromXY(mask, xy)
      if (hasValues(mask)) {
        vals <- cbind(cells, extract(mask, cells))
        cells <- stats::na.omit(vals)[, 1]
      }
    }
    if (excludep) {
      pcells <- cellFromXY(mask, p)
      cells <- cells[!(cells %in% pcells)]
    }
    if (length(cells) > n) {
      cells <- sample(cells, n)
    }
    else if (length(cells) < n) {
      frac <- length(cells)/n
      if (frac < 0.1) {
        stop("generated random points = ", frac, " times requested number; Use a higher value for tryf")
      }
      if (frac < 0.5 & warn == 1) {
        warning("generated random points = ", frac, " times requested number; Use a higher value for tryf")
      }
      else if (warn > 1) {
        warning("generated random points = ", frac, " times requested number")
      }
    }
    if (cellnumbers) {
      return(cells)
    }
    else {
      return(xyFromCell(mask, cells))
    }
  }
  
  
  mask_spec_raster<-ras
  values(mask_spec_raster)[values(mask_spec_raster)<0.01]<-NA
  set.seed(seed)
  pop<-as.data.frame(my.randomPoints(mask_spec_raster,pop.num,prob=TRUE,Replace=Replace))
  
  coordinates(pop)<-~x+y
  crs(pop)<-crs(ras)
  return(pop)
}
ras_area<-sapply(species.raster,function(x)length(x[x>0.01])*prod(res(x)))
ras_area<-data.frame(are_order=1:length(ras_area),area=ras_area)
ras_area<-ras_area[order(ras_area$area),]
set.seed(spec_seed)
pop_num<-sample(2^(rnorm(100,log(1000,2),log(1000,2)/10)),length(species.raster))
pop_num<-sort(pop_num)
data.frame(ras_area,pop_num=pop_num)->spec_eco
spec_eco<-spec_eco[order(spec_eco$are_order),]
pops<-lapply(seq(1:length(species.raster)),function(x)gimme.pop(ras=species.raster[[x]],pop.num=spec_eco[x,"pop_num"],Replace=TRUE,seed=spec_seed))
lapply(pops,function(x){x$age<-rep(1,length(x));
return(x)})->pops
names(pops)<-paste("species",1:length(pops),sep="_")
mapply(function(x,y){x$spec<-rep(y,length(x));
return(x)},pops,names(pops),SIMPLIFY = FALSE)->pops
populations<-do.call(rbind, pops)
populations->prj_populations
extent(lgm_w)[1:2]->x_lim
extent(lgm_w)[3:4]->y_lim

sampling_grid<-expand.grid(x=seq(from=x_lim[1],to=x_lim[2],100000),y=seq(from=y_lim[1],to=y_lim[2],100000))
bioclim_100[[1]]->prediction_ground
coordinates(sampling_grid)<-~x+y
gridded(sampling_grid)<-TRUE
crs(sampling_grid)<-laea_prj
as(sampling_grid,"SpatialPolygons")->sampling_grid

cl <- makeCluster(2, type="SOCK")
registerDoSNOW (cl)
foreach(i=1:length(pops),.packages=c("raster")) %dopar% {
  over(pops[[i]],sampling_grid)->original_over_res
}->original_over_res
stopCluster(cl)
doParallel::stopImplicitCluster()
##

lapply(original_over_res,function(x){sampling_grid[unique(x)[!is.na(unique(x))]]->x;
  return(x)})->real_poly
for(i in 1:length(real_poly)) {
  rgeos::gUnaryUnion(real_poly[[i]])->real_poly[[i]]
  print(i)
}

sapply(pops,function(x)length(x))->abundance


lapply(pops,function(x)unique(as.character(x$spec)))->pops_names
names(pops)<-pops_names
names(real_poly)<-pops_names
sapply(real_poly,function(x)gArea(x))->areas

#### Simulating spatial accurrences of fossil sites by using the spatial density of actual LGM mammalian fossil localiteis ####
data(lgm)
lgm$spec<-as.character(lgm$spec)
rownames(lgm)<-NULL
lgm[,c("x","y")]->lgm_distr
coordinates(lgm_distr)<-~x+y
proj4string(lgm_distr)<-CRS("+proj=longlat +datum=WGS84")
spTransform(lgm_distr,CRS=crs(species.raster[[1]]))->lgm_distr
lgm_distr<-lgm_distr[-zerodist(lgm_distr)[,2],]
point_dist<-dist(coordinates(lgm_distr),method = "euclidean")
bandw<-median(apply(as.matrix(point_dist),1,function(x)min(x[x!=0])))
est <- bkde2D(coordinates(lgm_distr), 
              bandwidth=c(bandw,bandw), 
              gridsize=c(nrow(species.raster[[1]]),ncol(species.raster[[1]])))
dens_layer = raster(list(x=est$x1,y=est$x2,z=est$fhat))
crs(dens_layer)<-crs(species.raster[[1]])
dens_layer<-projectRaster(from=dens_layer,to=species.raster[[1]]) ;
values(dens_layer)[!is.na(values(dens_layer))]<-scales:: rescale(values(dens_layer)[!is.na(values(dens_layer))],c(0,1))
values(dens_layer)[is.na(values(dens_layer))]<-0
dens_layer[!is.na(dens_layer)]<-scales:: rescale(dens_layer[!is.na(dens_layer)],c(0,1))
dens_layer[is.na(species.raster[[1]]),]<-NA
lapply(pops,function(x)extract(dens_layer,x,cellnumbers=TRUE))->lgm_ID_prob
pops<-mapply(function(x,y) {x$prob<-y[,2];
x$age<-1
return(x)}, pops,lgm_ID_prob,SIMPLIFY=FALSE)

set.seed(loc_seed)
sim_locs<-randomPoints(dens_layer,length(unique(as.character(lgm$loc_id))),prob = TRUE)
sim_locs<-as.data.frame(sim_locs)
coordinates(sim_locs)<-~x+y
crs(sim_locs)<-crs(species.raster[[1]])

#### Extracting species identity by overlapping species polygon geographic ranges by the simulated fossil localities ####
lapply(real_poly,function(x){
  over(x,sim_locs,returnList=TRUE)  
})->over_res

sapply(over_res,function(x)length(x[[1]]))->to_keep
names(which(to_keep>0))->to_keep
over_res[names(over_res)%in%to_keep]->over_res
real_poly[names(real_poly)%in%to_keep]->real_poly
pops[names(pops)%in%to_keep]->pops
populations[populations$spec%in%to_keep,]->populations
areas[names(areas)%in%to_keep]->areas

mapply(function(x,y) {data.frame(x,spec=rep(y,length(x)))->z;
  return(z)},over_res,names(over_res),SIMPLIFY = FALSE)->over_res
over_res<-lapply(over_res,function(x)data.frame(coordinates(sim_locs)[match(x$X1,rownames(coordinates(sim_locs))),],x))
over_res<-do.call(rbind,over_res)
rownames(over_res)<-NULL
over_res<-over_res[order(over_res$X1),]
colnames(over_res)[3]<-"loc_id"
coordinates(over_res)<-~x+y
crs(over_res)<-crs(species.raster[[1]])
over_res->lgm_sim_dat
spTransform(lgm_sim_dat,CRS=CRS("+proj=longlat +datum=WGS84"))->lgm_sim_dat
lgm_sim_dat<-as.data.frame(lgm_sim_dat)
as.character(lgm_sim_dat$spec)->lgm_sim_dat$spec
species_names<-unique(lgm_sim_dat$spec)


#### Simulating a nagative relationship between fossilization bias and species geographic ranges #### 
taf_bias<-seq(from=0.5,to=0.8,length.out = length(species_names))
data.frame(sort(areas),sort(taf_bias,decreasing=TRUE))->taf_data
set.seed(fossil_seed)
red_lgm_sim_dat<-lapply(1:nrow(taf_data),function(z){
  lgm_sim_dat[which(lgm_sim_dat$spec==rownames(taf_data)[z]),]->lgm_spec
  rownames(lgm_spec)<-NULL
  to_rem<-round(taf_data[z,2]*nrow(lgm_spec))
  lgm_spec[-as.numeric(sample(rownames(lgm_spec),to_rem)),]->lgm_spec;
  rownames(lgm_spec)<-NULL
  return(lgm_spec)
})
do.call(rbind,red_lgm_sim_dat)->red_lgm_sim_dat

red_lgm_sim_dat$age<-1
#### LGM simulation end ####



#### Performing MInOSSE ####
Sys.getenv("R_MAX_NUM_DLLs", unset = 1000)
unique(as.character(red_lgm_sim_dat$spec))->spec_list

minosse_dat<-list()
minosse_res_list<-list()
for(i in 1:length(spec_list)){
  if(class(try(minosse_dat[[i]]<-minosse.data(
    obj=red_lgm_sim_dat,
    species_name=spec_list[i],
    domain="land",
    coc.by="locality",
    min.occs=3,
    abiotic.covs=NULL,
    combine.covs=FALSE,   
    reduce_covs_by="pca",
    covs_th=0.95,
    c.size=300000,
    bkg.predictors="presence", 
    min.bkg=100,
    sampling.by.distance=TRUE,
    prediction.ground=prediction_ground,
    crop.by.mcp=FALSE,
    projection="laea",
    lon_0=85,
    lat_0=45,
    n.clusters=clus_num, 
    seed=625)
  ))=="try-error") {next} else {minosse_dat[[i]]<-minosse_dat[[i]];
  
  
  if(class(try(minosse_res_list[[i]]<-minosse.target(
    resp=minosse_dat[[i]][[1]],
    predictors=minosse_dat[[i]][[2]],
    bkg="presence",
    min.bkg = 100,
    n.sims=10,
    sampling.by.distance=TRUE,
    n.folds=n.folds,
    n.sims.clusters=clus_num,
    seed=625)))=="try-error") {next} else minosse_res_list[[i]]<-minosse_res_list[[i]] 
  }
  print(i)
}
gc()

#### Saving results ####
save.image(paste(paste(dir.path,sim.dir,sep=""),"LGM_19_4_2004_coc_loc_300km.RData",sep=""))
gc()





#### LGM 2015 coc by locality ####

rm(list=ls(all=TRUE)[-which(ls(all=TRUE)%in%c("dir.path","appendices_folder","n.folds","dir.path_no_coc","my.path","clus_num","species.raster","configs_100","lgm_w","lgm","bioclim_100","lgm_distr","dens_layer","laea_prj"))])
setwd(dir.path)
sim.dir<-"1979-2015/"
dir.create(sim.dir, showWarnings = TRUE, recursive = TRUE) 

spec_seed<-1979
loc_seed<-2015
fossil_seed<-10

gimme.pop<-function(ras,pop.num,Replace,seed){
  #ras=species.raster[[2]];pop.num=1000 
  my.randomPoints<-function (mask, n, p, ext = NULL, extf = 1.1, excludep = TRUE, 
                             prob = FALSE, cellnumbers = FALSE, tryf = 3, warn = 2, lonlatCorrection = TRUE,Replace=Replace) 
  {
    if (nlayers(mask) > 1) {
      mask <- raster(mask, 1)
    }
    tryf <- max(round(tryf[1]), 1)
    if (missing(p)) {
      excludep <- FALSE
    }
    else {
      if (inherits(p, "SpatialPoints")) {
        p <- coordinates(p)
      }
    }
    if (class(ext) == "character") {
      if (!ext %in% c("points")) {
        stop("if ext is a character variable it should be 'points'")
      }
      else if (missing(p)) {
        warning("if p is missing, 'ext=points' is meaningless")
        ext <- extent(mask)
      }
      else {
        ext <- extent(min(p[, 1]), max(p[, 1]), min(p[, 2]), 
                      max(p[, 2]))
      }
    }
    if (!is.null(ext)) {
      ext <- extent(ext)
      ext <- ext * extf
      ext <- intersect(ext, extent(mask))
      mask2 <- crop(raster(mask), ext)
    }
    else {
      mask2 <- raster(mask)
    }
    if (n > ncell(mask2)) {
      n <- ncell(mask2)
      if (warn > 0) {
        warning("changed n to ncell of the mask (extent)")
      }
    }
    nn <- n * tryf
    nn <- max(nn, 10)
    if (prob) {
      stopifnot(hasValues(mask))
      cells <- crop(mask, mask2)
      cells <- try(stats::na.omit(cbind(1:ncell(cells), getValues(cells))))
      if (class(cells) == "try-error") {
        stop("the raster is too large to be used with 'prob=TRUE'")
      }
      prob <- cells[, 2]
      cells <- cells[, 1]
      if (couldBeLonLat(mask)) {
        rows <- rowFromCell(mask2, cells)
        y <- yFromRow(mask2, rows)
        dx <- pointDistance(cbind(0, y), cbind(xres(mask2), 
                                               y), longlat = TRUE)
        prob <- prob * dx
      }
      cells <- sample(cells, nn, prob = prob,replace =Replace)
      xy <- xyFromCell(mask2, cells)
      cells <- cellFromXY(mask, xy)
    }
    else if (canProcessInMemory(mask2)) {
      cells <- crop(mask, mask2)
      if (hasValues(cells)) {
        cells <- which(!is.na(getValues(cells)))
      }
      else {
        cells <- 1:ncell(cells)
      }
      nn <- min(length(cells), nn)
      if (lonlatCorrection & couldBeLonLat(mask)) {
        rows <- rowFromCell(mask2, cells)
        y <- yFromRow(mask2, rows)
        dx <- pointDistance(cbind(0, y), cbind(xres(mask2), 
                                               y), longlat = TRUE)
        cells <- sample(cells, nn, prob = dx)
      }
      else {
        cells <- sample(cells, nn)
      }
      xy <- xyFromCell(mask2, cells)
      cells <- cellFromXY(mask, xy)
    }
    else {
      nn <- min(ncell(mask2), nn)
      if (couldBeLonLat(mask2)) {
        cells <- .randomCellsLonLat(mask2, nn)
      }
      else {
        if (nn >= ncell(mask2)) {
          cells <- 1:ncell(mask2)
        }
        else {
          cells <- sampleInt(ncell(mask2), nn)
        }
      }
      xy <- xyFromCell(mask2, cells)
      cells <- cellFromXY(mask, xy)
      if (hasValues(mask)) {
        vals <- cbind(cells, extract(mask, cells))
        cells <- stats::na.omit(vals)[, 1]
      }
    }
    if (excludep) {
      pcells <- cellFromXY(mask, p)
      cells <- cells[!(cells %in% pcells)]
    }
    if (length(cells) > n) {
      cells <- sample(cells, n)
    }
    else if (length(cells) < n) {
      frac <- length(cells)/n
      if (frac < 0.1) {
        stop("generated random points = ", frac, " times requested number; Use a higher value for tryf")
      }
      if (frac < 0.5 & warn == 1) {
        warning("generated random points = ", frac, " times requested number; Use a higher value for tryf")
      }
      else if (warn > 1) {
        warning("generated random points = ", frac, " times requested number")
      }
    }
    if (cellnumbers) {
      return(cells)
    }
    else {
      return(xyFromCell(mask, cells))
    }
  }
  
  
  mask_spec_raster<-ras
  values(mask_spec_raster)[values(mask_spec_raster)<0.01]<-NA
  set.seed(seed)
  pop<-as.data.frame(my.randomPoints(mask_spec_raster,pop.num,prob=TRUE,Replace=Replace))
  
  coordinates(pop)<-~x+y
  crs(pop)<-crs(ras)
  return(pop)
}
ras_area<-sapply(species.raster,function(x)length(x[x>0.01])*prod(res(x)))
ras_area<-data.frame(are_order=1:length(ras_area),area=ras_area)
ras_area<-ras_area[order(ras_area$area),]
set.seed(spec_seed)
pop_num<-sample(2^(rnorm(100,log(1000,2),log(1000,2)/10)),length(species.raster))
pop_num<-sort(pop_num)
data.frame(ras_area,pop_num=pop_num)->spec_eco
spec_eco<-spec_eco[order(spec_eco$are_order),]
pops<-lapply(seq(1:length(species.raster)),function(x)gimme.pop(ras=species.raster[[x]],pop.num=spec_eco[x,"pop_num"],Replace=TRUE,seed=spec_seed))
lapply(pops,function(x){x$age<-rep(1,length(x));
return(x)})->pops
names(pops)<-paste("species",1:length(pops),sep="_")
mapply(function(x,y){x$spec<-rep(y,length(x));
return(x)},pops,names(pops),SIMPLIFY = FALSE)->pops
populations<-do.call(rbind, pops)
populations->prj_populations

extent(lgm_w)[1:2]->x_lim
extent(lgm_w)[3:4]->y_lim
sampling_grid<-expand.grid(x=seq(from=x_lim[1],to=x_lim[2],100000),y=seq(from=y_lim[1],to=y_lim[2],100000))
bioclim_100[[1]]->prediction_ground
coordinates(sampling_grid)<-~x+y
gridded(sampling_grid)<-TRUE
crs(sampling_grid)<-laea_prj
as(sampling_grid,"SpatialPolygons")->sampling_grid

cl <- makeCluster(2, type="SOCK")
registerDoSNOW (cl)
foreach(i=1:length(pops),.packages=c("raster")) %dopar% {
  over(pops[[i]],sampling_grid)->original_over_res
}->original_over_res
stopCluster(cl)
doParallel::stopImplicitCluster()
##

lapply(original_over_res,function(x){sampling_grid[unique(x)[!is.na(unique(x))]]->x;
  return(x)})->real_poly
for(i in 1:length(real_poly)) {
  rgeos::gUnaryUnion(real_poly[[i]])->real_poly[[i]]
  print(i)
}
##

sapply(pops,function(x)length(x))->abundance


lapply(pops,function(x)unique(as.character(x$spec)))->pops_names
names(pops)<-pops_names
names(real_poly)<-pops_names
sapply(real_poly,function(x)gArea(x))->areas

#### Simulating spatial accurrences of fossil sites by using the spatial density of actual LGM mammalian fossil localiteis ####
data(lgm)
lgm$spec<-as.character(lgm$spec)
rownames(lgm)<-NULL
lgm[,c("x","y")]->lgm_distr
coordinates(lgm_distr)<-~x+y
proj4string(lgm_distr)<-CRS("+proj=longlat +datum=WGS84")
spTransform(lgm_distr,CRS=crs(species.raster[[1]]))->lgm_distr
lgm_distr<-lgm_distr[-zerodist(lgm_distr)[,2],]
point_dist<-dist(coordinates(lgm_distr),method = "euclidean")
bandw<-median(apply(as.matrix(point_dist),1,function(x)min(x[x!=0])))
est <- bkde2D(coordinates(lgm_distr), 
              bandwidth=c(bandw,bandw), 
              gridsize=c(nrow(species.raster[[1]]),ncol(species.raster[[1]])))
dens_layer = raster(list(x=est$x1,y=est$x2,z=est$fhat))
crs(dens_layer)<-crs(species.raster[[1]])
dens_layer<-projectRaster(from=dens_layer,to=species.raster[[1]]) ;
values(dens_layer)[!is.na(values(dens_layer))]<-scales:: rescale(values(dens_layer)[!is.na(values(dens_layer))],c(0,1))
values(dens_layer)[is.na(values(dens_layer))]<-0
dens_layer[!is.na(dens_layer)]<-scales:: rescale(dens_layer[!is.na(dens_layer)],c(0,1))
dens_layer[is.na(species.raster[[1]]),]<-NA
lapply(pops,function(x)extract(dens_layer,x,cellnumbers=TRUE))->lgm_ID_prob
pops<-mapply(function(x,y) {x$prob<-y[,2];
x$age<-1
return(x)}, pops,lgm_ID_prob,SIMPLIFY=FALSE)

set.seed(loc_seed)
sim_locs<-randomPoints(dens_layer,length(unique(as.character(lgm$loc_id))),prob = TRUE)
sim_locs<-as.data.frame(sim_locs)
coordinates(sim_locs)<-~x+y
crs(sim_locs)<-crs(species.raster[[1]])

#### Extracting species identity by overlapping species polygon geographic ranges by the simulated fossil localities ####
lapply(real_poly,function(x){
  over(x,sim_locs,returnList=TRUE)  
})->over_res

sapply(over_res,function(x)length(x[[1]]))->to_keep
names(which(to_keep>0))->to_keep
over_res[names(over_res)%in%to_keep]->over_res
real_poly[names(real_poly)%in%to_keep]->real_poly
pops[names(pops)%in%to_keep]->pops
populations[populations$spec%in%to_keep,]->populations
areas[names(areas)%in%to_keep]->areas

mapply(function(x,y) {data.frame(x,spec=rep(y,length(x)))->z;
  return(z)},over_res,names(over_res),SIMPLIFY = FALSE)->over_res
over_res<-lapply(over_res,function(x)data.frame(coordinates(sim_locs)[match(x$X1,rownames(coordinates(sim_locs))),],x))
over_res<-do.call(rbind,over_res)
rownames(over_res)<-NULL
over_res<-over_res[order(over_res$X1),]
colnames(over_res)[3]<-"loc_id"
coordinates(over_res)<-~x+y
crs(over_res)<-crs(species.raster[[1]])
over_res->lgm_sim_dat
spTransform(lgm_sim_dat,CRS=CRS("+proj=longlat +datum=WGS84"))->lgm_sim_dat
lgm_sim_dat<-as.data.frame(lgm_sim_dat)
as.character(lgm_sim_dat$spec)->lgm_sim_dat$spec
species_names<-unique(lgm_sim_dat$spec)


#### Simulating a nagative relationship between fossilization bias and species geographic ranges #### 
taf_bias<-seq(from=0.5,to=0.8,length.out = length(species_names))
data.frame(sort(areas),sort(taf_bias,decreasing=TRUE))->taf_data
set.seed(fossil_seed)
red_lgm_sim_dat<-lapply(1:nrow(taf_data),function(z){
  lgm_sim_dat[which(lgm_sim_dat$spec==rownames(taf_data)[z]),]->lgm_spec
  rownames(lgm_spec)<-NULL
  to_rem<-round(taf_data[z,2]*nrow(lgm_spec))
  lgm_spec[-as.numeric(sample(rownames(lgm_spec),to_rem)),]->lgm_spec;
  rownames(lgm_spec)<-NULL
  return(lgm_spec)
})
do.call(rbind,red_lgm_sim_dat)->red_lgm_sim_dat

red_lgm_sim_dat$age<-1
#### LGM simulation end ####


#### Performing MInOSSE ####
Sys.getenv("R_MAX_NUM_DLLs", unset = 1000)
unique(as.character(red_lgm_sim_dat$spec))->spec_list

minosse_dat<-list()
minosse_res_list<-list()
for(i in 1:length(spec_list)){
  if(class(try(minosse_dat[[i]]<-minosse.data(
    obj=red_lgm_sim_dat,
    species_name=spec_list[i],
    domain="land",
    coc.by="locality",
    min.occs=3,
    abiotic.covs=NULL,
    combine.covs=FALSE,   
    reduce_covs_by="pca",
    covs_th=0.95,
    c.size=300000,
    bkg.predictors="presence", 
    min.bkg=100,
    sampling.by.distance=TRUE,
    prediction.ground=prediction_ground,
    crop.by.mcp=FALSE,
    projection="laea",
    lon_0=85,
    lat_0=45,
    n.clusters=clus_num, 
    seed=625)
  ))=="try-error") {next} else {minosse_dat[[i]]<-minosse_dat[[i]];
  
  
  if(class(try(minosse_res_list[[i]]<-minosse.target(
    resp=minosse_dat[[i]][[1]],
    predictors=minosse_dat[[i]][[2]],
    bkg="presence",
    min.bkg = 100,
    n.sims=10,
    sampling.by.distance=TRUE,
    n.folds=n.folds,
    n.sims.clusters=clus_num,
    seed=625)))=="try-error") {next} else minosse_res_list[[i]]<-minosse_res_list[[i]] 
  }
  print(i)
}
gc()

#### Saving results ####

save.image(paste(paste(dir.path,sim.dir,sep=""),"LGM_1979_2015_10_coc_loc_300km.RData",sep=""))
gc()





