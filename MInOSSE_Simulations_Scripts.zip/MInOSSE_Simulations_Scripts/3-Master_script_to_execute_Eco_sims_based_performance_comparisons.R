# This script is used to extreact all the species reconstructions yielded by running
# MInOSSE with the LGM-based simulated fossil record. The following code lines are also
# used to compare MInOSSE outputs with the species'ranges yielded by using the Minimum
# Convex Polygon and the Alpha-hull methods in correctly reconstructing the simulated 
# species' actual geographic distributions. The three methods' performance is evaluated
# by means of the TSS scores. In details, first, MInOSSE's TSS scores are used by alone
# to measure its performance with different paramenters'settings by means of Permutational
# MANOVA, and, then, in comparison with MCP's and Alpha-hull's TSS scores to test their 
# ability in correctly reconstruct simulated actal species' geographic ranges by means 
# of ANOVA and Thukey HSD tests.







# This is a master script that you can use to execute all the other scripts
# running the all the methods'performance computation and comparison. 
# The first step consists of installing the last version of Rtools and the package "pairwiseAdonis". 
# To this aim, here we report the pairwiseAdonis package creator instructions:
# For linux
# make sure you have devtools installed and loaded, for windows also install Rtools
# 
# In your R session
# 
# install_github("pmartinezarbizu/pairwiseAdonis/pairwiseAdonis")
# 
# That's it
# 
# Or...
# 
# For windows
# first install Rtools from here https://cran.r-project.org/bin/windows/Rtools/
# 
# in R install devtools
# 
# install.packages('devtools')
# 
# load devtools
# 
# library(devtools)
# 
# In your R session
# 
# install_github("pmartinezarbizu/pairwiseAdonis/pairwiseAdonis")


# Packages to install:
install.packages(c("alphahull", "geosphere","ConR"))
# Setting the maximum memory size available to R
rm(list=ls(all=TRUE))
memory.size(max=TRUE)


#### Enter the path to the folder where you stored all appendices
appendices_folder<-"C:/MInOSSE_Simulations_Scripts/R_Appendices/" # ending slash required!
appendices_folder_RANDOM<-"C:/MInOSSE_Simulations_Scripts/RFM_RANDOM_Appendices/" # ending slash required!
appendices_folder_CLUSTERED<-"C:/MInOSSE_Simulations_Scripts/RFM_CLUSTERED_Appendices/" # ending slash required!


#### Enter the path where you stored all the simulations ####
my.path<-"C:/MInOSSE_Simulations_Scripts/R_Tests_minosse/"  # ending slash required!
my.path_RANDOM<-"C:/MInOSSE_Simulations_Scripts/RFM_RANDOM_Tests_minosse/"  # ending slash required!
my.path_CLUSTERED<-"C:/MInOSSE_Simulations_Scripts/RFM_CLUSTERED_Tests_minosse/"  # ending slash required!


#### Enter the path where you want to save all the methods' performance metrics when considering cooccurrence analysis ####
results_path<-paste(my.path,"eco-sims/LGM_results/",sep="")
dir.create(results_path, showWarnings = TRUE, recursive = TRUE)

results_path_RANDOM<-paste(my.path_RANDOM,"eco-sims/LGM_results/",sep="")
dir.create(results_path_RANDOM, showWarnings = TRUE, recursive = TRUE)

results_path_CLUSTERED<-paste(my.path_CLUSTERED,"eco-sims/LGM_results/",sep="")
dir.create(results_path_CLUSTERED, showWarnings = TRUE, recursive = TRUE)


#### Enter the path where you want to save all the methods' performance metrics when NOT considering cooccurrence analysis ####
results_path_no_coc<-paste(my.path,"eco-sims/LGM_no_coc_results/",sep="")
dir.create(results_path_no_coc, showWarnings = TRUE, recursive = TRUE)

results_path_no_coc_RANDOM<-paste(my.path_RANDOM,"eco-sims/LGM_no_coc_results/",sep="")
dir.create(results_path_no_coc_RANDOM, showWarnings = TRUE, recursive = TRUE)

results_path_no_coc_CLUSTERED<-paste(my.path_CLUSTERED,"eco-sims/LGM_no_coc_results/",sep="")
dir.create(results_path_no_coc_CLUSTERED, showWarnings = TRUE, recursive = TRUE)


# By running the following code lines, we will extract the MInOSSE's outputs yielded by using
# the three scenarios for the spatial distribution of the fossil localities (the LGM-based
# distribution, the clustered and the random spatial distributions). Each scenario was run 
# with different MInOSSE's parameter's setting, i.e. by using or not using the co-occurrence
# analysis and with the following cell resolutions for spatial reconstructions: 100x100 km,
# 200x200 km, 300x300 km, the mean neighbour distance and half of the mean neighbour distance.
 


#### With LGM-based fossil localities
#### By using cooccurrence analysis and half of the mean neighbour distance as cell resolution ####
rm(list=ls(all=TRUE)[-which(ls(all=TRUE)%in%c("appendices_folder","my.path","results_path","results_path_no_coc"))])
source(paste(appendices_folder,"Models_performance_eco-sims_semimean_coc_loc.R",sep=""))
gc()
#line_plot # a line plot showing the course of methods performance by varying the target species sample size
#box_plot # A box plot comparing the medians and ranges of the considered methods 

#### By using cooccurrence analysis and the mean neighbour distance as cell resolution ####
rm(list=ls(all=TRUE)[-which(ls(all=TRUE)%in%c("appendices_folder","my.path","results_path","results_path_no_coc"))])
source(paste(appendices_folder,"Models_performance_eco-sims_mean_coc_loc.R",sep=""))
gc()
#line_plot # a line plot showing the course of methods performance by varying the target species sample size
#box_plot # A box plot comparing the medians and ranges of the considered methods 

#### By using cooccurrence analysis and 100x100 km as cell resolution ####
rm(list=ls(all=TRUE)[-which(ls(all=TRUE)%in%c("appendices_folder","my.path","results_path","results_path_no_coc"))])
source(paste(appendices_folder,"Models_performance_eco-sims_100km_coc_loc.R",sep=""))
gc()
#line_plot # a line plot showing the course of methods performance by varying the target species sample size
#box_plot # A box plot comparing the medians and ranges of the considered methods 

#### By using cooccurrence analysis and 200x200 km as cell resolution ####
rm(list=ls(all=TRUE)[-which(ls(all=TRUE)%in%c("appendices_folder","my.path","results_path","results_path_no_coc"))])
source(paste(appendices_folder,"Models_performance_eco-sims_200km_coc_loc.R",sep=""))
gc()
#line_plot # a line plot showing the course of methods performance by varying the target species sample size
#box_plot # A box plot comparing the medians and ranges of the considered methods 

#### By using cooccurrence analysis and 300x300 km as cell resolution ####
rm(list=ls(all=TRUE)[-which(ls(all=TRUE)%in%c("appendices_folder","my.path","results_path","results_path_no_coc"))])
source(paste(appendices_folder,"Models_performance_eco-sims_300km_coc_loc.R",sep=""))
gc()
#line_plot # a line plot showing the course of methods performance by varying the target species sample size
#box_plot # A box plot comparing the medians and ranges of the considered methods 



#### Without the cooccurrence analysis and half of the mean neighbour distance as cell resolution ####
rm(list=ls(all=TRUE)[-which(ls(all=TRUE)%in%c("appendices_folder","my.path","results_path","results_path_no_coc"))])
source(paste(appendices_folder,"Models_performance_eco-sims_semimean_no_coc.R",sep=""))
gc()
#line_plot # a line plot showing the course of methods performance by varying the target species sample size
#box_plot # A box plot comparing the medians and ranges of the considered methods 

#### Without the cooccurrence analysis and the mean neighbour distance as cell resolution ####
rm(list=ls(all=TRUE)[-which(ls(all=TRUE)%in%c("appendices_folder","my.path","results_path","results_path_no_coc"))])
source(paste(appendices_folder,"Models_performance_eco-sims_mean_no_coc.R",sep=""))
gc()
#line_plot # a line plot showing the course of methods performance by varying the target species sample size
#box_plot # A box plot comparing the medians and ranges of the considered methods 

#### Without the cooccurrence analysis and 100x100 km as cell resolution ####
rm(list=ls(all=TRUE)[-which(ls(all=TRUE)%in%c("appendices_folder","my.path","results_path","results_path_no_coc"))])
source(paste(appendices_folder,"Models_performance_eco-sims_100km_no_coc.R",sep=""))
gc()
#line_plot # a line plot showing the course of methods performance by varying the target species sample size
#box_plot # A box plot comparing the medians and ranges of the considered methods 

#### Without the cooccurrence analysis and 200x200 km as cell resolution ####
rm(list=ls(all=TRUE)[-which(ls(all=TRUE)%in%c("appendices_folder","my.path","results_path","results_path_no_coc"))])
source(paste(appendices_folder,"Models_performance_eco-sims_200km_no_coc.R",sep=""))
gc()
#line_plot # a line plot showing the course of methods performance by varying the target species sample size
#box_plot # A box plot comparing the medians and ranges of the considered methods 

#### Without the cooccurrence analysis and 300x300 km as cell resolution ####
rm(list=ls(all=TRUE)[-which(ls(all=TRUE)%in%c("appendices_folder","my.path","results_path","results_path_no_coc"))])
source(paste(appendices_folder,"Models_performance_eco-sims_300km_no_coc.R",sep=""))
gc()
#line_plot # a line plot showing the course of methods performance by varying the target species sample size
#box_plot # A box plot comparing the medians and ranges of the considered methods 





#### With randomly distributed fossil localities and by using the co-occurrence analysis.
#### By using the cooccurrence analysis and half of the mean neighbour distance as cell resolution ####
rm(list=ls(all=TRUE)[-which(ls(all=TRUE)%in%c("appendices_folder_RANDOM","my.path_RANDOM","results_path_RANDOM","results_path_no_coc_RANDOM"))])
source(paste(appendices_folder_RANDOM,"Models_performance_eco-sims_semimean_coc_loc.R",sep=""))
gc()
#line_plot # a line plot showing the course of methods performance by varying the target species sample size
#box_plot # A box plot comparing the medians and ranges of the considered methods 

#### By using the cooccurrence analysis and the mean neighbour distance as cell resolution ####
rm(list=ls(all=TRUE)[-which(ls(all=TRUE)%in%c("appendices_folder_RANDOM","my.path_RANDOM","results_path_RANDOM","results_path_no_coc_RANDOM"))])
source(paste(appendices_folder_RANDOM,"Models_performance_eco-sims_mean_coc_loc.R",sep=""))
gc()
#line_plot # a line plot showing the course of methods performance by varying the target species sample size
#box_plot # A box plot comparing the medians and ranges of the considered methods 

#### By using the cooccurrence analysis and 100x100 km as cell resolution ####
rm(list=ls(all=TRUE)[-which(ls(all=TRUE)%in%c("appendices_folder_RANDOM","my.path_RANDOM","results_path_RANDOM","results_path_no_coc_RANDOM"))])
source(paste(appendices_folder_RANDOM,"Models_performance_eco-sims_100km_coc_loc.R",sep=""))
gc()
#line_plot # a line plot showing the course of methods performance by varying the target species sample size
#box_plot # A box plot comparing the medians and ranges of the considered methods 

#### By using the cooccurrence analysis and 200x200 km as cell resolution ####
rm(list=ls(all=TRUE)[-which(ls(all=TRUE)%in%c("appendices_folder_RANDOM","my.path_RANDOM","results_path_RANDOM","results_path_no_coc_RANDOM"))])
source(paste(appendices_folder_RANDOM,"Models_performance_eco-sims_200km_coc_loc.R",sep=""))
gc()
#line_plot # a line plot showing the course of methods performance by varying the target species sample size
#box_plot # A box plot comparing the medians and ranges of the considered methods 

#### By using the cooccurrence analysis and 300x300 km as cell resolution ####
rm(list=ls(all=TRUE)[-which(ls(all=TRUE)%in%c("appendices_folder_RANDOM","my.path_RANDOM","results_path_RANDOM","results_path_no_coc_RANDOM"))])
source(paste(appendices_folder_RANDOM,"Models_performance_eco-sims_300km_coc_loc.R",sep=""))
gc()
#line_plot # a line plot showing the course of methods performance by varying the target species sample size
#box_plot # A box plot comparing the medians and ranges of the considered methods 




#### Without using the cooccurrence analysis and half of the mean neighbour distance as cell resolution ####
rm(list=ls(all=TRUE)[-which(ls(all=TRUE)%in%c("appendices_folder_RANDOM","my.path_RANDOM","results_path_RANDOM","results_path_no_coc_RANDOM"))])
source(paste(appendices_folder_RANDOM,"Models_performance_eco-sims_semimean_no_coc.R",sep=""))
gc()
#line_plot # a line plot showing the course of methods performance by varying the target species sample size
#box_plot # A box plot comparing the medians and ranges of the considered methods 

#### Without using the cooccurrence analysis and the mean neighbour distance as cell resolution ####
rm(list=ls(all=TRUE)[-which(ls(all=TRUE)%in%c("appendices_folder_RANDOM","my.path_RANDOM","results_path_RANDOM","results_path_no_coc_RANDOM"))])
source(paste(appendices_folder_RANDOM,"Models_performance_eco-sims_mean_no_coc.R",sep=""))
gc()
#line_plot # a line plot showing the course of methods performance by varying the target species sample size
#box_plot # A box plot comparing the medians and ranges of the considered methods 

#### Without using the cooccurrence analysis and 100x100 km as cell resolution ####
rm(list=ls(all=TRUE)[-which(ls(all=TRUE)%in%c("appendices_folder_RANDOM","my.path_RANDOM","results_path_RANDOM","results_path_no_coc_RANDOM"))])
source(paste(appendices_folder_RANDOM,"Models_performance_eco-sims_100km_no_coc.R",sep=""))
gc()
#line_plot # a line plot showing the course of methods performance by varying the target species sample size
#box_plot # A box plot comparing the medians and ranges of the considered methods 

#### Without using the cooccurrence analysis and 200x200 km as cell resolution ####
rm(list=ls(all=TRUE)[-which(ls(all=TRUE)%in%c("appendices_folder_RANDOM","my.path_RANDOM","results_path_RANDOM","results_path_no_coc_RANDOM"))])
source(paste(appendices_folder_RANDOM,"Models_performance_eco-sims_200km_no_coc.R",sep=""))
gc()
#line_plot # a line plot showing the course of methods performance by varying the target species sample size
#box_plot # A box plot comparing the medians and ranges of the considered methods 

#### Without using the cooccurrence analysis and 300x300 km as cell resolution ####
rm(list=ls(all=TRUE)[-which(ls(all=TRUE)%in%c("appendices_folder_RANDOM","my.path_RANDOM","results_path_RANDOM","results_path_no_coc_RANDOM"))])
source(paste(appendices_folder_RANDOM,"Models_performance_eco-sims_300km_no_coc.R",sep=""))
gc()
#line_plot # a line plot showing the course of methods performance by varying the target species sample size
#box_plot # A box plot comparing the medians and ranges of the considered methods 






#### With a clustered distribution of fossil localities
#### By using the cooccurrence analysis and half of the mean neighbour distance as cell resolution ####
rm(list=ls(all=TRUE)[-which(ls(all=TRUE)%in%c("appendices_folder_CLUSTERED","my.path_CLUSTERED","results_path_CLUSTERED","results_path_no_coc_CLUSTERED"))])
source(paste(appendices_folder_CLUSTERED,"Models_performance_eco-sims_semimean_coc_loc.R",sep=""))
gc()
#line_plot # a line plot showing the course of methods performance by varying the target species sample size
#box_plot # A box plot comparing the medians and ranges of the considered methods 

#### By using the cooccurrence analysis and the mean neighbour distance as cell resolution ####
rm(list=ls(all=TRUE)[-which(ls(all=TRUE)%in%c("appendices_folder_CLUSTERED","my.path_CLUSTERED","results_path_CLUSTERED","results_path_no_coc_CLUSTERED"))])
source(paste(appendices_folder_CLUSTERED,"Models_performance_eco-sims_mean_coc_loc.R",sep=""))
gc()
#line_plot # a line plot showing the course of methods performance by varying the target species sample size
#box_plot # A box plot comparing the medians and ranges of the considered methods 

#### By using the cooccurrence analysis and 100x100 km as cell resolution ####
rm(list=ls(all=TRUE)[-which(ls(all=TRUE)%in%c("appendices_folder_CLUSTERED","my.path_CLUSTERED","results_path_CLUSTERED","results_path_no_coc_CLUSTERED"))])
source(paste(appendices_folder_CLUSTERED,"Models_performance_eco-sims_100km_coc_loc.R",sep=""))
gc()
#line_plot # a line plot showing the course of methods performance by varying the target species sample size
#box_plot # A box plot comparing the medians and ranges of the considered methods 

#### By using the cooccurrence analysis and 200x200 km as cell resolution ####
rm(list=ls(all=TRUE)[-which(ls(all=TRUE)%in%c("appendices_folder_CLUSTERED","my.path_CLUSTERED","results_path_CLUSTERED","results_path_no_coc_CLUSTERED"))])
source(paste(appendices_folder_CLUSTERED,"Models_performance_eco-sims_200km_coc_loc.R",sep=""))
gc()
#line_plot # a line plot showing the course of methods performance by varying the target species sample size
#box_plot # A box plot comparing the medians and ranges of the considered methods 

#### By using the cooccurrence analysis and 300x300 km as cell resolution ####
rm(list=ls(all=TRUE)[-which(ls(all=TRUE)%in%c("appendices_folder_CLUSTERED","my.path_CLUSTERED","results_path_CLUSTERED","results_path_no_coc_CLUSTERED"))])
source(paste(appendices_folder_CLUSTERED,"Models_performance_eco-sims_300km_coc_loc.R",sep=""))
gc()
#line_plot # a line plot showing the course of methods performance by varying the target species sample size
#box_plot # A box plot comparing the medians and ranges of the considered methods 




#### Without the cooccurrence analysis and half of the mean neighbour distance as cell resolution ####
rm(list=ls(all=TRUE)[-which(ls(all=TRUE)%in%c("appendices_folder_CLUSTERED","my.path_CLUSTERED","results_path_CLUSTERED","results_path_no_coc_CLUSTERED"))])
source(paste(appendices_folder_CLUSTERED,"Models_performance_eco-sims_semimean_no_coc.R",sep=""))
gc()
#line_plot # a line plot showing the course of methods performance by varying the target species sample size
#box_plot # A box plot comparing the medians and ranges of the considered methods 

#### Without the cooccurrence analysis and the mean neighbour distance as cell resolution ####
rm(list=ls(all=TRUE)[-which(ls(all=TRUE)%in%c("appendices_folder_CLUSTERED","my.path_CLUSTERED","results_path_CLUSTERED","results_path_no_coc_CLUSTERED"))])
source(paste(appendices_folder_CLUSTERED,"Models_performance_eco-sims_mean_no_coc.R",sep=""))
gc()
#line_plot # a line plot showing the course of methods performance by varying the target species sample size
#box_plot # A box plot comparing the medians and ranges of the considered methods 

#### Without the cooccurrence analysis and 100x100 km as cell resolution ####
rm(list=ls(all=TRUE)[-which(ls(all=TRUE)%in%c("appendices_folder_CLUSTERED","my.path_CLUSTERED","results_path_CLUSTERED","results_path_no_coc_CLUSTERED"))])
source(paste(appendices_folder_CLUSTERED,"Models_performance_eco-sims_100km_no_coc.R",sep=""))
gc()
#line_plot # a line plot showing the course of methods performance by varying the target species sample size
#box_plot # A box plot comparing the medians and ranges of the considered methods 

#### Without the cooccurrence analysis and 200x200 km as cell resolution ####
rm(list=ls(all=TRUE)[-which(ls(all=TRUE)%in%c("appendices_folder_CLUSTERED","my.path_CLUSTERED","results_path_CLUSTERED","results_path_no_coc_CLUSTERED"))])
source(paste(appendices_folder_CLUSTERED,"Models_performance_eco-sims_200km_no_coc.R",sep=""))
gc()
#line_plot # a line plot showing the course of methods performance by varying the target species sample size
#box_plot # A box plot comparing the medians and ranges of the considered methods 

#### Without the cooccurrence analysis and 300x300 km as cell resolution ####
rm(list=ls(all=TRUE)[-which(ls(all=TRUE)%in%c("appendices_folder_CLUSTERED","my.path_CLUSTERED","results_path_CLUSTERED","results_path_no_coc_CLUSTERED"))])
source(paste(appendices_folder_CLUSTERED,"Models_performance_eco-sims_300km_no_coc.R",sep=""))
gc()
#line_plot # a line plot showing the course of methods performance by varying the target species sample size
#box_plot # A box plot comparing the medians and ranges of the considered methods 








### This script is used to perform the pairwise MANOVA and the Tukey's honest 
# significance test to compare MInOSSE vs. hull methods in correctly reconstruct the simulated species' actual geographic ranges.
rm(list=ls(all=TRUE)[-which(ls(all=TRUE)%in%c("appendices_folder","my.path","results_path","results_path_no_coc"))])
source(paste(appendices_folder,"ANOVA_MANOVA_tests_ECO-sims.R",sep=""))
gc()

# This is the output of the permutational MANOVA showing that there ara no differences in the MInOSSE
# outputs yielded by using different interpolation cell resolutions or by using or not using cooccurrence analysis ###
# No need to perform pairwise test here.
ado_res_LGM_LOCS # permutational MANOVA with LGM-based density fossil localites
pw_ado_res_LGM_LOCS # pairwise permulational MANOVA between cell resolutions with LGM-based density fossil localites
ado_res_RANDOM # permutational MANOVA with random distribution of the fossil localites
ado_res_CLUSTERED # permutational MANOVA with clustered distribution of the fossil localites


#### Results when considering the LGM distribution of mammalian fossil localities to simulate the fossil record
# ANOVA results when considering cooccurrence analysis#
names(anov_res_TRUE_coc)<-sims # each element of the list contains the  performance scores computed for each cell resolution.
lapply(anov_res_TRUE_coc,function(x)x$aov_summary)->anov_res_TRUE_coc_res
anov_res_TRUE_coc_res$`100km`
anov_res_TRUE_coc_res$`200km`
anov_res_TRUE_coc_res$`300km`
anov_res_TRUE_coc_res$semi
anov_res_TRUE_coc_res$mean

# Tukey HSD results when considering cooccurrence analysis#
names(Tukey_res_TRUE_coc)<-sims # each element of the list contains the  performance scores computed for each cell resolution.
Tukey_res_TRUE_coc$`100km`$minosse.vs.hulls # MInOSSE vs. polygon-based methods
Tukey_res_TRUE_coc$`100km`$minosse.vs.minosse # comparisons between different Regression Kriging "binarized" maps by threshold values

Tukey_res_TRUE_coc$`200km`$minosse.vs.hulls # MInOSSE vs. polygon-based methods
Tukey_res_TRUE_coc$`200km`$minosse.vs.minosse # comparisons between different Regression Kriging "binarized" maps by threshold values

Tukey_res_TRUE_coc$`300km`$minosse.vs.hulls # MInOSSE vs. polygon-based methods
Tukey_res_TRUE_coc$`300km`$minosse.vs.minosse # comparisons between different Regression Kriging "binarized" maps by threshold values

Tukey_res_TRUE_coc$`semi`$minosse.vs.hulls # MInOSSE vs. polygon-based methods
Tukey_res_TRUE_coc$`semi`$minosse.vs.minosse # comparisons between different Regression Kriging "binarized" maps by threshold values

Tukey_res_TRUE_coc$`mean`$minosse.vs.hulls # MInOSSE vs. polygon-based methods
Tukey_res_TRUE_coc$`mean`$minosse.vs.minosse # comparisons between different Regression Kriging "binarized" maps by threshold values



# ANOVA results without cooccurrence analysis#
names(anov_res_FALSE_coc)<-sims # each element of the list contains the  performance scores computed for each cell resolution.
lapply(anov_res_FALSE_coc,function(x)x$aov_summary)->anov_res_FALSE_coc_res
anov_res_FALSE_coc_res$`100km`
anov_res_FALSE_coc_res$`200km`
anov_res_FALSE_coc_res$`300km`
anov_res_FALSE_coc_res$semi
anov_res_FALSE_coc_res$mean

# Tukey HSD results without cooccurrence analysis#
names(Tukey_res_FALSE_coc)<-sims # each element of the list contains the  performance scores computed for each cell resolution.
Tukey_res_FALSE_coc$`100km`$minosse.vs.hulls # MInOSSE vs. polygon-based methods
Tukey_res_FALSE_coc$`100km`$minosse.vs.minosse # comparisons between different Regression Kriging "binarized" maps by threshold values

Tukey_res_FALSE_coc$`200km`$minosse.vs.hulls # MInOSSE vs. polygon-based methods
Tukey_res_FALSE_coc$`200km`$minosse.vs.minosse # comparisons between different Regression Kriging "binarized" maps by threshold values

Tukey_res_FALSE_coc$`300km`$minosse.vs.hulls # MInOSSE vs. polygon-based methods
Tukey_res_FALSE_coc$`300km`$minosse.vs.minosse # comparisons between different Regression Kriging "binarized" maps by threshold values

Tukey_res_FALSE_coc$`semi`$minosse.vs.hulls # MInOSSE vs. polygon-based methods
Tukey_res_FALSE_coc$`semi`$minosse.vs.minosse # comparisons between different Regression Kriging "binarized" maps by threshold values

Tukey_res_FALSE_coc$`mean`$minosse.vs.hulls # MInOSSE vs. polygon-based methods
Tukey_res_FALSE_coc$`mean`$minosse.vs.minosse # comparisons between different Regression Kriging "binarized" maps by threshold values











#### Results when considering a random distribution of fossil localities to simulate the fossil record
# ANOVA results when considering cooccurrence analysis#
names(anov_res_TRUE_coc_RANDOM)<-sims # each element of the list contains the  performance scores computed for each cell resolution.
lapply(anov_res_TRUE_coc_RANDOM,function(x)x$aov_summary)->anov_res_TRUE_coc_res_RANDOM
anov_res_TRUE_coc_res_RANDOM$`100km`
anov_res_TRUE_coc_res_RANDOM$`200km`
anov_res_TRUE_coc_res_RANDOM$`300km`
anov_res_TRUE_coc_res_RANDOM$semi
anov_res_TRUE_coc_res_RANDOM$mean

# Tukey HSD results when considering cooccurrence analysis#
names(Tukey_res_TRUE_coc_RANDOM)<-sims # each element of the list contains the  performance scores computed for each cell resolution.
Tukey_res_TRUE_coc_RANDOM$`100km`$minosse.vs.hulls # MInOSSE vs. polygon-based methods
Tukey_res_TRUE_coc_RANDOM$`100km`$minosse.vs.minosse # comparisons between different Regression Kriging "binarized" maps by threshold values

Tukey_res_TRUE_coc_RANDOM$`200km`$minosse.vs.hulls # MInOSSE vs. polygon-based methods
Tukey_res_TRUE_coc_RANDOM$`200km`$minosse.vs.minosse # comparisons between different Regression Kriging "binarized" maps by threshold values

Tukey_res_TRUE_coc_RANDOM$`300km`$minosse.vs.hulls # MInOSSE vs. polygon-based methods
Tukey_res_TRUE_coc_RANDOM$`300km`$minosse.vs.minosse # comparisons between different Regression Kriging "binarized" maps by threshold values

Tukey_res_TRUE_coc_RANDOM$`semi`$minosse.vs.hulls # MInOSSE vs. polygon-based methods
Tukey_res_TRUE_coc_RANDOM$`semi`$minosse.vs.minosse # comparisons between different Regression Kriging "binarized" maps by threshold values

Tukey_res_TRUE_coc_RANDOM$`mean`$minosse.vs.hulls # MInOSSE vs. polygon-based methods
Tukey_res_TRUE_coc_RANDOM$`mean`$minosse.vs.minosse # comparisons between different Regression Kriging "binarized" maps by threshold values



# ANOVA results without cooccurrence analysis#
names(anov_res_FALSE_coc_RANDOM)<-sims # each element of the list contains the  performance scores computed for each cell resolution.
lapply(anov_res_FALSE_coc_RANDOM,function(x)x$aov_summary)->anov_res_FALSE_coc_res_RANDOM
anov_res_FALSE_coc_res_RANDOM$`100km`
anov_res_FALSE_coc_res_RANDOM$`200km`
anov_res_FALSE_coc_res_RANDOM$`300km`
anov_res_FALSE_coc_res_RANDOM$semi
anov_res_FALSE_coc_res_RANDOM$mean

# Tukey HSD results without cooccurrence analysis#
names(Tukey_res_FALSE_coc_RANDOM)<-sims # each element of the list contains the  performance scores computed for each cell resolution.
Tukey_res_FALSE_coc_RANDOM$`100km`$minosse.vs.hulls # MInOSSE vs. polygon-based methods
Tukey_res_FALSE_coc_RANDOM$`100km`$minosse.vs.minosse # comparisons between different Regression Kriging "binarized" maps by threshold values

Tukey_res_FALSE_coc_RANDOM$`200km`$minosse.vs.hulls # MInOSSE vs. polygon-based methods
Tukey_res_FALSE_coc_RANDOM$`200km`$minosse.vs.minosse # comparisons between different Regression Kriging "binarized" maps by threshold values

Tukey_res_FALSE_coc_RANDOM$`300km`$minosse.vs.hulls # MInOSSE vs. polygon-based methods
Tukey_res_FALSE_coc_RANDOM$`300km`$minosse.vs.minosse # comparisons between different Regression Kriging "binarized" maps by threshold values

Tukey_res_FALSE_coc_RANDOM$`semi`$minosse.vs.hulls # MInOSSE vs. polygon-based methods
Tukey_res_FALSE_coc_RANDOM$`semi`$minosse.vs.minosse # comparisons between different Regression Kriging "binarized" maps by threshold values

Tukey_res_FALSE_coc_RANDOM$`mean`$minosse.vs.hulls # MInOSSE vs. polygon-based methods
Tukey_res_FALSE_coc_RANDOM$`mean`$minosse.vs.minosse # comparisons between different Regression Kriging "binarized" maps by threshold values









#### Results when considering a clustered distribution of fossil localities to simulate the fossil record
# ANOVA results when considering cooccurrence analysis#
names(anov_res_TRUE_coc_CLUSTERED)<-sims # each element of the list contains the  performance scores computed for each cell resolution.
lapply(anov_res_TRUE_coc_CLUSTERED,function(x)x$aov_summary)->anov_res_TRUE_coc_res_CLUSTERED
anov_res_TRUE_coc_res_CLUSTERED$`100km`
anov_res_TRUE_coc_res_CLUSTERED$`200km`
anov_res_TRUE_coc_res_CLUSTERED$`300km`
anov_res_TRUE_coc_res_CLUSTERED$semi
anov_res_TRUE_coc_res_CLUSTERED$mean

# Tukey HSD results when considering cooccurrence analysis#
names(Tukey_res_TRUE_coc_CLUSTERED)<-sims # each element of the list contains the  performance scores computed for each cell resolution.
Tukey_res_TRUE_coc_CLUSTERED$`100km`$minosse.vs.hulls # MInOSSE vs. polygon-based methods
Tukey_res_TRUE_coc_CLUSTERED$`100km`$minosse.vs.minosse # comparisons between different Regression Kriging "binarized" maps by threshold values

Tukey_res_TRUE_coc_CLUSTERED$`200km`$minosse.vs.hulls # MInOSSE vs. polygon-based methods
Tukey_res_TRUE_coc_CLUSTERED$`200km`$minosse.vs.minosse # comparisons between different Regression Kriging "binarized" maps by threshold values

Tukey_res_TRUE_coc_CLUSTERED$`300km`$minosse.vs.hulls # MInOSSE vs. polygon-based methods
Tukey_res_TRUE_coc_CLUSTERED$`300km`$minosse.vs.minosse # comparisons between different Regression Kriging "binarized" maps by threshold values

Tukey_res_TRUE_coc_CLUSTERED$`semi`$minosse.vs.hulls # MInOSSE vs. polygon-based methods
Tukey_res_TRUE_coc_CLUSTERED$`semi`$minosse.vs.minosse # comparisons between different Regression Kriging "binarized" maps by threshold values

Tukey_res_TRUE_coc_CLUSTERED$`mean`$minosse.vs.hulls # MInOSSE vs. polygon-based methods
Tukey_res_TRUE_coc_CLUSTERED$`mean`$minosse.vs.minosse # comparisons between different Regression Kriging "binarized" maps by threshold values



# ANOVA results without cooccurrence analysis#
names(anov_res_FALSE_coc_CLUSTERED)<-sims # each element of the list contains the  performance scores computed for each cell resolution.
lapply(anov_res_FALSE_coc_CLUSTERED,function(x)x$aov_summary)->anov_res_FALSE_coc_res_CLUSTERED
anov_res_FALSE_coc_res_CLUSTERED$`100km`
anov_res_FALSE_coc_res_CLUSTERED$`200km`
anov_res_FALSE_coc_res_CLUSTERED$`300km`
anov_res_FALSE_coc_res_CLUSTERED$semi
anov_res_FALSE_coc_res_CLUSTERED$mean

# Tukey HSD results without cooccurrence analysis#
names(Tukey_res_FALSE_coc_CLUSTERED)<-sims # each element of the list contains the  performance scores computed for each cell resolution.
Tukey_res_FALSE_coc_CLUSTERED$`100km`$minosse.vs.hulls # MInOSSE vs. polygon-based methods
Tukey_res_FALSE_coc_CLUSTERED$`100km`$minosse.vs.minosse # comparisons between different Regression Kriging "binarized" maps by threshold values

Tukey_res_FALSE_coc_CLUSTERED$`200km`$minosse.vs.hulls # MInOSSE vs. polygon-based methods
Tukey_res_FALSE_coc_CLUSTERED$`200km`$minosse.vs.minosse # comparisons between different Regression Kriging "binarized" maps by threshold values

Tukey_res_FALSE_coc_CLUSTERED$`300km`$minosse.vs.hulls # MInOSSE vs. polygon-based methods
Tukey_res_FALSE_coc_CLUSTERED$`300km`$minosse.vs.minosse # comparisons between different Regression Kriging "binarized" maps by threshold values

Tukey_res_FALSE_coc_CLUSTERED$`semi`$minosse.vs.hulls # MInOSSE vs. polygon-based methods
Tukey_res_FALSE_coc_CLUSTERED$`semi`$minosse.vs.minosse # comparisons between different Regression Kriging "binarized" maps by threshold values

Tukey_res_FALSE_coc_CLUSTERED$`mean`$minosse.vs.hulls # MInOSSE vs. polygon-based methods
Tukey_res_FALSE_coc_CLUSTERED$`mean`$minosse.vs.minosse # comparisons between different Regression Kriging "binarized" maps by threshold values




